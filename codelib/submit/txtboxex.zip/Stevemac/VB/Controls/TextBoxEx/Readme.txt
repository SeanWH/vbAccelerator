TextboxEx implements the Windows Edit Box Class, which allows you to modify any of the controls properties at run-time. I've thrown in a little of this and that, too give you an idea of what's possible.  There is a lot of extra stuff included, so I would suggest hacking and wacking as required to trim the control down to just the features that make sense for your specific need.  If in the process of doing this, you find a better way of implementing a feature, fix a total bogus existing feature, or come up with a new and cool feature, please feel free to email me at mike@ctr.com, and as time allows I'll weave it into TextboxEx for the benefit of all.

TextboxEx requires the SSubTmr.DLL from Steve McMahon's website, vbAccelerator.

Have Fun!

This software is FREEWARE. You may use it as you see fit.

No warranty express or implied, is given as to the use of this
program. Use at your own risk.
