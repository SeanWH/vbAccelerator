README for E-checker

HI, I send this contribution to Brian's Page

It checks for incoming mail (POP3 client). Uses
Control Panel's Internet Configuration.
Known bugs: if the pop3 password is invalid, the program
show a message from the winsock control (invalid protocol
or something). Solution: correct the password.

The code are freeware. Enjoy it!!.
Send me an acknowlegment if you use it.

Regards

Julio Daniel Moreyra
Trelew - Chubut - Argentina
e-mail:jmoreyra@altavista.net


