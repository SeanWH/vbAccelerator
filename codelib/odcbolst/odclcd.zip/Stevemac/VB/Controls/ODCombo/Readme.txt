***********************************************************************
vbAccelerator ODCboLst Control Complete Source (odclcd.zip)
Copyright � 1998 Steve McMahon (steve@dogma.demon.co.uk)
-----------------------------------------------------------------------
      Visit vbAccelerator - the VB programmer's resource - at
	             www.dogma.demon.co.uk
***********************************************************************

About ODCboLst
Owner draw combo and list boxes are an excellent way to improve the 
look and feel of your application. However, there is precious little 
support for them in Visual Basic. The only owner-draw combo box supplied 
is the Checked list box style, but this is a preset list box style with 
no possibility for customisation. ODCbolst is  a new control, completely 
written in Visual Basic 5, which does all the hard work of setting up 
an owner draw combo or list box. 

It also provides some great looking preset implementations: 

+ Choosing colours 
+ Choosing system colours 
+ Choosing fonts 
+ Drawing combo or list boxes with icons, indentations and different font 
  and fore/back colours for each item 
+ Selecting paragraph styles, similar to the paragraph picker in Word 97 

This project contains the full ODCboLst source code and is provided
for your information only.  It should NOT be used to build modified
versions the ODCboLst control for distribution purposes.  If you want
to build a modified version of the control, make sure you change the
filename and control class name before doing so.  Any bugs or problems
should be reported to the author (steve@dogma.demon.co.uk) for 
incorporation into future releases.

Installation Requirements
ODCboLst requires Visual Basic 5 with at least Service Pack 2 applied
and the SSubTmr.DLL (available from www.dogma.demon.co.uk)

**********************************************************************
Distribution notice:
You are free to distribute odclcd.zip in it's original state to any
public WWW site, online service or BBS without explicitly obtaining
the authors permission. (Notification would be greatly appreciated
though!).
You are also free to use and distribute the compiled ODCboLst.ocx file, 
provided it is unmodified from the version supplied in this package.

If you wish to distribute odclcd.zip by any other means (i.e. if 
you want to include it on a CD or any other software media) then the
EXPRESS PERMISSION of the author is REQUIRED.
***********************************************************************
