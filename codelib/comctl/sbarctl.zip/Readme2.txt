***********************************************************************
vbAccelerator Status Bar Control (sbarctl.zip)
Copyright � 1998 Steve McMahon (steve@vbaccelerator.com)
-----------------------------------------------------------------------
      Visit vbAccelerator - serious free VB source code !
	           http://vbaccelerator.com
***********************************************************************

About the vbAccelerator Status Bar Control
This control provides a small and fairly lightweight (58k) all VB 
replacement for the tab control in COMCTL32.OCX.

Some of the great features of this implementation are:
Features of this implementation:
  * Tooltip support
  * Set status bar icons from Image Lists
  * Change the status bar background colour
  * Create Owner-Draw status bar sections
  * Get the rectangle of any status bar panel.  You can use this to 
    show (for example) a progress bar in the status bar.

Full source is also freely available from http://vbaccelerator.com

Installation Requirements
vbalSbar requires Visual Basic 5 with at least Service Pack 2 applied
and the SSubTmr.DLL (available from http://vbaccelerator.com).

***********************************************************************
Distribution notice:
You are free to distribute this zip in it's original state to any
public WWW site, online service or BBS without explicitly obtaining
the authors permission. (Notification would be greatly appreciated
though!).
You are also free to use or distribute the compiled OCX with your
own application as you wish.

If you wish to distribute the OCX separate to a project by any other 
means (i.e. if  you want to include it on a CD or any other software 
media) then the EXPRESS PERMISSION of the author is REQUIRED.
***********************************************************************
