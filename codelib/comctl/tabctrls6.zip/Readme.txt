***********************************************************************
vbAccelerator Tab Control Control Complete Source (tabctrls.zip)
Copyright � 1998-2000 Steve McMahon (steve@vbaccelerator.com)
-----------------------------------------------------------------------
      Visit vbAccelerator - serious free VB source code !
	           http://vbaccelerator.com
***********************************************************************

About the vbAccelerator Tab Control
This control provides a small and fairly lightweight (52k) all VB 
replacement for the tab control in COMCTL32.OCX.

Some of the great features of this implementation are:
* Flat tab buttons
* Mouse-over Hot-tracking of tabs

This project contains the full vbalTab.ocx source code and is provided
for your information only.  It should NOT be used to build modified
versions the control for distribution purposes.  If you want
to build a modified version of the control, make sure you change the
filename and control class name before doing so.  Any bugs or problems
should be reported to the author (steve@vbaccelerator.com) for 
incorporation into future releases.

Installation Requirements
vbalTab requires Visual Basic 5 with at least Service Pack 2 applied
and the SSubTmr.DLL (available from http://vbaccelerator.com).

***********************************************************************
Distribution notice:
You are free to distribute this zip in it's original state to any
public WWW site, online service or BBS without explicitly obtaining
the authors permission. (Notification would be greatly appreciated
though!).
You are also free to use the code in your own application as you 
wish, or to use or distribute the compiled OCX (provided it is 
unmodified from the version supplied in this package.)
!DO NOT DISTRIBUTE MODIFIED OCX UNLESS YOU HAVE CHANGED THE FILENAME!

If you wish to distribute the source by any other means (i.e. if 
you want to include it on a CD or any other software media) then the
EXPRESS PERMISSION of the author is REQUIRED.
***********************************************************************
