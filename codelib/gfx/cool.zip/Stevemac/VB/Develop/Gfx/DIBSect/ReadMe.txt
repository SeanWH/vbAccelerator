***********************************************************************
vbAccelerator Realtime Image Processing Sample (cool.zip)
Copyright � 1998 Steve McMahon (steve@dogma.demon.co.uk)
-----------------------------------------------------------------------
      Visit vbAccelerator - the VB programmer's resource - at
	             www.dogma.demon.co.uk
***********************************************************************

About The Code
This sample demonstrates using GDI DIB Sections in VB to achieve
real time fades and tv-style static effects.  It also shows how to
resample images.

This code is completely free - do what you like with it!

Please report any bugs to the author (steve@dogma.demon.co.uk) and
send me your cool demos.

***********************************************************************
