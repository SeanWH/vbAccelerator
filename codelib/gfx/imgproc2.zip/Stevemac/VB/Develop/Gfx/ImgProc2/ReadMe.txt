***********************************************************************
vbAccelerator Image Processing Sample (imgproc2.zip)
Copyright � 1998-1999 Steve McMahon (steve@dogma.demon.co.uk)
-----------------------------------------------------------------------
      Visit vbAccelerator - the VB programmer's resource - at
	            http://vbaccelerator.com
***********************************************************************

About the vbAccelerator Image Processing Sample
This sample demonstrates a VB 24 bit image processor using the DIB 
Section GDI object.

What you can do with this sample: 

* Image Processing 
	- Blurring and softening 
	- Sharpening 
	- Embossing 
	- Customised filters 
	- Minimum, Maximum and Average Rank filters for impressionistic 
	  effects 
* Colour Manipulation 
	- Colourise images 
	- Darken and Light images 
	- Gray scale images 
	- Floyd Stucci Black and White conversion 
	- Decrease colour depth by dithering and matching to a specified 
	  palette. 
* Image Combination 
	- Add, subtract with offsets or take the darkest/lightest pixels 
* Resample Images 
	- Use interpolation to create a smooth resized version of an image. 

Any bugs or problems should be reported to the author 
(steve@dogma.demon.co.uk) for incorporation into future releases.

Installation Requirements
This sample requires Visual Basic 5 with at least Service Pack 2 applied
and the SSubTmr.DLL (available from www.dogma.demon.co.uk)

**********************************************************************
Distribution notice:
You are free to distribute this zip in it's original state to any
public WWW site, online service or BBS without explicitly obtaining
the authors permission. (Notification would be greatly appreciated
though!).
You are also free to use the code in your own application as you 
wish, or to distribute the compiled EXE (provided it is unmodified 
from the version supplied in this package.)

If you wish to distribute the source by any other means (i.e. if 
you want to include it on a CD or any other software media) then the
EXPRESS PERMISSION of the author is REQUIRED.
***********************************************************************
