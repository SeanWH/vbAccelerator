***********************************************************************
vbAccelerator DIB Section Class (cdibsect.zip)
Copyright � 1998-1999 Steve McMahon (steve@dogma.demon.co.uk)
-----------------------------------------------------------------------
      Visit vbAccelerator - the VB programmer's resource - at
	             http://vbaccelerator.com
***********************************************************************

About the vbAccelerator Image Processing Sample
This sample provides a class which wraps up using the GDI DIB Section
object in VB.

Any bugs or problems should be reported to the author 
(steve@dogma.demon.co.uk) for incorporation into future releases.

**********************************************************************
Distribution notice:
You are free to distribute this zip in it's original state to any
public WWW site, online service or BBS without explicitly obtaining
the authors permission. (Notification would be greatly appreciated
though!).
You are also free to use the code in your own application as you 
wish.

If you wish to distribute the source by any other means (i.e. if 
you want to include it on a CD or any other software media) then the
EXPRESS PERMISSION of the author is REQUIRED.
***********************************************************************
