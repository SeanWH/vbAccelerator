***********************************************************************
vbAccelerator Desktop DC Splitter Sample
Copyright � 1998 Steve McMahon
-----------------------------------------------------------------------
      Visit vbAccelerator - the VB programmer's resource - at
	             www.dogma.demon.co.uk
***********************************************************************

This sample demonstrates how to create a splitter which draws onto 
the Desktop Device Context.  
Because the splitter is drawing directly on the Desktop window (which 
is simply an image of the windows on the Desktop), there is absolutely 
no restriction where the splitter is drawn.  This means it is possible 
to perform splits on, for example, a left aligned Picture Box on an 
MDI form. 

This method could form the basis for lots of other code. 
For example, you could achieve a dockable tool window effect with this 
method, because you can draw a drag outline (or a Blitted Image of the 
form you are moving - if you prefer your dockable windows to look like 
the ones in Office 97) anywhere on the screen. 

**********************************************************************
Distribution notice:
You are free to distribute csplitdc.zip in it's original state to any
public WWW site, online service or BBS without explicitly obtaining
the authors permission. (Notification would be greatly appreciated
though!).

If you wish to distribute csplitdc.zip by any other means (i.e. if 
you want to include it on a CD or any other software media) then the
EXPRESS PERMISSION of the author is REQUIRED.
***********************************************************************
