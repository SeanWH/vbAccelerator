' ======================================================================================
' Name:     vbAccelerator ListBar Control (VB5 Version)
' Author:   Steve McMahon (steve@vbaccelerator.com)
' Date:     27 February 2000
'
' Requires: SSubTmr.DLL (vbAccelerator Subclassing and timer assistant)
'           - available from http://vbaccelerator.com/
'
' Copyright � 1999-2000 Steve McMahon for vbAccelerator
' --------------------------------------------------------------------------------------
' Visit vbAccelerator - advanced free source code for VB programmers
' http://vbaccelerator.com
' --------------------------------------------------------------------------------------
'
' An accurate reproduction of the Microsoft Outlook Bar, incorporating a ComCtl32.DLL 
' ListView implementation in VB to play with.
'
'
'
'
'
' ======================================================================================
' Distribution notice:
' You are free to distribute this zip file in it's original state to any
' public WWW site, online service or BBS without explicitly obtaining
' the authors permission. (Notification would be greatly appreciated
' though!).
' You are also free to use and distribute any binaries supplied in this
' package, provided they are completely unmodified from the version supplied 
' in this package.
'
' If you wish to distribute this file or its contents by any other means 
' (i.e. if  you want to include it on a CD or any other software media) then 
' the EXPRESS PERMISSION of the author is REQUIRED.
' ======================================================================================
