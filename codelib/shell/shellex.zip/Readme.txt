***********************************************************************
vbAccelerator ShellEx Sample
Copyright � 1998 Steve McMahon
-----------------------------------------------------------------------
      Visit vbAccelerator - the VB programmer's resource - at
	             www.dogma.demon.co.uk
***********************************************************************

This sample demonstrates how use the Shell API ShellExecute function
to start any file without knowing the executable.  It also shows how
to print a file, explore folders, and how to browse for a folder 
using the Shell's BrowseForFolder API function.

**********************************************************************
Distribution notice:
You are free to distribute shellex.zip in it's original state to any
public WWW site, online service or BBS without explicitly obtaining
the authors permission. (Notification would be greatly appreciated
though!).

If you wish to distribute shellex.zip by any other means (i.e. if 
you want to include it on a CD or any other software media) then the
EXPRESS PERMISSION of the author is REQUIRED.
***********************************************************************
