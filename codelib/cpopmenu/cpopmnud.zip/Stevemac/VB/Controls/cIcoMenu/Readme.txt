***********************************************************************
vbAccelerator Icon Menu Control Complete Source (cpopmnud.zip)
Copyright � 1998-1999 Steve McMahon (steve@dogma.demon.co.uk)
-----------------------------------------------------------------------
      Visit vbAccelerator - the VB programmer's resource - at
	             http://vbaccelerator.com
***********************************************************************

About cPopMenu
The cPopMenu control is a really simple way to get icons into a VB 
project's menus. It also allows you to create arbitrary new submenus, 
gives you control over the system menu and has some useful new events 
indicating when menu items are highlighted and exited.

This project contains the full cPopMenu source code and is provided
for your information only.  It should NOT be used to build modified
versions the cPopMenu control for distribution purposes.  If you want
to build a modified version of the control, make sure you change the
filename and control class name before doing so.  Any bugs or problems
should be reported to the author (steve@dogma.demon.co.uk) for 
incorporation into future releases.

Installation Requirements
cPopMenu requires Visual Basic 5 with at least Service Pack 2 applied
and the SSubTmr.DLL (available from www.dogma.demon.co.uk)

**********************************************************************
Distribution notice:
You are free to distribute cpopmnud.zip in it's original state to any
public WWW site, online service or BBS without explicitly obtaining
the authors permission. (Notification would be greatly appreciated
though!).
You are also free to use and distribute the compiled cPopMenu.ocx file, 
provided it is unmodified from the version supplied in this package.

If you wish to distribute cpopmenud.zip by any other means (i.e. if 
you want to include it on a CD or any other software media) then the
EXPRESS PERMISSION of the author is REQUIRED.
***********************************************************************
