***********************************************************************
vbAccelerator PopMenu2 Component
Copyright � 2000 Steve McMahon (steve@vbaccelerator.com)
-----------------------------------------------------------------------
      Visit vbAccelerator - the VB programmer's resource - at
	             http://vbaccelerator.com
***********************************************************************

About the vbAccelerator PopMenu2 Component
----------------------------------------------------------
This component provides a really simple way to get icons into the
menu of any VB project.  Just call the Attach method, passing
in the hWnd of the form, add an ImageList using the ImageList
method and then start associating menu captions with the 0 based
icon index you want to show with the IconIndex method.  If you
change the caption later, just use the IconItemCaptionChanged
method to sort it out.

Installation Requirements
-------------------------
This demonstration requires:
* Visual Basic 6 with at least Service Pack 3
* SSubTmr6.DLL (vbAccelerator VB6 subclassing and timer assistant)
* vbalIml6.OCX (vbAccelerator VB6 ImageList control)
available from vbAccelerator at http://vbaccelerator.com/

Notice
------
This project contains the full source code and is provided
for your information only.  It should NOT be used to build modified
versions the vbalTbar control for distribution purposes.  If you want
to build a modified version of the control, make sure you change the
filename and control class name before doing so.  Any bugs or problems
should be reported to the author (steve@vbaccelerator.com) for 
incorporation into future releases.

**********************************************************************
Distribution notice:
You are free to distribute this zip in it's original state to any
public WWW site, online service or BBS without explicitly obtaining
the authors permission. (Notification would be greatly appreciated
though!).
You are also free to use and distribute any compiled ocx or dll file, 
provided it is unmodified from the version supplied in this package.

If you wish to distribute the contents by any other means (i.e. if 
you want to include it on a CD or any other software media) then the
EXPRESS PERMISSION of the author is REQUIRED.
***********************************************************************
