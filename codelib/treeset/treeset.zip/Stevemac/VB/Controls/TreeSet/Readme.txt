***********************************************************************
vbAccelerator Hierarchy Selector Control (treeset.zip)
Copyright � 1998 Steve McMahon (steve@vbaccelerator.com)
-----------------------------------------------------------------------
      Visit vbAccelerator - the VB programmer's resource - at
	             http://vbaccelerator.com/
***********************************************************************

About the Hierarchy Selector Control
This control allows you to easily create option windows like the
Win98 Explorer Folder Options dialog and the Internet Explorer
Advanced Options dialog.

In addition, it provides an easy method to allow users to choose
hierarchical options.

Any bugs or problems should be reported to the author 
(steve@vbaccelerator.com) for incorporation into future releases.

Installation Requirements
cTreeSet requires Visual Basic 5 with at least Service Pack 2 applied
and SSubTmr.DLL (available from http://vbaccelerator.com/)

The TreeView background code in this control is based on code 
developed by Ben Baird.  Visit his excellent web site, VB Thunder at:
http://www.vbthunder.com/

**********************************************************************
Distribution notice:
You are free to distribute treeset.zip in it's _original_ state to any
public WWW site, online service or BBS without explicitly obtaining
the authors permission. (Notification would be greatly appreciated
though!).
You are also free to use and distribute the compiled ctreeset.ocx file, 
provided it is unmodified from the version supplied in this package.

If you wish to distribute treeset.zip by any other means (i.e. if 
you want to include it on a CD or any other software media) then the
EXPRESS PERMISSION of the author is REQUIRED.
***********************************************************************
