***********************************************************************
vbAccelerator Windows Hook Library
Copyright � 1999 Steve McMahon (steve@vbaccelerator.com)
-----------------------------------------------------------------------
  Visit vbAccelerator - free, advanced source code for VB programmers
	             http://vbaccelerator.com
***********************************************************************

The vbAccelerator Windows Hooks Library is a wrapper around the
Win32 Hook functions, making it easier to implement Hooks in VB
applications.

This zip includes the VB5 binary, source code and demonstration
projects for the vbAccelerator Hook Library.
For more details, and to ensure you have the latest version of the
library, visit the vbAccelerator Windows Hooks Library page:
http://vbaccelerator.com/j-index.htm?url=codelib/hooks/vbalhook.htm


**********************************************************************
Distribution notice:
You are free to distribute vbalhks.zip in it's original state to any
public www site, online service or BBS without explicitly obtaining
the author's permission. (Notification would be greatly appreciated
though!).

You are free distribute vbalHook.dll unmodified, or to use or modify 
the source code as you wish.  However, you must not distribute
modified versions of vbalHook.dll unless you have changed the filename
and the ProgID (project name).

If you wish to distribute vbalhks.zip by any other means (i.e. if 
you want to include it on a CD or any other software media) then the
EXPRESS PERMISSION of the author is REQUIRED.

Please report any bugs in the component to the author.
***********************************************************************
