***********************************************************************
vbAccelerator Hook Library
Copyright � 1999 Steve McMahon (steve@vbaccelerator.com)
-----------------------------------------------------------------------
  Visit vbAccelerator - free, advanced source code for VB programmers
	             http://vbaccelerator.com
***********************************************************************

The vbAccelerator Hook Library is a DLL component which simplifies
the process of setting up Windows Hooks in VB.  Gain complete control
over keyboard, mouse and messages in your application!

This ZIP contains the release version of the DLL for VB5.


Dependencies
============
S-Grid requires SSubTmr.DLL to run. Download it from:
http://vbaccelerator.com/j-index.htm?url=codelib/ssubtmr/ssubtmr.htm

**********************************************************************
Distribution notice:
You are free to distribute sgridctl.zip in it's original state to any
public www site, online service or BBS without explicitly obtaining
the author's permission. (Notification would be greatly appreciated
though!).

You are free to use and distribute vbalGrid.ocx unmodified in your
projects.

If you wish to distribute sgridctl.zip by any other means (i.e. if 
you want to include it on a CD or any other software media) then the
EXPRESS PERMISSION of the author is REQUIRED.

Please report any bugs in the component to the author.
***********************************************************************
