using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

using Microsoft.Win32;

using ICSharpCode.SharpZipLib.Zip;

using vbAccelerator.Controls.ListBox;
using vbAccelerator.Components.ImageList;
using vbAccelerator.Components.Menu;

namespace NetProjectZip
{
	/// <summary>
	/// Summary description for frmNetProjectZip.
	/// </summary>
	public class frmNetProjectZip : System.Windows.Forms.Form
	{
		[DllImport("comctl32")]
		private extern static void InitCommonControls();

		private Hashtable zipMenuItems;
		private SysImageList sysIls;
		private string basePath;
		private System.Windows.Forms.ImageList ilsIcons;
		private System.Windows.Forms.ToolBar tbrMain;
		private System.Windows.Forms.ToolBarButton tbtnOpen;
		private System.Windows.Forms.ToolBarButton tbtnZip;
		private System.Windows.Forms.ToolBarButton tbtnSep1;
		private System.Windows.Forms.ToolBarButton tbtnVba;
		private IconMainMenu mnuMain;
		private IconMenuItem mnuFile;
		private IconMenuItem mnuOpen;
		private IconMenuItem mnuFileSep1;
		private IconMenuItem mnuExit;
		private IconMenuItem mnuZip;
		private IconMenuItem mnuZipAll;
		private IconMenuItem mnuZipSep1;
		private IconMenuItem mnuHelp;
		private IconMenuItem mnuVBA;
		private IconMenuItem mnuHelpSep1;
		private IconMenuItem mnuAbout;
		private System.Windows.Forms.StatusBar sbrMain;
		private System.Windows.Forms.StatusBarPanel spnlMain;
		private System.Windows.Forms.StatusBarPanel spnlName;
		private System.Windows.Forms.StatusBarPanel spnlProgress;
		private System.Windows.Forms.Panel pnlProject;
		private vbAccelerator.Controls.ListBox.CheckedIconListBox lstSolution;
		private System.Windows.Forms.Label lblProjectName;
		private IconContextMenu mnuContext;
		private IconMenuItem mnuContextZipAll;
		private IconMenuItem mnuContextZipSep1;
		private System.ComponentModel.IContainer components;

		public frmNetProjectZip(string[] args)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// Add to the registry for start 
			installRegistry();

			// Prepare icon menu:
			mnuMain.IconImageList = ilsIcons;
			mnuOpen.IconIndex = 0;
			mnuZipAll.IconIndex = 2;
			mnuVBA.IconIndex = 1;
			mnuContext.IconImageList = ilsIcons;
			mnuContextZipAll.IconIndex = 2;
			// Prepare for additional menu items:
			zipMenuItems = new Hashtable();
			enableMenus(false);

			// create sys Image List:
			sysIls = new SysImageList(SysImageListSize.smallIcons);
			// append to the solution box:
			lstSolution.SystemImageList = sysIls;
			lstSolution.HighlightStyle = CheckedIconListBox.ItemHighlightStyle.xp;

			// install events:
			lstSolution.ItemCheck += new ItemCheckEventHandler(lstSolution_ItemCheck);
			mnuOpen.Click += new EventHandler(mnu_Click);
			mnuExit.Click += new EventHandler(mnu_Click);
			mnuZipAll.Click += new EventHandler(mnu_Click);
			mnuVBA.Click += new EventHandler(mnu_Click);
			mnuAbout.Click += new EventHandler(mnu_Click);
			mnuContextZipAll.Click += new EventHandler(mnu_Click);			

			// perform any command line:		
			DoCommand(args);
		}

		private void installRegistry()
		{
			string command = Application.ExecutablePath + " \"%1\"";
			installRegistry(Registry.ClassesRoot, ".sln", "Zip", "Zip Solution", command);
			installRegistry(Registry.LocalMachine, ".sln", "Zip", "Zip Solution", command);

			installRegistry(Registry.ClassesRoot, ".csproj", "Zip", "Zip Project", command);
			installRegistry(Registry.LocalMachine, ".csproj", "Zip", "Zip Project", command);

			installRegistry(Registry.ClassesRoot, ".vbproj", "Zip", "Zip Project", command);
			installRegistry(Registry.LocalMachine, ".vbproj", "Zip", "Zip Project", command);

		}
		private void installRegistry(
			RegistryKey topKey, 
			string ext, 
			string commandName, 
			string commandText, 
			string command
			)
		{
			try
			{
				RegistryKey extKey = topKey.OpenSubKey(ext);
				if (extKey != null)
				{
					string progId = (string)extKey.GetValue("");
					if ((progId != null) && (progId.Length > 0))
					{
						string shellPath = progId + "\\Shell";
						RegistryKey progIdKey = topKey.OpenSubKey(shellPath, true);
						if (progIdKey != null)
						{
							string[] cmds = progIdKey.GetSubKeyNames();
							RegistryKey zipKey = createSubKey(progIdKey, commandName);
							zipKey.SetValue("", commandText);
							RegistryKey commandKey = createSubKey(zipKey, "Command");
							commandKey.SetValue("", command); 
						}
					}
				}
			}
			catch (Exception e)
			{
				Console.WriteLine(e.Message);
			}
		}
		private RegistryKey createSubKey(RegistryKey key, string subKeyName)
		{
			RegistryKey newKey = key.OpenSubKey(subKeyName, true);
			if (newKey == null)
			{
				newKey = key.CreateSubKey(subKeyName);
			}
			return newKey;
		}

		public void DoCommand(string[] args)
		{
			if (args.Length>0)
			{
				loadSolution(args[0]);	
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.ilsIcons = new System.Windows.Forms.ImageList(this.components);
			this.tbrMain = new System.Windows.Forms.ToolBar();
			this.tbtnOpen = new System.Windows.Forms.ToolBarButton();
			this.tbtnZip = new System.Windows.Forms.ToolBarButton();
			this.mnuContext = new vbAccelerator.Components.Menu.IconContextMenu();
			this.mnuContextZipAll = new vbAccelerator.Components.Menu.IconMenuItem();
			this.mnuContextZipSep1 = new vbAccelerator.Components.Menu.IconMenuItem();
			this.tbtnSep1 = new System.Windows.Forms.ToolBarButton();
			this.tbtnVba = new System.Windows.Forms.ToolBarButton();
			this.mnuMain = new vbAccelerator.Components.Menu.IconMainMenu();
			this.mnuFile = new vbAccelerator.Components.Menu.IconMenuItem();
			this.mnuOpen = new vbAccelerator.Components.Menu.IconMenuItem();
			this.mnuFileSep1 = new vbAccelerator.Components.Menu.IconMenuItem();
			this.mnuExit = new vbAccelerator.Components.Menu.IconMenuItem();
			this.mnuZip = new vbAccelerator.Components.Menu.IconMenuItem();
			this.mnuZipAll = new vbAccelerator.Components.Menu.IconMenuItem();
			this.mnuZipSep1 = new vbAccelerator.Components.Menu.IconMenuItem();
			this.mnuHelp = new vbAccelerator.Components.Menu.IconMenuItem();
			this.mnuVBA = new vbAccelerator.Components.Menu.IconMenuItem();
			this.mnuHelpSep1 = new vbAccelerator.Components.Menu.IconMenuItem();
			this.mnuAbout = new vbAccelerator.Components.Menu.IconMenuItem();
			this.sbrMain = new System.Windows.Forms.StatusBar();
			this.spnlMain = new System.Windows.Forms.StatusBarPanel();
			this.spnlName = new System.Windows.Forms.StatusBarPanel();
			this.spnlProgress = new System.Windows.Forms.StatusBarPanel();
			this.pnlProject = new System.Windows.Forms.Panel();
			this.lblProjectName = new System.Windows.Forms.Label();
			this.lstSolution = new vbAccelerator.Controls.ListBox.CheckedIconListBox();
			((System.ComponentModel.ISupportInitialize)(this.spnlMain)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.spnlName)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.spnlProgress)).BeginInit();
			this.pnlProject.SuspendLayout();
			this.SuspendLayout();
			// 
			// ilsIcons
			// 
			this.ilsIcons.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.ilsIcons.ImageSize = new System.Drawing.Size(16, 16);
			this.ilsIcons.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// tbrMain
			// 
			this.tbrMain.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																					   this.tbtnOpen,
																					   this.tbtnZip,
																					   this.tbtnSep1,
																					   this.tbtnVba});
			this.tbrMain.DropDownArrows = true;
			this.tbrMain.ImageList = this.ilsIcons;
			this.tbrMain.Name = "tbrMain";
			this.tbrMain.ShowToolTips = true;
			this.tbrMain.Size = new System.Drawing.Size(472, 25);
			this.tbrMain.TabIndex = 5;
			this.tbrMain.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right;
			this.tbrMain.Wrappable = false;
			this.tbrMain.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.tbrMain_ButtonClick);
			// 
			// tbtnOpen
			// 
			this.tbtnOpen.ImageIndex = 0;
			this.tbtnOpen.Tag = "OPEN";
			this.tbtnOpen.Text = "Open";
			this.tbtnOpen.ToolTipText = "Open a Project or Solution";
			// 
			// tbtnZip
			// 
			this.tbtnZip.DropDownMenu = this.mnuContext;
			this.tbtnZip.ImageIndex = 2;
			this.tbtnZip.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton;
			this.tbtnZip.Tag = "ZIP:ALL";
			this.tbtnZip.Text = "Zip";
			this.tbtnZip.ToolTipText = "Zip Selected Items";
			// 
			// mnuContext
			// 
			this.mnuContext.IconImageList = null;
			this.mnuContext.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.mnuContextZipAll,
																					   this.mnuContextZipSep1});
			// 
			// mnuContextZipAll
			// 
			this.mnuContextZipAll.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
			this.mnuContextZipAll.IconIndex = -1;
			this.mnuContextZipAll.Index = 0;
			this.mnuContextZipAll.OwnerDraw = true;
			this.mnuContextZipAll.Shortcut = System.Windows.Forms.Shortcut.CtrlS;
			this.mnuContextZipAll.Tag = "";
			this.mnuContextZipAll.Text = "&Zip All";
			// 
			// mnuContextZipSep1
			// 
			this.mnuContextZipSep1.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
			this.mnuContextZipSep1.IconIndex = -1;
			this.mnuContextZipSep1.Index = 1;
			this.mnuContextZipSep1.OwnerDraw = true;
			this.mnuContextZipSep1.Tag = "";
			this.mnuContextZipSep1.Text = "-";
			// 
			// tbtnSep1
			// 
			this.tbtnSep1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// tbtnVba
			// 
			this.tbtnVba.ImageIndex = 1;
			this.tbtnVba.Tag = "VBA";
			this.tbtnVba.ToolTipText = "vbAccelerator Home Page";
			// 
			// mnuMain
			// 
			this.mnuMain.IconImageList = null;
			this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.mnuFile,
																					this.mnuZip,
																					this.mnuHelp});
			// 
			// mnuFile
			// 
			this.mnuFile.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
			this.mnuFile.IconIndex = -1;
			this.mnuFile.Index = 0;
			this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.mnuOpen,
																					this.mnuFileSep1,
																					this.mnuExit});
			this.mnuFile.OwnerDraw = true;
			this.mnuFile.Tag = "";
			this.mnuFile.Text = "&File";
			// 
			// mnuOpen
			// 
			this.mnuOpen.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
			this.mnuOpen.IconIndex = -1;
			this.mnuOpen.Index = 0;
			this.mnuOpen.OwnerDraw = true;
			this.mnuOpen.Shortcut = System.Windows.Forms.Shortcut.CtrlO;
			this.mnuOpen.Tag = "";
			this.mnuOpen.Text = "&Open...";
			// 
			// mnuFileSep1
			// 
			this.mnuFileSep1.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
			this.mnuFileSep1.IconIndex = -1;
			this.mnuFileSep1.Index = 1;
			this.mnuFileSep1.OwnerDraw = true;
			this.mnuFileSep1.Tag = "";
			this.mnuFileSep1.Text = "-";
			// 
			// mnuExit
			// 
			this.mnuExit.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
			this.mnuExit.IconIndex = -1;
			this.mnuExit.Index = 2;
			this.mnuExit.OwnerDraw = true;
			this.mnuExit.Tag = "";
			this.mnuExit.Text = "E&xit";
			// 
			// mnuZip
			// 
			this.mnuZip.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
			this.mnuZip.IconIndex = -1;
			this.mnuZip.Index = 1;
			this.mnuZip.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.mnuZipAll,
																				   this.mnuZipSep1});
			this.mnuZip.OwnerDraw = true;
			this.mnuZip.Tag = "";
			this.mnuZip.Text = "&Zip";
			// 
			// mnuZipAll
			// 
			this.mnuZipAll.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
			this.mnuZipAll.IconIndex = -1;
			this.mnuZipAll.Index = 0;
			this.mnuZipAll.OwnerDraw = true;
			this.mnuZipAll.Shortcut = System.Windows.Forms.Shortcut.CtrlS;
			this.mnuZipAll.Tag = "";
			this.mnuZipAll.Text = "Zip A&ll...";
			// 
			// mnuZipSep1
			// 
			this.mnuZipSep1.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
			this.mnuZipSep1.IconIndex = -1;
			this.mnuZipSep1.Index = 1;
			this.mnuZipSep1.OwnerDraw = true;
			this.mnuZipSep1.Tag = "";
			this.mnuZipSep1.Text = "-";
			this.mnuZipSep1.Visible = false;
			// 
			// mnuHelp
			// 
			this.mnuHelp.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
			this.mnuHelp.IconIndex = -1;
			this.mnuHelp.Index = 2;
			this.mnuHelp.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.mnuVBA,
																					this.mnuHelpSep1,
																					this.mnuAbout});
			this.mnuHelp.OwnerDraw = true;
			this.mnuHelp.Tag = "";
			this.mnuHelp.Text = "&Help";
			// 
			// mnuVBA
			// 
			this.mnuVBA.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
			this.mnuVBA.IconIndex = -1;
			this.mnuVBA.Index = 0;
			this.mnuVBA.OwnerDraw = true;
			this.mnuVBA.Shortcut = System.Windows.Forms.Shortcut.F1;
			this.mnuVBA.Tag = "";
			this.mnuVBA.Text = "&vbAccelerator on the Web...";
			// 
			// mnuHelpSep1
			// 
			this.mnuHelpSep1.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
			this.mnuHelpSep1.IconIndex = -1;
			this.mnuHelpSep1.Index = 1;
			this.mnuHelpSep1.OwnerDraw = true;
			this.mnuHelpSep1.Tag = "";
			this.mnuHelpSep1.Text = "-";
			// 
			// mnuAbout
			// 
			this.mnuAbout.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
			this.mnuAbout.IconIndex = -1;
			this.mnuAbout.Index = 2;
			this.mnuAbout.OwnerDraw = true;
			this.mnuAbout.Tag = "";
			this.mnuAbout.Text = "&About...";
			// 
			// sbrMain
			// 
			this.sbrMain.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.sbrMain.Location = new System.Drawing.Point(0, 362);
			this.sbrMain.Name = "sbrMain";
			this.sbrMain.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																					   this.spnlMain,
																					   this.spnlName,
																					   this.spnlProgress});
			this.sbrMain.ShowPanels = true;
			this.sbrMain.Size = new System.Drawing.Size(472, 20);
			this.sbrMain.TabIndex = 6;
			// 
			// spnlMain
			// 
			this.spnlMain.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.spnlMain.Text = "No project or solution loaded.";
			this.spnlMain.Width = 256;
			// 
			// pnlProject
			// 
			this.pnlProject.Controls.AddRange(new System.Windows.Forms.Control[] {
																					 this.lblProjectName,
																					 this.lstSolution});
			this.pnlProject.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnlProject.Location = new System.Drawing.Point(0, 25);
			this.pnlProject.Name = "pnlProject";
			this.pnlProject.Size = new System.Drawing.Size(472, 337);
			this.pnlProject.TabIndex = 10;
			this.pnlProject.Resize += new System.EventHandler(this.pnlProject_Resize);
			this.pnlProject.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlProject_Paint);
			// 
			// lblProjectName
			// 
			this.lblProjectName.BackColor = System.Drawing.SystemColors.ControlDark;
			this.lblProjectName.Dock = System.Windows.Forms.DockStyle.Top;
			this.lblProjectName.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblProjectName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.lblProjectName.Name = "lblProjectName";
			this.lblProjectName.Size = new System.Drawing.Size(472, 20);
			this.lblProjectName.TabIndex = 11;
			this.lblProjectName.Text = "No Project";
			this.lblProjectName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lstSolution
			// 
			this.lstSolution.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lstSolution.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lstSolution.HighlightStyle = vbAccelerator.Controls.ListBox.CheckedIconListBox.ItemHighlightStyle.system;
			this.lstSolution.IntegralHeight = false;
			this.lstSolution.Location = new System.Drawing.Point(4, 28);
			this.lstSolution.Name = "lstSolution";
			this.lstSolution.Size = new System.Drawing.Size(364, 244);
			this.lstSolution.SystemImageList = null;
			this.lstSolution.TabIndex = 10;
			// 
			// frmNetProjectZip
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(472, 382);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.pnlProject,
																		  this.sbrMain,
																		  this.tbrMain});
			this.Menu = this.mnuMain;
			this.Name = "frmNetProjectZip";
			this.Text = "Net Project Zip";
			this.Load += new System.EventHandler(this.frmNetProjectZip_Load);
			((System.ComponentModel.ISupportInitialize)(this.spnlMain)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.spnlName)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.spnlProgress)).EndInit();
			this.pnlProject.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args) 
		{
			InitCommonControls();			
			frmNetProjectZip frm = new frmNetProjectZip(args);
			Application.Run(frm);
		}

		private void clearZipMenu()
		{
			foreach (IconMenuItem zipMenu in zipMenuItems.Keys)
			{
				zipMenu.Click -= new EventHandler(mnu_Click);
				zipMenu.Parent.MenuItems.Remove(zipMenu);
			}
			mnuZipSep1.Visible = false;
			mnuContextZipSep1.Visible = false;
			zipMenuItems.Clear();
		}

		private void loadSolution(string fileName)
		{
			// clear current solution:
			lstSolution.Items.Clear();
			// clear any custom menus:
			enableMenus(false);
	
			// open this solution:
			Solution s = null;
			try
			{
				s = new Solution(fileName);
			}
			catch (Exception e)
			{
				System.Windows.Forms.MessageBox.Show(
					this, 
					string.Format("Failed to load solution: {0}", e.Message), 
					"NetProjectZip",
					MessageBoxButtons.OK,
					MessageBoxIcon.Exclamation);
				return;
			}
			
			// success; display in the list box:
			//Console.WriteLine("{0}", s.ToString());
			// first add the solution:
			enableMenus(true);			

			CheckedIconListBox.CheckedIconItem item = new CheckedIconListBox.CheckedIconItem();
			string contentString = "";
			if ((s.Projects == null) || (s.Projects.Count == 0))
			{
				contentString = "No Projects";
			}
			else if (s.Projects.Count == 1)
			{
				contentString = "1 Project";
			}
			else
			{
				contentString = s.Projects.Count.ToString() + " projects";
			}
			item.Text = String.Format("Solution '{0}' ({1}, {2})", Path.GetFileName(s.FileName), contentString, s.FileName);
			item.IconIndex = sysIls.IconIndex(s.FileName);
			item.Data = s.FileName;
			item.Bold = true;
			lstSolution.Items.Add(item, CheckState.Checked);
			lblProjectName.Text = Path.GetFileName(s.FileName);
			spnlMain.Text = s.FileName;

			// Now add the projects:
			if ((s.Projects != null) && (s.Projects.Count > 0))
			{
				mnuZipSep1.Visible = true;
				mnuContextZipSep1.Visible = true;

				foreach (Project p in s.Projects)
				{
					// Add the new zip menu item:
					IconMenuItem zipMenuItem = new IconMenuItem();
					zipMenuItem.Text = "Zip " + p.Name + "...";
					zipMenuItem.Click += new EventHandler(mnu_Click);
					zipMenuItems.Add(zipMenuItem, "ZIP:" + p.AbsolutePath);
					mnuZip.MenuItems.Add(zipMenuItem);

					zipMenuItem = new IconMenuItem();
					zipMenuItem.Text = "Zip " + p.Name + "...";
					zipMenuItem.Click += new EventHandler(mnu_Click);
					zipMenuItems.Add(zipMenuItem, "ZIP:" + p.AbsolutePath);
					mnuContext.MenuItems.Add(zipMenuItem);

					// Add the project to the listbox:
					item = new CheckedIconListBox.CheckedIconItem();
					item.Text = string.Format("{0} ({1})", p.Name , p.AbsolutePath);
					item.IconIndex = sysIls.IconIndex(p.AbsolutePath);
					item.Indent = 1;
					item.Bold = true;
					item.Data = p.AbsolutePath;
					lstSolution.Items.Add(item, CheckState.Checked);

					// Add associated files:
					foreach (ProjectFile pf in p.FileCollection)
					{
						item = new CheckedIconListBox.CheckedIconItem();
						item.Text = string.Format("{0} ({1})", pf.RelativePath, pf.AbsolutePath);
						item.IconIndex = sysIls.IconIndex(pf.AbsolutePath);
						item.Indent = 2;
						item.Data = pf.AbsolutePath;
						if (!File.Exists(pf.AbsolutePath))
						{
							item.Enabled = false;
						}
						lstSolution.Items.Add(item, CheckState.Checked);
					}

					// Add the configuration directory:
					foreach (ProjectConfigItemCollection pcc in p.Configurations)
					{					
						if (Directory.Exists(pcc.OutputAbsolutePath))
						{
							item = new CheckedIconListBox.CheckedIconItem();
							item.Text = string.Format("{0} ({1})", pcc.Name, pcc.OutputAbsolutePath);
							string folder = Environment.SystemDirectory;
							item.IconIndex = sysIls.IconIndex(folder, true);
							item.Indent = 2;
							item.Bold = true;
							item.Data = pcc.OutputAbsolutePath;
							lstSolution.Items.Add(item, CheckState.Checked);					
							string[] files = Directory.GetFiles(pcc.OutputAbsolutePath, "*.*");
							foreach (string file in files)
							{
								// check if file not already included...
								bool inSolution = false;
								if (Path.Equals(file, s.FileName))
								{
									inSolution = true;
								}
								else
								{
									foreach (Project pCheck in s.Projects)
									{
										if (Path.Equals(file, pCheck.AbsolutePath))
										{
											inSolution = true;
										}
										else
										{
											foreach (ProjectFile pCheckFile in pCheck.FileCollection)
											{
												if (Path.Equals(file, pCheckFile.AbsolutePath))
												{
													inSolution = true;
													break;
												}
											}
											if (inSolution)
											{
												break;
											}
										}
									}
								}
								if (!inSolution)
								{
									item = new CheckedIconListBox.CheckedIconItem();
									item.Text = file;
									item.Data = file;
									item.Indent = 3;
									item.IconIndex = sysIls.IconIndex(file);
									lstSolution.Items.Add(item, CheckState.Checked);
								}
							}
						}
					}

					// Display the dependencies:
					if (p.ReferenceCollection.Count > 0)
					{
						item = new CheckedIconListBox.CheckedIconItem();
						item.Text = "References";
						item.Bold = true;
						item.IconIndex = sysIls.IconIndex(Environment.SystemDirectory, true);
						item.Indent = 2;
						item.NoCheckBox = true;
						lstSolution.Items.Add(item);

						foreach (ProjectReference r in p.ReferenceCollection)
						{
							item = new CheckedIconListBox.CheckedIconItem();
							item.Text = String.Format("{0} ({1})", r.Name, r.HintPath);
							item.Indent = 4;
							item.NoCheckBox = true;
							item.IconIndex = sysIls.IconIndex(r.AbsolutePath);
							lstSolution.Items.Add(item);
						}
					}
				}
			}	
			basePath = s.LongestSharedPath;
			Console.WriteLine("Longest shared path: {0}", basePath);
			
		}

		private void enableMenus(bool state)
		{
			mnuZipAll.Enabled = state;
			tbtnZip.Enabled = state;
			clearZipMenu();
			if (!state)
			{
				lblProjectName.Text = "No Project.";
				spnlMain.Text = "No Project.";
			}
		}

		private void frmNetProjectZip_Load(object sender, System.EventArgs e)
		{
		}

		private void lstSolution_ItemCheck(object sender, ItemCheckEventArgs e)
		{
			if (e.NewValue == CheckState.Checked)
			{
				// anything below this item should also be checked:
				CheckedIconListBox.CheckedIconItem c = (CheckedIconListBox.CheckedIconItem)lstSolution.Items[e.Index];
				int thisIndent = c.Indent;
				for (int i = e.Index + 1; i < lstSolution.Items.Count; i++)
				{
					c = (CheckedIconListBox.CheckedIconItem)lstSolution.Items[i];
					if (c.Indent <= thisIndent)
					{
						break;
					}
					else
					{
						lstSolution.SetItemCheckState(i, CheckState.Checked);
					}
				}

				// all parents which have no unchecked children should be checked:
			}
			else
			{
				// anything below this item should be unchecked:
				CheckedIconListBox.CheckedIconItem c = (CheckedIconListBox.CheckedIconItem)lstSolution.Items[e.Index];
				int thisIndent = c.Indent;
				for (int i = e.Index + 1; i < lstSolution.Items.Count; i++)
				{
					c = (CheckedIconListBox.CheckedIconItem)lstSolution.Items[i];
					if (c.Indent <= thisIndent)
					{
						break;
					}
					else
					{
						lstSolution.SetItemCheckState(i, CheckState.Unchecked);
					}
				}				

				// anything at a higher check level should be partially checked:

			}
		}

		private void zipSolution(string fileName, string part)
		{
			Console.WriteLine("Zip {0} to {1}", part, fileName);

			if (File.Exists(fileName))
			{
				File.Delete(fileName);
			}

			ZipOutputStream s = new ZipOutputStream(File.Create(fileName));
			foreach (int index in lstSolution.CheckedIndices)
			{				
				CheckedIconListBox.CheckedIconItem c;
				c = (CheckedIconListBox.CheckedIconItem)lstSolution.Items[index];
				string file = (string)c.Data;
				Console.WriteLine("{0}", file);
				if (!Directory.Exists(file))
				{
					if (File.Exists(file))
					{
						FileStream fs = File.OpenRead(file);
						byte[] buffer = new byte[fs.Length];
						fs.Read(buffer, 0, buffer.Length);

						string sharedPath = basePath;
						string relativePath = file;
						if (sharedPath.Length > 0)
						{
							if (!sharedPath.EndsWith(Path.DirectorySeparatorChar.ToString()))
							{
								sharedPath += Path.DirectorySeparatorChar;
							}
							relativePath = file.Replace(sharedPath, "");
						}
						ZipEntry entry = new ZipEntry(relativePath);
						s.PutNextEntry(entry);
						s.Write(buffer, 0, buffer.Length);
					}
					else
					{
						Console.WriteLine("File {0} not found.", file);
					}
				}
			}
			s.Finish();
			s.Close();
		}

		private void mnu_Click(object sender, System.EventArgs e)
		{
			if (sender == mnuOpen)
			{
				commandHandler("OPEN");
			}
			else if (sender == mnuExit)
			{
				commandHandler("EXIT");
			}
			else if ((sender == mnuZipAll) || (sender == mnuContextZipAll))
			{
				commandHandler("ZIP:ALL");
			}
			else if (sender == mnuVBA)
			{
				commandHandler("VBA");
			}
			else if (sender == mnuAbout)
			{
				commandHandler("ABOUT");
			}
			else if (zipMenuItems.ContainsKey(sender))
			{
				commandHandler((string)zipMenuItems[sender]);
			}
		}

		private void tbrMain_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
			if (e.Button.Tag != null)
			{
				commandHandler((string)e.Button.Tag);
			}
		}

		private void commandHandler(string tag)
		{
			if (tag.Equals("OPEN"))
			{
				OpenFileDialog o = new OpenFileDialog();
				o.CheckFileExists = true;
				o.CheckPathExists = true;
				o.Filter = "All Project Files (*.sln;*.csproj;*.vbproj;)|*.sln;*.csjproj;*.vbproj;|Solutions (*.sln)|*.sln|C# Projects (*.csproj)|*.csproj|VB Projects (*.vbproj)|*.vbproj|All Files (*.*)|*.*";
				o.FilterIndex = 1;
				o.DefaultExt = "*.SLN";
				if (o.ShowDialog(this) == DialogResult.OK)
				{
					loadSolution(o.FileName);
				}
			}
			else if (tag.StartsWith("ZIP"))
			{
				int pos = tag.IndexOf(":");
				string part = "ALL";
				if (pos > 0)
				{
					part = tag.Substring(pos);
				}
				
				SaveFileDialog s = new SaveFileDialog();			
				s.Filter = "Zip Files (*.zip)|*.zip|All Files (*.*)|*.*";
				s.FilterIndex = 1;
				s.DefaultExt = "*.ZIP";
				s.OverwritePrompt = true;
				if (s.ShowDialog(this) == DialogResult.OK)
				{
					zipSolution(s.FileName, part);
				}

			}
			else if (tag.Equals("VBA"))
			{
				
			}
			else if (tag.Equals("EXIT"))
			{
				this.Close();
			}
			else if (tag.Equals("ABOUT"))
			{
				frmAbout about = new frmAbout();
				about.ShowDialog(this);
			}
		}

		private void pnlProject_Resize(object sender, EventArgs e)
		{
			try
			{
				Size sz = new Size(
					pnlProject.ClientRectangle.Width,
					pnlProject.ClientRectangle.Height - lblProjectName.Height - 2
					);
				lstSolution.Left = 0;
				lstSolution.Top = lblProjectName.Height + 1;
				lstSolution.Size = sz;
			}
			catch
			{
			}
		}

		private void pnlProject_Paint(object sender, PaintEventArgs e)
		{
		}

	}
}
