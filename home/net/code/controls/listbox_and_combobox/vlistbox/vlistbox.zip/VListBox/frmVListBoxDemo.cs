using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using vbAccelerator.Components.Controls;

namespace VListBoxCS
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmVListBoxDemo : System.Windows.Forms.Form
	{
		private VListBox listBox1;
		private FixedSizeCache cache;
		private System.Windows.Forms.Label lblInfo;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmVListBoxDemo()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// Create a cache.  The idea is that if looking up the data
			// to display in the ListBox is expensive, then a redraw
			// of the ListBox will be expensive too, since you'll need
			// to look up the data again.  By holding a cache of a small
			// number of objects, many redraws can be serviced from the 
			// cache and the performance hit will only be seen when you
			// try to display items that haven't been shown before.
			cache = new FixedSizeCache(512);

			// Set the number of items in our Virtual List Box:
			listBox1.Count = 100000;

			// Set the draw handler for items in the List Box:
			listBox1.DrawItem += new DrawItemEventHandler(listBox1_DrawItem);
			listBox1.SelectedIndexChanged += new EventHandler(listBox1_SelectedIndexChanged);

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmVListBoxDemo));
			this.listBox1 = new vbAccelerator.Components.Controls.VListBox();
			this.lblInfo = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// listBox1
			// 
			this.listBox1.Count = 1;
			this.listBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
			this.listBox1.ItemHeight = 16;
			this.listBox1.Location = new System.Drawing.Point(4, 56);
			this.listBox1.Name = "listBox1";
			this.listBox1.ScrollAlwaysVisible = true;
			this.listBox1.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
			this.listBox1.Size = new System.Drawing.Size(428, 180);
			this.listBox1.TabIndex = 0;
			// 
			// lblInfo
			// 
			this.lblInfo.Location = new System.Drawing.Point(8, 8);
			this.lblInfo.Name = "lblInfo";
			this.lblInfo.Size = new System.Drawing.Size(424, 44);
			this.lblInfo.TabIndex = 1;
			this.lblInfo.Text = "This ListBox is an extended Framework ListBox which supports Virtual  Mode.  In v" +
				"irtual mode, the items are externally managed.  This allows us to display many m" +
				"ore items that could be displayed normally, in this case 100,000.";
			// 
			// frmVListBoxDemo
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(436, 242);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lblInfo,
																		  this.listBox1});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmVListBoxDemo";
			this.Text = "vbAccelerator Virtual ListBox Demonstration";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmVListBoxDemo());
		}


		private void listBox1_DrawItem(object sender, DrawItemEventArgs e)
		{
			// Determine the text for the item we want to display:
			String text = "";
			if (cache.Contains(e.Index))
			{
				text = (String) cache[e.Index];
			}
			else
			{
				// here we would look up the item with the specified index
				text = String.Format("Item {0}", e.Index);
				cache.Add(e.Index, text);
			}

			// Draw the item.  You can use your own customised drawing
			// routine for more interesting ListBoxes, e.g. with icons,
			// pictures, multi-columns etc.
			listBox1.DefaultDrawItem(e, text);

		}

		private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			Console.WriteLine("Selected index: {0}", listBox1.SelectedIndex);
		}

	}
}
