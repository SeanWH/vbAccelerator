Public Class frmVListBoxDemo
    Inherits System.Windows.Forms.Form

    Private cache As FixedSizeCache = Nothing


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        '// Create a cache.  The idea is that if looking up the data
        '// to display in the ListBox is expensive, then a redraw
        '// of the ListBox will be expensive too, since you'll need
        '// to look up the data again.  By holding a cache of a small
        '// number of objects, many redraws can be serviced from the 
        '// cache and the performance hit will only be seen when you
        '// try to display items that haven't been shown before.
        cache = New FixedSizeCache(512)

        '// Set the number of items in our Virtual List Box:
        ListBox1.Count = 100000

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents ListBox1 As vbAccelerator.Components.Controls.VListBox
    Friend WithEvents lblInfo As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmVListBoxDemo))
        Me.ListBox1 = New VListBoxVB.vbAccelerator.Components.Controls.VListBox()
        Me.lblInfo = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'ListBox1
        '
        Me.ListBox1.Count = 1
        Me.ListBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ListBox1.ItemHeight = 16
        Me.ListBox1.Location = New System.Drawing.Point(4, 56)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(428, 212)
        Me.ListBox1.TabIndex = 0
        '
        'lblInfo
        '
        Me.lblInfo.Location = New System.Drawing.Point(8, 8)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(424, 44)
        Me.lblInfo.TabIndex = 2
        Me.lblInfo.Text = "This ListBox is an extended Framework ListBox which supports Virtual  Mode.  In v" & _
        "irtual mode, the items are externally managed.  This allows us to display many m" & _
        "ore items that could be displayed normally, in this case 100,000."
        '
        'frmVListBoxDemo
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(436, 274)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblInfo, Me.ListBox1})
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmVListBoxDemo"
        Me.Text = "vbAccelerator Virtual ListBox Demonstration"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ListBox1_DrawItem(ByVal sender As Object, ByVal e As System.Windows.Forms.DrawItemEventArgs) Handles ListBox1.DrawItem
        '// Determine the text for the item we want to display:
        Dim text As String = ""
        If (cache.Contains(e.Index)) Then
            text = cache(e.Index)
        Else
            '// here we would look up the item with the specified index
            text = String.Format("Item {0}", e.Index)
            cache.Add(e.Index, text)
        End If

        '// Draw the item.  You can use your own customised drawing
        '// routine for more interesting ListBoxes, e.g. with icons,
        '// pictures, multi-columns etc.
        ListBox1.DefaultDrawItem(e, text)
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        Console.WriteLine("Selected index: {0}", ListBox1.SelectedIndex)
    End Sub
End Class
