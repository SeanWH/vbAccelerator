''' <summary>
''' A very simple implementation of a cache for a limited number
''' of objects. 
''' </summary>
Public Class FixedSizeCache

    Private Const DEFAULT_CACHE_CAPACITY As Integer = 200

    Private size As Integer
    Private cache As Hashtable
    Private keyHistory As Queue

    Public Sub Add(ByVal key As Object, ByVal item As Object)
        If (cache.Contains(key)) Then
            '// this item may end up being removed inappropriately
            '// early, since we haven't adjusted the keyHistory
            '// queue.  The assumption is that it is
            '// quicker to do an additional lookup than rewrite
            '// the keyHistory queue.
            cache(key) = item
        Else
            keyHistory.Enqueue(key)
            cache.Add(key, item)
            If (cache.Count > size) Then
                '// remove oldest item
                Dim removeKey As Object = keyHistory.Dequeue()
                cache.Remove(removeKey)
            End If
        End If
    End Sub

    Public Sub Clear()
        cache.Clear()
        keyHistory.Clear()
    End Sub

    Public Function Contains(ByVal key As Object) As Boolean
        Return cache.Contains(key)
    End Function

    Default Public ReadOnly Property Item(ByVal key As Object) As Object
        Get
            Return cache(key)
        End Get
    End Property

    Public Sub New(ByVal capacity As Integer)
        If (capacity <= 0) Then
            Throw New ArgumentException("Cache capacity must be >= 1", "capacity")
        End If
        size = capacity
        cache = New Hashtable()
        keyHistory = New Queue()
    End Sub

    Public Sub New()
        Me.New(DEFAULT_CACHE_CAPACITY)
    End Sub

End Class
