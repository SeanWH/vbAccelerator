using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace vbAccelerator.Components.Controls
{
	/// <summary>
	/// A class which raises an event when a ComboBox closes up.
	/// </summary>
	public class ComboCloseUpDetector : NativeWindow
	{
		/// <summary>
		/// Used to detect when the ComboBox is closed up.
		/// </summary>
		private const int WM_COMMAND = 0x111;
		private const int CBN_CLOSEUP = 8;

		/// <summary>
		/// The handle of the combo box to check
		/// </summary>
		private IntPtr comboHandle = IntPtr.Zero;

		/// <summary>
		/// Raised when the ComboBox closes up.
		/// </summary>
		public event System.EventHandler CloseUp;

		/// <summary>
		/// Raises the <see cref="CloseUp"/> event for the combo box.
		/// </summary>
		/// <param name="e">Not used</param>
		protected virtual void OnCloseUp(EventArgs e)
		{
			if (this.CloseUp != null)
			{
				this.CloseUp(this, e);
			}
		}

		/// <summary>
		/// Performs default Window Procedure processing and
		/// allows detection of the point when the combo box
		/// closes up.
		/// </summary>
		/// <param name="m">Window Procedure Message</param>
		protected override void WndProc(ref System.Windows.Forms.Message m)
		{
			base.WndProc(ref m);
			switch (m.Msg)
			{
				case (WM_COMMAND):
					if (m.LParam == comboHandle)
					{
						int notifyMessage = (int)((((uint)m.WParam) & 0xFFFF0000) >> 16 );
						if (notifyMessage == CBN_CLOSEUP)
						{
							OnCloseUp(new EventArgs());
						}
					}
					break;
			}
		}


		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="comboHandle">The handle of the combo box to
		/// check.</param>
		public ComboCloseUpDetector(IntPtr comboHandle) : base()
		{
			this.comboHandle = comboHandle;
		}

	}
}
