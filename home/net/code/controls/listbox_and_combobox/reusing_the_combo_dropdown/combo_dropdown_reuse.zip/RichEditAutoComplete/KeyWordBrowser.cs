using System;

namespace RichEditAutoComplete
{
	/// <summary>
	/// Summary description for KeyWordBrowser.
	/// </summary>
	public class KeyWordBrowser
	{
		public KeyWordBrowser()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
