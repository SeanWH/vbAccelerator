using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

using vbAccelerator.Components.Controls;

namespace RichEditAutoComplete
{
	/// <summary>
	/// Summary description for DropDown.
	/// </summary>
	public class DropDown : System.Windows.Forms.ComboBox
	{
		/// <summary>
		/// The class which enables the drop-down position
		/// to be modified.
		/// </summary>
		private DropDownPosition position;

		/// <summary>
		/// Raised when the combo box is closed up
		/// </summary>
		public event System.EventHandler CloseUp;

		/// <summary>
		/// Gets/sets whether to position the drop-down or not.
		/// </summary>
		public bool PositionDropDown
		{
			get
			{
				return this.position.PositionDropDown;
			}
			set
			{
				this.position.PositionDropDown = value;
			}
		}

		/// <summary>
		/// Gets/sets the location to show the drop-down at.
		/// </summary>
		public Point DropDownLocation
		{
			get
			{
				return this.position.DropDownLocation;
			}
			set
			{
				this.position.DropDownLocation = value;
			}
		}

		/// <summary>
		/// Performs default OnHandleCreated processing and connects to
		/// combo box for drop-down processing.
		/// </summary>
		/// <param name="e">Not used.</param>
		protected override void OnHandleCreated(EventArgs e)
		{
			base.OnHandleCreated(e);
			position.AssignHandle(this.Handle);
		}


		private void position_CloseUp(object sender, EventArgs e)
		{
			Trace.WriteLine("DropDown.position_CloseUp");
			if (this.CloseUp != null)
			{
				this.CloseUp(this, e);
			}
		}

		/// <summary>
		/// This implementation draws a colour box
		/// </summary>
		/// <param name="e">Draw item arguments</param>
		protected override void OnDrawItem(DrawItemEventArgs e)
		{
			if ((e.Index > -1) && (e.Index < this.Items.Count))
			{
				bool selected = ((e.State & DrawItemState.Selected) == DrawItemState.Selected);				
				bool rightToLeft = (this.RightToLeft == RightToLeft.Yes);
				string itemText = this.Items[e.Index].ToString();

				// Fill background:
				e.Graphics.FillRectangle(
					(selected ? SystemBrushes.Highlight : SystemBrushes.Window), 
					e.Bounds);

				// Draw colour box:
				Rectangle colourBoxBounds = new Rectangle(e.Bounds.Location, e.Bounds.Size);
				colourBoxBounds.Y += 2;
				colourBoxBounds.Height -= 5;
				if (rightToLeft)
				{
					colourBoxBounds.X += colourBoxBounds.Width - 28;
				}
				else
				{
					colourBoxBounds.X += 2;
				}
				colourBoxBounds.Width = 24;

				KnownColor knownColor = KnownColor.ControlLight;
				knownColor = (KnownColor) Enum.Parse(knownColor.GetType(), itemText, true);
				Brush colourSample = new SolidBrush(Color.FromKnownColor(knownColor));
				e.Graphics.FillRectangle(colourSample, colourBoxBounds);
				colourSample.Dispose();
				e.Graphics.DrawRectangle(SystemPens.ControlDarkDark, colourBoxBounds);
	
				// Draw the text:
				RectangleF textBoxBounds = new RectangleF(e.Bounds.Left, e.Bounds.Top, e.Bounds.Width, e.Bounds.Height);
				StringFormat textFormat = new StringFormat(
					StringFormatFlags.NoWrap |
					(rightToLeft ? StringFormatFlags.DirectionRightToLeft : 0));
				textFormat.LineAlignment = StringAlignment.Center;
				textFormat.Alignment = StringAlignment.Near;
				if (!rightToLeft)
				{
					textBoxBounds.X += 28;
				}
				textBoxBounds.Width -= 28;

				e.Graphics.DrawString(itemText, this.Font, 
					(selected ? SystemBrushes.HighlightText : SystemBrushes.WindowText ),
					textBoxBounds, 
					textFormat);

			}
		}


		/// <summary>
		/// Default constructor
		/// </summary>
		public DropDown() : base()
		{
			this.Location = new Point(0x7FF0, 0x7FF0);
			this.position = new DropDownPosition();
			position.CloseUp += new EventHandler(position_CloseUp);
		}

	}
}
