using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace RichEditAutoComplete
{
	/// <summary>
	/// A form which demonstrates manipulating the position of the drop-down portion of
	/// a combo box.  This can be used for customised auto-complete and 
	/// item pick functionality in forms.
	/// </summary>
	public class frmDropDownPosition : System.Windows.Forms.Form
	{
		private AutoComplete autoComplete = null;

		private System.Windows.Forms.RichTextBox richTextBox1;
		private System.Windows.Forms.Button button1;
		private DropDown comboBox1;
		private System.Windows.Forms.Label label1;	
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary>
		/// Creates a new instance of the demonstration form
		/// </summary>
		public frmDropDownPosition()
		{			
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			comboBox1.PositionDropDown = true;
			Point pt = new Point(button1.Left, button1.Top + button1.Height);
			Point ptScreen = this.PointToScreen(pt);
			comboBox1.DropDownLocation = ptScreen;

			Array arr = Enum.GetNames(typeof(System.Drawing.KnownColor));
			comboBox1.Items.AddRange((object[]) arr);

			richTextBox1.KeyUp += new KeyEventHandler(richTextBox1_KeyUp);
			richTextBox1.SelectionStart = richTextBox1.Text.Length;

			autoComplete = new AutoComplete();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDropDownPosition));
			this.richTextBox1 = new System.Windows.Forms.RichTextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.comboBox1 = new RichEditAutoComplete.DropDown();
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// richTextBox1
			// 
			this.richTextBox1.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.richTextBox1.Location = new System.Drawing.Point(8, 52);
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.ShowSelectionMargin = true;
			this.richTextBox1.Size = new System.Drawing.Size(284, 212);
			this.richTextBox1.TabIndex = 0;
			this.richTextBox1.Text = "KnownColor";
			// 
			// button1
			// 
			this.button1.Font = new System.Drawing.Font("Marlett", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.button1.Location = new System.Drawing.Point(300, 52);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(32, 32);
			this.button1.TabIndex = 2;
			this.button1.Text = "u";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// comboBox1
			// 
			this.comboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
			this.comboBox1.DropDownLocation = new System.Drawing.Point(0, 0);
			this.comboBox1.Location = new System.Drawing.Point(56, 180);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.PositionDropDown = false;
			this.comboBox1.Size = new System.Drawing.Size(176, 22);
			this.comboBox1.TabIndex = 3;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(328, 32);
			this.label1.TabIndex = 4;
			this.label1.Text = "ComboBox dropdown  positioning demonstration.  Type a Period into the text box or" +
				" click the button to demonstrate the effect.";
			// 
			// frmDropDownPosition
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(348, 278);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.label1,
																		  this.button1,
																		  this.richTextBox1,
																		  this.comboBox1});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmDropDownPosition";
			this.Text = "vbAccelerator Combo DropDown Positioning Example";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmDropDownPosition());
		}



		private void button1_Click(object sender, System.EventArgs e)
		{
			// Get location of bottom-left point of button relative to the screen:
			Point location = button1.Location;
			location.Y += button1.Height;
			location = this.PointToScreen(location);

			// Show the drop-down:
			comboBox1.DropDownLocation = location;
			comboBox1.DroppedDown = true;
			comboBox1.Focus();
		}


		private void richTextBox1_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.OemPeriod)
			{

				// Here we would determine the text prior to the
				// period character in order to determine which
				// drop-down list to show; in this case we
				// just show some default text to demonstrate
				// the technique
				
				
				autoComplete.Start(richTextBox1, comboBox1);				
			}
		}


	}
}
