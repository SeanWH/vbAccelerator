Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("vbAccelerator Text and ComboBox Margin Customisation Sample")> 
<Assembly: AssemblyDescription("Demonstrates how to make space at the right or left margin of a TextBox or ComboBox and display a custom graphic or control.")> 
<Assembly: AssemblyCompany("vbAccelerator")> 
<Assembly: AssemblyProduct("vbAccelerator Text and ComboBox Margin Customisation Sample")> 
<Assembly: AssemblyCopyright("Copyright � 2003 Steve McMahon for vbAccelerator Ltd.")> 
<Assembly: AssemblyTrademark("vbAccelerator and vbAccelerator.com are Legal Trade Marks of vbAccelerator Ltd.  All Rights Reserved.")> 
<Assembly: CLSCompliant(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("FF8E32C9-C1A9-4905-AC27-871CF3244CE7")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.*")> 
