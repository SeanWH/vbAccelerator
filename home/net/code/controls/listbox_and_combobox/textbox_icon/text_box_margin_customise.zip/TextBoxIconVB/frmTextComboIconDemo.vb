Public Class frmTextComboIconDemo
    Inherits System.Windows.Forms.Form

    Private textBox1Icon As vbAccelerator.Components.Controls.TextBoxMarginCustomise
    Private textBox2Icon As vbAccelerator.Components.Controls.TextBoxMarginCustomise
    Private textBox3Icon As vbAccelerator.Components.Controls.TextBoxMarginCustomise
    Private textBox4Icon As vbAccelerator.Components.Controls.TextBoxMarginCustomise
    Private comboBox1Icon As vbAccelerator.Components.Controls.TextBoxMarginCustomise
    Private comboBox2Icon As vbAccelerator.Components.Controls.TextBoxMarginCustomise
    Private comboBox3Icon As vbAccelerator.Components.Controls.TextBoxMarginCustomise
    Private comboBox4Icon As vbAccelerator.Components.Controls.TextBoxMarginCustomise


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents checkBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents checkBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents comboBox4 As System.Windows.Forms.ComboBox
    Friend WithEvents textBox4 As System.Windows.Forms.TextBox
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents ilsIcons As System.Windows.Forms.ImageList
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents comboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents textBox3 As System.Windows.Forms.TextBox
    Friend WithEvents comboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents textBox2 As System.Windows.Forms.TextBox
    Friend WithEvents comboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmTextComboIconDemo))
        Me.checkBox2 = New System.Windows.Forms.CheckBox()
        Me.checkBox1 = New System.Windows.Forms.CheckBox()
        Me.label4 = New System.Windows.Forms.Label()
        Me.comboBox4 = New System.Windows.Forms.ComboBox()
        Me.textBox4 = New System.Windows.Forms.TextBox()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.ilsIcons = New System.Windows.Forms.ImageList(Me.components)
        Me.label2 = New System.Windows.Forms.Label()
        Me.comboBox3 = New System.Windows.Forms.ComboBox()
        Me.textBox3 = New System.Windows.Forms.TextBox()
        Me.comboBox2 = New System.Windows.Forms.ComboBox()
        Me.textBox2 = New System.Windows.Forms.TextBox()
        Me.comboBox1 = New System.Windows.Forms.ComboBox()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'checkBox2
        '
        Me.checkBox2.BackColor = System.Drawing.SystemColors.Window
        Me.checkBox2.Checked = True
        Me.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkBox2.Location = New System.Drawing.Point(200, 324)
        Me.checkBox2.Name = "checkBox2"
        Me.checkBox2.Size = New System.Drawing.Size(12, 16)
        Me.checkBox2.TabIndex = 24
        '
        'checkBox1
        '
        Me.checkBox1.BackColor = System.Drawing.SystemColors.Window
        Me.checkBox1.Checked = True
        Me.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkBox1.Location = New System.Drawing.Point(200, 296)
        Me.checkBox1.Name = "checkBox1"
        Me.checkBox1.Size = New System.Drawing.Size(12, 16)
        Me.checkBox1.TabIndex = 23
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(8, 180)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(272, 20)
        Me.label4.TabIndex = 27
        Me.label4.Text = "Colours:"
        '
        'comboBox4
        '
        Me.comboBox4.Location = New System.Drawing.Point(8, 232)
        Me.comboBox4.Name = "comboBox4"
        Me.comboBox4.Size = New System.Drawing.Size(200, 21)
        Me.comboBox4.TabIndex = 26
        Me.comboBox4.Text = "comboBox4"
        '
        'textBox4
        '
        Me.textBox4.Location = New System.Drawing.Point(8, 200)
        Me.textBox4.Name = "textBox4"
        Me.textBox4.Size = New System.Drawing.Size(200, 21)
        Me.textBox4.TabIndex = 25
        Me.textBox4.Text = "textBox4"
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(8, 268)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(272, 20)
        Me.label3.TabIndex = 22
        Me.label3.Text = "Embedded CheckBox controls"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(8, 12)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(272, 20)
        Me.label1.TabIndex = 20
        Me.label1.Text = "Icons, Left-To-Right"
        '
        'ilsIcons
        '
        Me.ilsIcons.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ilsIcons.ImageSize = New System.Drawing.Size(16, 16)
        Me.ilsIcons.ImageStream = CType(resources.GetObject("ilsIcons.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ilsIcons.TransparentColor = System.Drawing.Color.Transparent
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(8, 96)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(272, 20)
        Me.label2.TabIndex = 21
        Me.label2.Text = "Icons, Right-To-Left"
        '
        'comboBox3
        '
        Me.comboBox3.Location = New System.Drawing.Point(8, 320)
        Me.comboBox3.Name = "comboBox3"
        Me.comboBox3.Size = New System.Drawing.Size(200, 21)
        Me.comboBox3.TabIndex = 19
        Me.comboBox3.Text = "comboBox3"
        '
        'textBox3
        '
        Me.textBox3.Location = New System.Drawing.Point(8, 288)
        Me.textBox3.Name = "textBox3"
        Me.textBox3.Size = New System.Drawing.Size(200, 21)
        Me.textBox3.TabIndex = 18
        Me.textBox3.Text = "textBox3"
        '
        'comboBox2
        '
        Me.comboBox2.Location = New System.Drawing.Point(8, 148)
        Me.comboBox2.Name = "comboBox2"
        Me.comboBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.comboBox2.Size = New System.Drawing.Size(200, 21)
        Me.comboBox2.TabIndex = 17
        Me.comboBox2.Text = "comboBox2"
        '
        'textBox2
        '
        Me.textBox2.Location = New System.Drawing.Point(8, 116)
        Me.textBox2.Name = "textBox2"
        Me.textBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.textBox2.Size = New System.Drawing.Size(200, 21)
        Me.textBox2.TabIndex = 16
        Me.textBox2.Text = "textBox2"
        '
        'comboBox1
        '
        Me.comboBox1.Location = New System.Drawing.Point(8, 64)
        Me.comboBox1.Name = "comboBox1"
        Me.comboBox1.Size = New System.Drawing.Size(200, 21)
        Me.comboBox1.TabIndex = 15
        Me.comboBox1.Text = "comboBox1"
        '
        'textBox1
        '
        Me.textBox1.Location = New System.Drawing.Point(8, 32)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(200, 21)
        Me.textBox1.TabIndex = 14
        Me.textBox1.Text = "textBox1"
        '
        'frmTextComboIconDemo
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(304, 366)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.checkBox2, Me.checkBox1, Me.label4, Me.comboBox4, Me.textBox4, Me.label3, Me.label1, Me.label2, Me.comboBox3, Me.textBox3, Me.comboBox2, Me.textBox2, Me.comboBox1, Me.textBox1})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmTextComboIconDemo"
        Me.Text = "Text and ComboBox Margin Customiser Demonstration"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmTextComboIconDemo_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load

        textBox1Icon = New vbAccelerator.Components.Controls.TextBoxMarginCustomise()
        textBox1Icon.ImageList = ilsIcons
        textBox1Icon.Icon = 1
        textBox1Icon.Attach(textBox1)

        comboBox1Icon = New vbAccelerator.Components.Controls.TextBoxMarginCustomise()
        comboBox1Icon.ImageList = ilsIcons
        comboBox1Icon.Icon = 2
        comboBox1Icon.Attach(comboBox1)

        textBox2Icon = New vbAccelerator.Components.Controls.TextBoxMarginCustomise()
        textBox2Icon.ImageList = ilsIcons
        textBox2Icon.Icon = 3
        textBox2Icon.Attach(textBox2)

        comboBox2Icon = New vbAccelerator.Components.Controls.TextBoxMarginCustomise()
        comboBox2Icon.ImageList = ilsIcons
        comboBox2Icon.Icon = 4
        comboBox2Icon.Attach(comboBox2)

        textBox4Icon = New vbAccelerator.Components.Controls.TextBoxMarginCustomise()
        textBox4Icon.CustomPainter = New TextBoxMarginColourPainter(Color.CornflowerBlue)
        textBox4Icon.Attach(textBox4)

        comboBox4Icon = New vbAccelerator.Components.Controls.TextBoxMarginCustomise()
        comboBox4Icon.CustomPainter = New TextBoxMarginColourPainter(Color.Cornsilk)
        comboBox4Icon.Attach(comboBox4)

        textBox3Icon = New vbAccelerator.Components.Controls.TextBoxMarginCustomise()
        textBox3Icon.Control = checkBox1
        textBox3Icon.Attach(textBox3)

        comboBox3Icon = New vbAccelerator.Components.Controls.TextBoxMarginCustomise()
        comboBox3Icon.Control = checkBox2
        comboBox3Icon.Attach(comboBox3)

    End Sub

    Private Sub checkBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkBox1.CheckedChanged
        textBox3.BackColor = IIf(checkBox1.Checked, Color.FromKnownColor(KnownColor.Window), Color.FromKnownColor(KnownColor.Window))
        textBox3.Enabled = checkBox1.Checked
    End Sub


    Private Sub checkBox2_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles checkBox2.CheckedChanged
        comboBox3.BackColor = IIf(checkBox2.Checked, Color.FromKnownColor(KnownColor.Window), Color.FromKnownColor(KnownColor.Window))
        comboBox3.Enabled = checkBox2.Checked
    End Sub
End Class
