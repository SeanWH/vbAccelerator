Public Class frmFlatCombo
    Inherits System.Windows.Forms.Form

    Private flatComboBoxList As ArrayList = New ArrayList()

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents chkEnabled As System.Windows.Forms.CheckBox
    Friend WithEvents llblInfo5 As System.Windows.Forms.Label
    Friend WithEvents cboSize As System.Windows.Forms.ComboBox
    Friend WithEvents lblInfo4 As System.Windows.Forms.Label
    Friend WithEvents lblInfo3 As System.Windows.Forms.Label
    Friend WithEvents lblInfo2 As System.Windows.Forms.Label
    Friend WithEvents lblInfo1 As System.Windows.Forms.Label
    Friend WithEvents comboBox4 As System.Windows.Forms.ComboBox
    Friend WithEvents comboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents comboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents comboBox1 As System.Windows.Forms.ComboBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmFlatCombo))
        Me.chkEnabled = New System.Windows.Forms.CheckBox()
        Me.llblInfo5 = New System.Windows.Forms.Label()
        Me.cboSize = New System.Windows.Forms.ComboBox()
        Me.lblInfo4 = New System.Windows.Forms.Label()
        Me.lblInfo3 = New System.Windows.Forms.Label()
        Me.lblInfo2 = New System.Windows.Forms.Label()
        Me.lblInfo1 = New System.Windows.Forms.Label()
        Me.comboBox4 = New System.Windows.Forms.ComboBox()
        Me.comboBox3 = New System.Windows.Forms.ComboBox()
        Me.comboBox2 = New System.Windows.Forms.ComboBox()
        Me.comboBox1 = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'chkEnabled
        '
        Me.chkEnabled.Checked = True
        Me.chkEnabled.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkEnabled.Location = New System.Drawing.Point(8, 237)
        Me.chkEnabled.Name = "chkEnabled"
        Me.chkEnabled.Size = New System.Drawing.Size(212, 20)
        Me.chkEnabled.TabIndex = 21
        Me.chkEnabled.Text = "E&nabled"
        '
        'llblInfo5
        '
        Me.llblInfo5.Location = New System.Drawing.Point(240, 9)
        Me.llblInfo5.Name = "llblInfo5"
        Me.llblInfo5.Size = New System.Drawing.Size(60, 16)
        Me.llblInfo5.TabIndex = 20
        Me.llblInfo5.Text = "Narrow"
        '
        'cboSize
        '
        Me.cboSize.Items.AddRange(New Object() {"8", "9", "10", "10.5", "11", "12", "14", "16", "18", "20", "22", "24", "26", "28", "36", "48", "72"})
        Me.cboSize.Location = New System.Drawing.Point(240, 29)
        Me.cboSize.Name = "cboSize"
        Me.cboSize.Size = New System.Drawing.Size(44, 21)
        Me.cboSize.TabIndex = 19
        Me.cboSize.Text = "8"
        '
        'lblInfo4
        '
        Me.lblInfo4.Location = New System.Drawing.Point(8, 165)
        Me.lblInfo4.Name = "lblInfo4"
        Me.lblInfo4.Size = New System.Drawing.Size(212, 16)
        Me.lblInfo4.TabIndex = 18
        Me.lblInfo4.Text = "Right-To-Left, Larger Font"
        '
        'lblInfo3
        '
        Me.lblInfo3.Location = New System.Drawing.Point(8, 113)
        Me.lblInfo3.Name = "lblInfo3"
        Me.lblInfo3.Size = New System.Drawing.Size(212, 16)
        Me.lblInfo3.TabIndex = 17
        Me.lblInfo3.Text = "Disabled Combo Box"
        '
        'lblInfo2
        '
        Me.lblInfo2.Location = New System.Drawing.Point(8, 61)
        Me.lblInfo2.Name = "lblInfo2"
        Me.lblInfo2.Size = New System.Drawing.Size(212, 16)
        Me.lblInfo2.TabIndex = 16
        Me.lblInfo2.Text = "Drop-Down List"
        '
        'lblInfo1
        '
        Me.lblInfo1.Location = New System.Drawing.Point(8, 9)
        Me.lblInfo1.Name = "lblInfo1"
        Me.lblInfo1.Size = New System.Drawing.Size(212, 16)
        Me.lblInfo1.TabIndex = 15
        Me.lblInfo1.Text = "Drop-Down Combo"
        '
        'comboBox4
        '
        Me.comboBox4.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.comboBox4.Items.AddRange(New Object() {"Test Item 1", "Test Item 2", "Test Item 3", "Test Item 4", "Test Item 5", "Test Item 6", "Test Item 7", "Test Item 8", "Test Item 9", "Test Item 10", "Test Item 11", "Test Item 12", "Test Item 13", "Test Item 14"})
        Me.comboBox4.Location = New System.Drawing.Point(8, 185)
        Me.comboBox4.Name = "comboBox4"
        Me.comboBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.comboBox4.Size = New System.Drawing.Size(212, 33)
        Me.comboBox4.TabIndex = 14
        Me.comboBox4.Text = "comboBox4"
        '
        'comboBox3
        '
        Me.comboBox3.BackColor = System.Drawing.SystemColors.Control
        Me.comboBox3.Enabled = False
        Me.comboBox3.Items.AddRange(New Object() {"Test Item 1", "Test Item 2", "Test Item 3", "Test Item 4", "Test Item 5", "Test Item 6", "Test Item 7", "Test Item 8", "Test Item 9", "Test Item 10", "Test Item 11", "Test Item 12", "Test Item 13", "Test Item 14"})
        Me.comboBox3.Location = New System.Drawing.Point(8, 133)
        Me.comboBox3.Name = "comboBox3"
        Me.comboBox3.Size = New System.Drawing.Size(212, 21)
        Me.comboBox3.TabIndex = 13
        Me.comboBox3.Text = "comboBox3"
        '
        'comboBox2
        '
        Me.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBox2.Items.AddRange(New Object() {"Test Item 1", "Test Item 2", "Test Item 3", "Test Item 4", "Test Item 5", "Test Item 6", "Test Item 7", "Test Item 8", "Test Item 9", "Test Item 10", "Test Item 11", "Test Item 12", "Test Item 13", "Test Item 14"})
        Me.comboBox2.Location = New System.Drawing.Point(8, 81)
        Me.comboBox2.Name = "comboBox2"
        Me.comboBox2.Size = New System.Drawing.Size(212, 21)
        Me.comboBox2.TabIndex = 12
        '
        'comboBox1
        '
        Me.comboBox1.Items.AddRange(New Object() {"Test Item 1", "Test Item 2", "Test Item 3", "Test Item 4", "Test Item 5", "Test Item 6", "Test Item 7", "Test Item 8", "Test Item 9", "Test Item 10", "Test Item 11", "Test Item 12", "Test Item 13", "Test Item 14"})
        Me.comboBox1.Location = New System.Drawing.Point(8, 29)
        Me.comboBox1.Name = "comboBox1"
        Me.comboBox1.Size = New System.Drawing.Size(212, 21)
        Me.comboBox1.TabIndex = 11
        Me.comboBox1.Text = "vbAccelerator"
        '
        'frmFlatCombo
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(304, 270)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.chkEnabled, Me.llblInfo5, Me.cboSize, Me.lblInfo4, Me.lblInfo3, Me.lblInfo2, Me.lblInfo1, Me.comboBox4, Me.comboBox3, Me.comboBox2, Me.comboBox1})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmFlatCombo"
        Me.Text = "vbAccelerator .NET Flat Combo Box Demonstration"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmFlatCombo_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim flatComboBox As vbAccelerator.Components.Controls.FlatControl
        Dim ctl As Control
        For Each ctl In Me.Controls
            If (ctl.GetType().IsAssignableFrom(comboBox1.GetType())) Then
                flatComboBox = New vbAccelerator.Components.Controls.FlatControl()
                flatComboBox.Attach(ctl)
                flatComboBoxList.Add(flatComboBox)
            End If
        Next
    End Sub

    Private Sub chkEnabled_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkEnabled.CheckedChanged
        Dim ctl As Control
        Dim enabled As Boolean
        enabled = chkEnabled.Checked
        For Each ctl In Me.Controls
            If (ctl.GetType().IsAssignableFrom(comboBox1.GetType())) Then
                If (Not (enabled)) Then
                    ctl.BackColor = Color.FromKnownColor(KnownColor.Control)
                End If
                ctl.Enabled = enabled
                If (enabled) Then
                    ctl.BackColor = Color.FromKnownColor(KnownColor.Window)
                End If
            End If
        Next

    End Sub
End Class
