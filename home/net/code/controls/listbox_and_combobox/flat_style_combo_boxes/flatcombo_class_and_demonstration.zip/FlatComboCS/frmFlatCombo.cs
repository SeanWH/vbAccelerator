using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using vbAccelerator.Components.Controls;

namespace FlatComboCS
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmFlatCombo : System.Windows.Forms.Form
	{
		private ArrayList flatComboBoxList = new ArrayList();
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.ComboBox comboBox2;
		private System.Windows.Forms.ComboBox comboBox3;
		private System.Windows.Forms.ComboBox comboBox4;
		private System.Windows.Forms.Label lblInfo1;
		private System.Windows.Forms.Label lblInfo2;
		private System.Windows.Forms.Label lblInfo3;
		private System.Windows.Forms.Label lblInfo4;
		private System.Windows.Forms.ComboBox cboSize;
		private System.Windows.Forms.Label llblInfo5;
		private System.Windows.Forms.CheckBox chkEnabled;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmFlatCombo()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFlatCombo));
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.comboBox2 = new System.Windows.Forms.ComboBox();
			this.comboBox3 = new System.Windows.Forms.ComboBox();
			this.comboBox4 = new System.Windows.Forms.ComboBox();
			this.lblInfo1 = new System.Windows.Forms.Label();
			this.lblInfo2 = new System.Windows.Forms.Label();
			this.lblInfo3 = new System.Windows.Forms.Label();
			this.lblInfo4 = new System.Windows.Forms.Label();
			this.cboSize = new System.Windows.Forms.ComboBox();
			this.llblInfo5 = new System.Windows.Forms.Label();
			this.chkEnabled = new System.Windows.Forms.CheckBox();
			this.SuspendLayout();
			// 
			// comboBox1
			// 
			this.comboBox1.Items.AddRange(new object[] {
														   "Test Item 1",
														   "Test Item 2",
														   "Test Item 3",
														   "Test Item 4",
														   "Test Item 5",
														   "Test Item 6",
														   "Test Item 7",
														   "Test Item 8",
														   "Test Item 9",
														   "Test Item 10",
														   "Test Item 11",
														   "Test Item 12",
														   "Test Item 13",
														   "Test Item 14"});
			this.comboBox1.Location = new System.Drawing.Point(12, 28);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(212, 21);
			this.comboBox1.TabIndex = 0;
			this.comboBox1.Text = "vbAccelerator";
			// 
			// comboBox2
			// 
			this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox2.Items.AddRange(new object[] {
														   "Test Item 1",
														   "Test Item 2",
														   "Test Item 3",
														   "Test Item 4",
														   "Test Item 5",
														   "Test Item 6",
														   "Test Item 7",
														   "Test Item 8",
														   "Test Item 9",
														   "Test Item 10",
														   "Test Item 11",
														   "Test Item 12",
														   "Test Item 13",
														   "Test Item 14"});
			this.comboBox2.Location = new System.Drawing.Point(12, 80);
			this.comboBox2.Name = "comboBox2";
			this.comboBox2.Size = new System.Drawing.Size(212, 21);
			this.comboBox2.TabIndex = 1;
			// 
			// comboBox3
			// 
			this.comboBox3.BackColor = System.Drawing.SystemColors.Control;
			this.comboBox3.Enabled = false;
			this.comboBox3.Items.AddRange(new object[] {
														   "Test Item 1",
														   "Test Item 2",
														   "Test Item 3",
														   "Test Item 4",
														   "Test Item 5",
														   "Test Item 6",
														   "Test Item 7",
														   "Test Item 8",
														   "Test Item 9",
														   "Test Item 10",
														   "Test Item 11",
														   "Test Item 12",
														   "Test Item 13",
														   "Test Item 14"});
			this.comboBox3.Location = new System.Drawing.Point(12, 132);
			this.comboBox3.Name = "comboBox3";
			this.comboBox3.Size = new System.Drawing.Size(212, 21);
			this.comboBox3.TabIndex = 2;
			this.comboBox3.Text = "comboBox3";
			// 
			// comboBox4
			// 
			this.comboBox4.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBox4.Items.AddRange(new object[] {
														   "Test Item 1",
														   "Test Item 2",
														   "Test Item 3",
														   "Test Item 4",
														   "Test Item 5",
														   "Test Item 6",
														   "Test Item 7",
														   "Test Item 8",
														   "Test Item 9",
														   "Test Item 10",
														   "Test Item 11",
														   "Test Item 12",
														   "Test Item 13",
														   "Test Item 14"});
			this.comboBox4.Location = new System.Drawing.Point(12, 184);
			this.comboBox4.Name = "comboBox4";
			this.comboBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.comboBox4.Size = new System.Drawing.Size(212, 33);
			this.comboBox4.TabIndex = 3;
			this.comboBox4.Text = "comboBox4";
			// 
			// lblInfo1
			// 
			this.lblInfo1.Location = new System.Drawing.Point(12, 8);
			this.lblInfo1.Name = "lblInfo1";
			this.lblInfo1.Size = new System.Drawing.Size(212, 16);
			this.lblInfo1.TabIndex = 4;
			this.lblInfo1.Text = "Drop-Down Combo";
			// 
			// lblInfo2
			// 
			this.lblInfo2.Location = new System.Drawing.Point(12, 60);
			this.lblInfo2.Name = "lblInfo2";
			this.lblInfo2.Size = new System.Drawing.Size(212, 16);
			this.lblInfo2.TabIndex = 5;
			this.lblInfo2.Text = "Drop-Down List";
			// 
			// lblInfo3
			// 
			this.lblInfo3.Location = new System.Drawing.Point(12, 112);
			this.lblInfo3.Name = "lblInfo3";
			this.lblInfo3.Size = new System.Drawing.Size(212, 16);
			this.lblInfo3.TabIndex = 6;
			this.lblInfo3.Text = "Disabled Combo Box";
			// 
			// lblInfo4
			// 
			this.lblInfo4.Location = new System.Drawing.Point(12, 164);
			this.lblInfo4.Name = "lblInfo4";
			this.lblInfo4.Size = new System.Drawing.Size(212, 16);
			this.lblInfo4.TabIndex = 7;
			this.lblInfo4.Text = "Right-To-Left, Larger Font";
			// 
			// cboSize
			// 
			this.cboSize.Items.AddRange(new object[] {
														 "8",
														 "9",
														 "10",
														 "10.5",
														 "11",
														 "12",
														 "14",
														 "16",
														 "18",
														 "20",
														 "22",
														 "24",
														 "26",
														 "28",
														 "36",
														 "48",
														 "72"});
			this.cboSize.Location = new System.Drawing.Point(244, 28);
			this.cboSize.Name = "cboSize";
			this.cboSize.Size = new System.Drawing.Size(44, 21);
			this.cboSize.TabIndex = 8;
			this.cboSize.Text = "8";
			// 
			// llblInfo5
			// 
			this.llblInfo5.Location = new System.Drawing.Point(244, 8);
			this.llblInfo5.Name = "llblInfo5";
			this.llblInfo5.Size = new System.Drawing.Size(60, 16);
			this.llblInfo5.TabIndex = 9;
			this.llblInfo5.Text = "Narrow";
			// 
			// chkEnabled
			// 
			this.chkEnabled.Checked = true;
			this.chkEnabled.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkEnabled.Location = new System.Drawing.Point(12, 236);
			this.chkEnabled.Name = "chkEnabled";
			this.chkEnabled.Size = new System.Drawing.Size(212, 20);
			this.chkEnabled.TabIndex = 10;
			this.chkEnabled.Text = "E&nabled";
			this.chkEnabled.CheckedChanged += new System.EventHandler(this.chkEnabled_CheckedChanged);
			// 
			// frmFlatCombo
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(312, 270);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.chkEnabled,
																		  this.llblInfo5,
																		  this.cboSize,
																		  this.lblInfo4,
																		  this.lblInfo3,
																		  this.lblInfo2,
																		  this.lblInfo1,
																		  this.comboBox4,
																		  this.comboBox3,
																		  this.comboBox2,
																		  this.comboBox1});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmFlatCombo";
			this.Text = ".NET Flat Combo Box Demonstration";
			this.Load += new System.EventHandler(this.frmFlatCombo_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmFlatCombo());
		}

		private void frmFlatCombo_Load(object sender, System.EventArgs e)
		{
			FlatControl flatComboBox;
			foreach (Control ctl in this.Controls)
			{
				if (ctl.GetType().IsAssignableFrom(comboBox1.GetType()))
				{
					flatComboBox = new FlatControl();
					flatComboBox.Attach(ctl);
					flatComboBoxList.Add(flatComboBox);
				}
			}
		}

		private void chkEnabled_CheckedChanged(object sender, System.EventArgs e)
		{
			bool enabled = chkEnabled.Checked;
			foreach (Control ctl in this.Controls)
			{
				if (ctl.GetType().IsAssignableFrom(comboBox1.GetType()))
				{
					if (!enabled)
					{
						ctl.BackColor = Color.FromKnownColor(KnownColor.Control);
					}
					ctl.Enabled = enabled;
					if (enabled)
					{
						ctl.BackColor = Color.FromKnownColor(KnownColor.Window);
					}
				}
			}
		
		}
	}
}
