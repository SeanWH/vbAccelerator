using System;
using System.Collections;

namespace vbAccelerator.Components.Collections
{
	/// <summary>
	/// A basic Most-Recently Used (MRU) Queue implementation
	/// </summary>
	[SerializableAttribute()]
	public class MRUQueue : ICloneable, ICollection, IEnumerable
	{
		private const int INITIAL_SIZE = 8;

		/// <summary>
		/// The ArrayList used to maintain the MRU queue
		/// </summary>
		protected ArrayList innerList;
		private int size = INITIAL_SIZE;

		/// <summary>
		/// Gets/sets the maximum size of the MRU Queue.
		/// </summary>
		public int Size
		{
			get
			{
				return this.size;
			}
			set
			{
				if (value <= 0)
				{
					throw new ArgumentException("Size must be greater than or equal to 1", "value");
				}
				this.size = value;
				OnSizeChanged();
			}
		}

		/// <summary>
		/// Trims the MRU list to size based on the setting
		/// of the <see cref="Size" /> property.
		/// </summary>
		protected virtual void OnSizeChanged()
		{
			if (innerList.Count > size)
			{
				for (int i = size; i < innerList.Count; i++)
				{
					innerList.RemoveAt(innerList.Count - 1);
				}
			}
		}

		/// <summary>
		/// Copies the contents of the MRU starting at the specified
		/// index to an array.
		/// </summary>
		/// <param name="array">Array to copy contents to</param>
		/// <param name="arrayIndex">Index of array to start at.</param>
		public virtual void CopyTo(Array array, int arrayIndex)
		{
			this.innerList.CopyTo(array, arrayIndex);
		}

		/// <summary>
		/// Gets the object with the specified index.
		/// </summary>
		public virtual object this[int index]
		{
			get
			{
				return innerList[index];
			}
		}

		/// <summary>
		/// Adds the specified item to the MRU queue.  If the queue
		/// already contains the specified item, it is shifted up
		/// to the first position.  Otherwise, it is added at the
		/// first position and any existing items are shuffled 
		/// downwards and the <see cref="OnSizeChanged"/> method
		/// is called to trim the collection to size.
		/// </summary>
		/// <param name="item">Item to add</param>
		public virtual void Add(object item)
		{
			bool noSizeChange = false;
			if (this.innerList.Contains(item))
			{
				innerList.Remove(item);
				noSizeChange = true;
			}
			this.innerList.Insert(0, item);			
			if (!noSizeChange)
			{
				OnSizeChanged();
			}
		}

		/// <summary>
		/// Clears the MRU cache.
		/// </summary>
		public virtual void Clear()
		{
			OnClear();
		}

		/// <summary>
		/// Called to clear the collection of contents.
		/// </summary>
		protected virtual void OnClear()
		{
			this.innerList.Clear();
		}

		/// <summary>
		/// Gets the number of items currently in the MRU Queue.
		/// </summary>
		public virtual int Count
		{
			get
			{
				return innerList.Count;
			}
		}

		/// <summary>
		/// Gets whether this implementation is synchronized or not.
		/// </summary>
		public virtual bool IsSynchronized
		{
			get
			{
				return innerList.IsSynchronized;
			}
		}

		/// <summary>
		/// Gets an object that can be used to synchronize access to the 
		/// <see cref="MRUQueue"/>.
		/// </summary>
		public virtual object SyncRoot
		{
			get
			{
				return innerList.SyncRoot;
			}
		}

		/// <summary>
		/// Gets the object that allows iterating through the members of the collection.
		/// </summary>
		/// <returns>An object that implements the <see cref="System.Collections.IEnumerator "/> interface.</returns>
		public virtual IEnumerator GetEnumerator()
		{
			return innerList.GetEnumerator();
		}

		/// <summary>
		/// Creates a shallow copy of the System.Collections.Hashtable.
		/// </summary>
		/// <returns>A shallow copy of the <see cref="MRUQueue"/>.</returns>
		public virtual object Clone()
		{
			ArrayList arrayList = (ArrayList) innerList.Clone();
			MRUQueue mruQueue = new MRUQueue(arrayList);
			return (object) mruQueue;
		}


		/// <summary>
		/// Constructs a new <see cref="MRUQueue"/> using the specified <see cref="ArrayList"/> as the
		/// internal collection.
		/// </summary>
		/// <param name="arrayList">ArrayList to use as the internal collection.</param>
		protected MRUQueue(ArrayList arrayList)
		{
			this.innerList = arrayList;
		}

		/// <summary>
		/// Constructs a new instance of this collection
		/// </summary>
		public MRUQueue()
		{
			innerList = new ArrayList();
		}
	}
}
