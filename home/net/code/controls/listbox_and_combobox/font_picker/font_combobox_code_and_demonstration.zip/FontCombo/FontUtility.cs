using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace vbAccelerator.Components.Text
{
	/*
	/// <summary>
	/// Windows API Logical Font structure to represent information
	/// about a font.
	/// </summary>
	[StructLayout(LayoutKind.Sequential)]
	public struct LOGFONT 
	{ 
		/// <summary>
		/// Height of the font.
		/// </summary>
		public int lfHeight; 		
		public int lfWidth; 
		public int lfEscapement; 
		public int lfOrientation; 
		public int lfWeight; 
		public byte lfItalic; 
		public byte lfUnderline; 
		public byte lfStrikeOut; 
		public byte lfCharSet; 
		public byte lfOutPrecision; 
		public byte lfClipPrecision; 
		public byte lfQuality; 
		public byte lfPitchAndFamily;
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)]
		public string lfFaceName; 
	}
	*/

	/// <summary>
	/// Summary description for FontUtility.
	/// </summary>
	public class FontUtility
	{
		/*
		[StructLayout(LayoutKind.Sequential)]
		private struct TEXTMETRIC 
		{ 
			public int tmHeight; 
			public int tmAscent; 
			public int tmDescent; 
			public int tmInternalLeading; 
			public int tmExternalLeading; 
			public int tmAveCharWidth; 
			public int tmMaxCharWidth; 
			public int tmWeight; 
			public int tmOverhang; 
			public int tmDigitizedAspectX; 
			public int tmDigitizedAspectY; 
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst=1)]
			public String tmFirstChar; 
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst=1)]
			public String tmLastChar; 
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst=1)]
			public String tmDefaultChar; 
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst=1)]
			public String tmBreakChar; 
			public byte tmItalic; 
			public byte tmUnderlined; 
			public byte tmStruckOut; 
			public byte tmPitchAndFamily; 
			public byte tmCharSet; 
		}
		*/


		/*
		[DllImport("gdi32")]
		private static extern int GetTextMetrics(
			IntPtr hdc,            // handle to DC
			ref TEXTMETRIC lptm   // text metrics
			);
		*/
		[DllImport("gdi32", CharSet = CharSet.Ansi)]
		private static extern int GetOutlineTextMetrics(
			IntPtr hdc,				// handle to DC
			int cbData,				// size in bytes for text metrics
			IntPtr lpOtm			// pointer to buffer to receive outline text metrics structure
			);
		[DllImport("gdi32")]
		private static extern IntPtr SelectObject(
			IntPtr hdc,
			IntPtr hObj
			);

		/// <summary>
		/// Enumeration of Panose Font Family Types.  These can be used for
		/// determining the similarity of two fonts or for detecting non-character
		/// fonts like WingDings.
		/// </summary>
		public enum PanoseFontFamilyTypes : int
		{
			/// <summary>
			///  Any
			/// </summary>
			PAN_ANY = 0,
			/// <summary>
			/// No Fit
			/// </summary>
			PAN_NO_FIT = 1,
			/// <summary>
			/// Text and Display
			/// </summary>
			PAN_FAMILY_TEXT_DISPLAY = 2,
			/// <summary>
			/// Script
			/// </summary>
			PAN_FAMILY_SCRIPT = 3,
			/// <summary>
			/// Decorative
			/// </summary>
			PAN_FAMILY_DECORATIVE = 4,
			/// <summary>
			/// Pictorial                      
			/// </summary>
			PAN_FAMILY_PICTORIAL = 5
		}

		/*
		/// <summary>
		/// Enumeration of Font Family types available from the LogFont structure.
		/// Font family types describe the look of a font in a general way. They are 
		/// intended for specifying fonts when the exact typeface desired is not available. 
		/// </summary>
		public enum FontFamilyTypes : int
		{
			/// <summary>
			/// Don't care or don't know.
			/// </summary>
			FF_DONTCARE        = (0<<4),
			/// <summary>
			/// Variable stroke width, serifed.
			/// Times Roman, Century Schoolbook, etc.
			/// </summary>
			FF_ROMAN           = (1<<4),
			/// <summary>
			/// Variable stroke width, sans-serifed.
			/// Helvetica, Swiss, etc. 
			/// </summary>
			FF_SWISS           = (2<<4),
			/// <summary>
			/// Constant stroke width, serifed or sans-serifed.
			/// Pica, Elite, Courier, etc.
			/// </summary>
			FF_MODERN          = (3<<4),
			/// <summary>
			/// Cursive, etc.
			/// </summary>
			FF_SCRIPT           = (4<<4),
			/// <summary>
			/// Old English, etc.
			/// </summary>
			FF_DECORATIVE       = (5<<4)  
		}

		/// <summary>
		/// Enumeration of font pitches.
		/// </summary>
		public enum FontPitches : int
		{
			/// <summary>
			/// Pitch is not specified
			/// </summary>
			DEFAULT_PITCH           = 0,
			/// <summary>
			/// The font has fixed size characters
			/// </summary>
			FIXED_PITCH             = 1,
			/// <summary>
			/// The font has variable size characters
			/// </summary>
			VARIABLE_PITCH          = 2
		}
		

		public static LOGFONT LogFontOf(Font font)
		{
			object logFontObject = new LOGFONT();
			font.ToLogFont(logFontObject);
			LOGFONT logFont = (LOGFONT) logFontObject;
			Console.WriteLine("{0:X2}", logFont.lfPitchAndFamily);
			return logFont;
		}
		*/

		/// <summary>
		/// Gets the <see cref="PanoseFontFamilyTypes"/> for the specified font.
		/// </summary>
		/// <param name="graphics">A graphics object to use when detecting the Panose
		/// family.</param>
		/// <param name="font">The font to check.</param>
		/// <returns>The Panose font family type.</returns>
		public static PanoseFontFamilyTypes PanoseFontFamilyType(Graphics graphics, Font font)
		{
			byte bFamilyType = 0;

			IntPtr hdc = graphics.GetHdc();
			IntPtr hFontOld = SelectObject(hdc, font.ToHfont());

			int bufSize = GetOutlineTextMetrics(hdc, 0, IntPtr.Zero);
			IntPtr lpOtm = Marshal.AllocCoTaskMem(bufSize);
			Marshal.WriteInt32(lpOtm, bufSize);			
			int success = GetOutlineTextMetrics(hdc, bufSize, lpOtm);
			if (success != 0)
			{
				int offset = 61;
				bFamilyType = Marshal.ReadByte(lpOtm, offset); 
				/*
				byte bSerifStyle = Marshal.ReadByte(lpOtm, offset + 1); 
				byte bWeight = Marshal.ReadByte(lpOtm, offset + 2); 
				byte bProportion = Marshal.ReadByte(lpOtm, offset + 3); 
				byte bContrast = Marshal.ReadByte(lpOtm, offset + 4); 
				byte bStrokeVariation = Marshal.ReadByte(lpOtm, offset + 5); 
				byte bArmStyle = Marshal.ReadByte(lpOtm, offset + 6); 
				byte bLetterform = Marshal.ReadByte(lpOtm, offset + 7); 
				byte bMidline = Marshal.ReadByte(lpOtm, offset + 8); 
				byte bXHeight = Marshal.ReadByte(lpOtm, offset + 9); 
				*/
			}

			Marshal.FreeCoTaskMem(lpOtm);

			SelectObject(hdc, hFontOld);
			graphics.ReleaseHdc(hdc);
				
			return (PanoseFontFamilyTypes) bFamilyType;
			
		}

		private FontUtility()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
