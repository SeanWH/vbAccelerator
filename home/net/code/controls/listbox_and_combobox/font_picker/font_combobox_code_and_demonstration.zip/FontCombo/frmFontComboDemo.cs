using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;

using System.Runtime.InteropServices;

using vbAccelerator.Components.Controls;

namespace FontCombo
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmFontComboDemo : System.Windows.Forms.Form
	{
		#region RichEdit Unmanaged Code
		private const int WM_SETREDRAW              = 0x000B;
		private const int WM_USER					= 0x400;
		private const int EM_GETEVENTMASK			= (WM_USER + 59);
		private const int EM_SETEVENTMASK			= (WM_USER + 69);

		[DllImport("user32", CharSet = CharSet.Auto)]
		private extern static IntPtr SendMessage(IntPtr hWnd, int msg, int wParam, IntPtr lParam);

		#endregion



		private bool interlock = false;
		private System.Windows.Forms.RichTextBox richTextBox1;
		private vbAccelerator.Components.Controls.FontComboBox cboFonts;
		private vbAccelerator.Components.Controls.IconComboBox cboSize;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmFontComboDemo()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// Set up the font and sizing combos:
			cboFonts.SelectedIndexChanged += new EventHandler(cboFonts_SelectedIndexChanged);
			cboFonts.CloseUp += new EventHandler(cboFonts_CloseUp);
			
			string[] sizes = new string[] {"8", "9", "10", "10.5", "11", "12", "14", "16", "18", "20", "22", "24", "26", "28", "36", "48", "72" };
			foreach (string size in sizes)
			{
				IconComboItem sizeItem = new IconComboItem();
				sizeItem.Text = size;
				cboSize.Items.Add(sizeItem);
			}
			cboSize.Text = String.Format("{0:0}", richTextBox1.Font.Size);
			cboSize.SelectedIndexChanged += new EventHandler(cboSize_SelectedIndexChanged);
			cboSize.CloseUp += new EventHandler(cboSize_CloseUp);

			richTextBox1.SelectionChanged += new EventHandler(richTextBox1_SelectionChanged);

			// respond to form resize events;
			this.SizeChanged += new EventHandler(frmFontComboDemo_SizeChanged);

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFontComboDemo));
			this.cboFonts = new vbAccelerator.Components.Controls.FontComboBox();
			this.richTextBox1 = new System.Windows.Forms.RichTextBox();
			this.cboSize = new vbAccelerator.Components.Controls.IconComboBox();
			this.SuspendLayout();
			// 
			// cboFonts
			// 
			this.cboFonts.AutoComplete = true;
			this.cboFonts.BorderStyle = vbAccelerator.Components.Controls.IconComboBox.DrawingStyle.Office10;
			this.cboFonts.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
			this.cboFonts.DropDownWidth = 300;
			this.cboFonts.FullRowSelect = true;
			this.cboFonts.GridLines = false;
			this.cboFonts.HighlightStyle = vbAccelerator.Components.Controls.IconComboBox.DrawingStyle.Office10;
			this.cboFonts.ImageList = null;
			this.cboFonts.IndentationSize = 16;
			this.cboFonts.Location = new System.Drawing.Point(8, 8);
			this.cboFonts.MaxDropDownItems = 16;
			this.cboFonts.Name = "cboFonts";
			this.cboFonts.Size = new System.Drawing.Size(136, 22);
			this.cboFonts.TabIndex = 1;
			this.cboFonts.TextBoxIcon = false;
			this.cboFonts.Populated += new System.EventHandler(this.cboFonts_Populated);
			// 
			// richTextBox1
			// 
			this.richTextBox1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.richTextBox1.HideSelection = false;
			this.richTextBox1.Location = new System.Drawing.Point(8, 36);
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.Size = new System.Drawing.Size(504, 296);
			this.richTextBox1.TabIndex = 0;
			this.richTextBox1.Text = "richTextBox1";
			// 
			// cboSize
			// 
			this.cboSize.AutoComplete = true;
			this.cboSize.BorderStyle = vbAccelerator.Components.Controls.IconComboBox.DrawingStyle.Office10;
			this.cboSize.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
			this.cboSize.FullRowSelect = true;
			this.cboSize.GridLines = false;
			this.cboSize.HighlightStyle = vbAccelerator.Components.Controls.IconComboBox.DrawingStyle.Office10;
			this.cboSize.ImageList = null;
			this.cboSize.IndentationSize = 16;
			this.cboSize.Location = new System.Drawing.Point(152, 8);
			this.cboSize.MaxDropDownItems = 16;
			this.cboSize.Name = "cboSize";
			this.cboSize.Size = new System.Drawing.Size(44, 22);
			this.cboSize.TabIndex = 2;
			this.cboSize.TextBoxIcon = false;
			// 
			// frmFontComboDemo
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(524, 346);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.cboSize,
																		  this.richTextBox1,
																		  this.cboFonts});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmFontComboDemo";
			this.Text = "vbAccelerator Font Combo Demonstration";
			this.Load += new System.EventHandler(this.frmFontComboDemo_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmFontComboDemo());
		}

		private void frmFontComboDemo_SizeChanged(object sender, EventArgs e)
		{
			this.richTextBox1.Size = new Size(
				this.ClientRectangle.Width - this.richTextBox1.Left * 2,
				this.ClientRectangle.Height - this.richTextBox1.Top - this.richTextBox1.Left);
		}

		private void richTextBox1_SelectionChanged(object sender, EventArgs e)
		{
			if (!interlock)
			{
				interlock = true;

				Font selectedFont = richTextBox1.SelectionFont;
				
				if (selectedFont == null) // more than one font selected
				{
					cboFonts.SelectedIndex = -1;
					cboFonts.Text = "";
					cboSize.Text = "";
				}
				else
				{
					cboSize.Text = String.Format("{0:#0}", selectedFont.Size);
					Console.WriteLine(selectedFont.Size);
					int index = cboFonts.FindStringExact(selectedFont.Name);
					if (index > -1)
					{
						cboFonts.SelectedIndex = index;
					}
				}

				interlock = false;
			}
		}
		

		private void cboFonts_SelectedIndexChanged(object sender, EventArgs e)
		{			
			if (!cboFonts.DroppedDown)
			{
				setFontFromCombo();
			}
		}

		private void cboFonts_CloseUp(object sender, EventArgs e)
		{
			setFontFromCombo();
		}


		private void cboSize_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (!cboSize.DroppedDown) // whilst combo is dropped we don't change the font
			{
				setSizeFromCombo();
			}
		}

		private void cboSize_CloseUp(object sender, EventArgs e)
		{
			setSizeFromCombo();
		}

		private void cboFonts_Populated(object sender, EventArgs e)
		{
			richTextBox1_SelectionChanged(sender, e);
		}

		private void setFontFromCombo()
		{
			if (!interlock)
			{
				
				interlock = true;
				IconComboItem item = (IconComboItem) cboFonts.SelectedItem;
				Font newSelFont = item.Font;
				if (newSelFont == null) // case for Wingdings etc
				{
					newSelFont = new Font(
						(string) cboFonts.SelectedItem.Text, 8);
				}
				Console.WriteLine("Selected Font Changed {0}", newSelFont.FontFamily);

				float size = richTextBox1.Font.Size;
				bool sizeOk = true;
				try
				{
					size = float.Parse(cboSize.Text);
				}
				catch (System.FormatException)
				{
					sizeOk = false;
				}

				if (sizeOk)
				{
					richTextBox1.SelectionFont = new Font(newSelFont.FontFamily, size, newSelFont.Style);
				}
				else
				{
					// need to parse through the items to 

					// We want to suspend redrawing because we need to select each character in turn
					// to determine its fonts. However, RichTextBox appears to be missing some properties
					// to set these fields:
					richTextBox1.SuspendLayout();
					// Stops RichText redrawing:
					SendMessage(richTextBox1.Handle, WM_SETREDRAW, 0, IntPtr.Zero);
					// Stops RichText sending any events:
					IntPtr eventMask = SendMessage(richTextBox1.Handle, EM_GETEVENTMASK, 0, IntPtr.Zero);
					
					// Ok now we can enumerate through, just setting the size of the font:
					Font lastFont = null;
					Font selectedFont = null;
					int selStart = richTextBox1.SelectionStart;
					int selEnd = richTextBox1.SelectionStart + richTextBox1.SelectionLength;
					int currentStart = selStart;
					int currentSize = 0;
					for (int i = selStart; i < selEnd; i++)
					{
						richTextBox1.Select(i, 1);
						selectedFont = richTextBox1.SelectionFont;
						if (lastFont != null)
						{
							bool newStyle = (selectedFont.Style != lastFont.Style);
							bool newFontSize = (selectedFont.Size != lastFont.Size);
							if (newFontSize || newStyle)
							{
								Font newFont = null;
								try
								{
									newFont = new Font(newSelFont.FontFamily, lastFont.Size, lastFont.Style);
								}
								catch (System.ArgumentException)
								{
									newFont = new Font(newSelFont.FontFamily, lastFont.Size, newSelFont.Style);
								}
								richTextBox1.Select(currentStart, currentSize);
								richTextBox1.SelectionFont = newFont;
								currentStart = i;
								currentSize = 0;
							}
						}
						lastFont = selectedFont;
						currentSize++;
					}
					if (currentSize > 0)
					{
						Font newFont = new Font(newSelFont.FontFamily, lastFont.Size, lastFont.Style);
						richTextBox1.Select(currentStart, currentSize);
						richTextBox1.SelectionFont = newFont;					
					}

					// Turn events back on again:
					SendMessage(richTextBox1.Handle, EM_SETEVENTMASK, 0, eventMask);
					// Select the correct range (we must do this with events on otherwise
					// the scroll state is inconsistent):
					richTextBox1.Select(selStart, selEnd - selStart);
					// Turn redraw back on again:
					SendMessage(richTextBox1.Handle, WM_SETREDRAW, 1, IntPtr.Zero);
					richTextBox1.ResumeLayout();
					// Show changes
					richTextBox1.Invalidate();

				}
				interlock = false;

				// Switch focus to the RichEdit control
				richTextBox1.Focus();
			}			

		}

		private void setSizeFromCombo()
		{
			if (!interlock)
			{
				interlock = true;

				Font selectedFont = richTextBox1.SelectionFont;
				float newSize = float.Parse(cboSize.SelectedItem.ToString());
				
				if (selectedFont != null) // more than one font selected
				{
					Font newFont = new Font(selectedFont.FontFamily, newSize, selectedFont.Style);
					richTextBox1.SelectionFont = newFont;
				}
				else
				{
					// need to enumerate through the selected text, checking each font, and setting
					// the size correctly.

					// We want to suspend redrawing because we need to select each character in turn
					// to determine its fonts. However, RichTextBox appears to be missing some properties
					// to set these fields:
					richTextBox1.SuspendLayout();
					// Stops RichText redrawing:
					SendMessage(richTextBox1.Handle, WM_SETREDRAW, 0, IntPtr.Zero);
					// Stops RichText sending any events:
					IntPtr eventMask = SendMessage(richTextBox1.Handle, EM_GETEVENTMASK, 0, IntPtr.Zero);
					
					// Ok now we can enumerate through, just setting the size of the font:
					Font lastFont = null;
					int selStart = richTextBox1.SelectionStart;
					int selEnd = richTextBox1.SelectionStart + richTextBox1.SelectionLength;
					int currentStart = selStart;
					int currentSize = 0;
					for (int i = selStart; i < selEnd; i++)
					{
						richTextBox1.Select(i, 1);
						selectedFont = richTextBox1.SelectionFont;
						if (lastFont != null)
						{
							bool newFamily = !(selectedFont.FontFamily.Equals(lastFont.FontFamily));
							bool newStyle = (selectedFont.Style != lastFont.Style);
							if (newFamily || newStyle)
							{
								Font newFont = new Font(lastFont.FontFamily, newSize, lastFont.Style);
								richTextBox1.Select(currentStart, currentSize);
								richTextBox1.SelectionFont = newFont;
								currentStart = i;
								currentSize = 0;
							}
						}
						lastFont = selectedFont;
						currentSize++;
					}
					if (currentSize > 0)
					{
						Font newFont = new Font(lastFont.FontFamily, newSize, lastFont.Style);
						richTextBox1.Select(currentStart, currentSize);
						richTextBox1.SelectionFont = newFont;					
					}

					// Turn events back on again:
					SendMessage(richTextBox1.Handle, EM_SETEVENTMASK, 0, eventMask);
					// Select the correct range (we must do this with events on otherwise
					// the scroll state is inconsistent):
					richTextBox1.Select(selStart, selEnd - selStart);
					// Turn redraw back on again:
					SendMessage(richTextBox1.Handle, WM_SETREDRAW, 1, IntPtr.Zero);
					richTextBox1.ResumeLayout();
					
					// Display changes:
					richTextBox1.Invalidate();
				}
				interlock = false;

				// Switch focus to the RichEdit control
				richTextBox1.Focus();

			}
		}

		private void frmFontComboDemo_Load(object sender, System.EventArgs e)
		{		
			string exeDir = Path.GetDirectoryName(Application.ExecutablePath);
			string loadFile = Path.Combine(exeDir, "trying.rtf");
			if (File.Exists(loadFile))
			{
				richTextBox1.LoadFile(loadFile);
			}			
		}
	}
}
