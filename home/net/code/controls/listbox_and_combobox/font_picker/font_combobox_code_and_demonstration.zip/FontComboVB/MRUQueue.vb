Namespace FontCombo
    ''' <summary>
    ''' A basic Most-Recently Used (MRU) Queue implementation
    ''' </summary>
    <SerializableAttribute()> _
    Public Class MRUQueue
        Implements ICloneable, ICollection, IEnumerable

        Private Const INITIAL_SIZE As Integer = 8

        ''' <summary>
        ''' The ArrayList used to maintain the MRU queue
        ''' </summary>
        Protected innerList As ArrayList
        Private m_size As Integer = INITIAL_SIZE

        ''' <summary>
        ''' Gets/sets the maximum size of the MRU Queue.
        ''' </summary>
        Public Property Size() As Integer
            Get
                Return m_size
            End Get
            Set(ByVal Value As Integer)
                If (Value <= 0) Then
                    Throw New ArgumentException("Size must be greater than or equal to 1", "value")
                End If
                Me.Size = Value
                OnSizeChanged()
            End Set
        End Property

        ''' <summary>
        ''' Trims the MRU list to size based on the setting
        ''' of the <see cref="Size" /> property.
        ''' </summary>
        Protected Overridable Sub OnSizeChanged()
            If (innerList.Count > Size) Then
                Dim i As Integer
                For i = Size To innerList.Count - 1
                    innerList.RemoveAt(innerList.Count - 1)
                Next i
            End If
        End Sub

        ''' <summary>
        ''' Copies the contents of the MRU starting at the specified
        ''' index to an array.
        ''' </summary>
        ''' <param name="array">Array to copy contents to</param>
        ''' <param name="arrayIndex">Index of array to start at.</param>
        Public Overridable Sub CopyTo(ByVal array As Array, ByVal arrayIndex As Integer) _
            Implements ICollection.CopyTo
            Me.innerList.CopyTo(array, arrayIndex)
        End Sub

        ''' <summary>
        ''' Gets the object with the specified index.
        ''' </summary>
        Default Public ReadOnly Property Item(ByVal index As Integer)
            Get
                Return innerList(index)
            End Get
        End Property

        ''' <summary>
        ''' Adds the specified item to the MRU queue.  If the queue
        ''' already contains the specified item, it is shifted up
        ''' to the first position.  Otherwise, it is added at the
        ''' first position and any existing items are shuffled 
        ''' downwards and the <see cref="OnSizeChanged"/> method
        ''' is called to trim the collection to size.
        ''' </summary>
        ''' <param name="item">Item to add</param>
        Public Overridable Sub Add(ByVal item As Object)
            Dim noSizeChange As Boolean = False
            If (Me.innerList.Contains(item)) Then
                innerList.Remove(item)
                noSizeChange = True
            End If
            Me.innerList.Insert(0, item)
            If Not (noSizeChange) Then
                OnSizeChanged()
            End If
        End Sub

        ''' <summary>
        ''' Clears the MRU cache.
        ''' </summary>
        Public Overridable Sub Clear()
            OnClear()
        End Sub

        ''' <summary>
        ''' Called to clear the collection of contents.
        ''' </summary>
        Protected Overridable Sub OnClear()
            Me.innerList.Clear()
        End Sub

        ''' <summary>
        ''' Gets the number of items currently in the MRU Queue.
        ''' </summary>
        Public Overridable ReadOnly Property Count() As Integer _
            Implements ICollection.Count
            Get
                Return innerList.Count
            End Get
        End Property

        ''' <summary>
        ''' Gets whether this implementation is synchronized or not.
        ''' </summary>
        Public Overridable ReadOnly Property IsSynchronized() As Boolean _
            Implements ICollection.IsSynchronized
            Get
                Return innerList.IsSynchronized
            End Get
        End Property

        ''' <summary>
        ''' Gets an object that can be used to synchronize access to the 
        ''' <see cref="MRUQueue"/>.
        ''' </summary>
        Public Overridable ReadOnly Property SyncRoot() As Object _
            Implements ICollection.SyncRoot
            Get
                Return innerList.SyncRoot
            End Get
        End Property

        ''' <summary>
        ''' Gets the object that allows iterating through the members of the collection.
        ''' </summary>
        ''' <returns>An object that implements the <see cref="System.Collections.IEnumerator "/> interface.</returns>
        Public Overridable Function GetEnumerator() As IEnumerator _
                  Implements IEnumerable.GetEnumerator
            Return innerList.GetEnumerator()
        End Function

        ''' <summary>
        ''' Creates a shallow copy of the System.Collections.Hashtable.
        ''' </summary>
        ''' <returns>A shallow copy of the <see cref="MRUQueue"/>.</returns>
        Public Overridable Function Clone() As Object _
            Implements ICloneable.Clone
            Dim list As ArrayList = innerList.Clone()
            Dim mruQueue As MRUQueue = New MRUQueue(list)
            Return mruQueue
        End Function


        ''' <summary>
        ''' Constructs a new <see cref="MRUQueue"/> using the specified <see cref="ArrayList"/> as the
        ''' internal collection.
        ''' </summary>
        ''' <param name="arrayList">ArrayList to use as the internal collection.</param>
        Protected Sub New(ByVal arrayList As ArrayList)
            Me.innerList = arrayList
        End Sub

        ''' <summary>
        ''' Constructs a new instance of this collection
        ''' </summary>
        Public Sub New()
            innerList = New ArrayList()
        End Sub
    End Class

End Namespace
