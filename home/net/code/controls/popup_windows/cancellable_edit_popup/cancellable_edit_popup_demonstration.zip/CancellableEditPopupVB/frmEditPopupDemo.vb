Public Class frmEditPopupDemo
    Inherits System.Windows.Forms.Form

    Private WithEvents popupNotifier As vbAccelerator.Components.Controls.PopupCancelNotifier

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        popupNotifier = New vbAccelerator.Components.Controls.PopupCancelNotifier()

        Dim i As Integer
        For i = 0 To 99
            listBox1.Items.Add(String.Format("Test Item {0}", i))
        Next i

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents lblInfo2 As System.Windows.Forms.Label
    Friend WithEvents lblClickToEdit As System.Windows.Forms.Label
    Friend WithEvents txtPopupEdit As System.Windows.Forms.TextBox
    Friend WithEvents listBox1 As vbAccelerator.Components.Controls.EditableListBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmEditPopupDemo))
        Me.label1 = New System.Windows.Forms.Label()
        Me.lblInfo2 = New System.Windows.Forms.Label()
        Me.lblClickToEdit = New System.Windows.Forms.Label()
        Me.txtPopupEdit = New System.Windows.Forms.TextBox()
        Me.listBox1 = New CancellableEditPopupVB.vbAccelerator.Components.Controls.EditableListBox()
        Me.SuspendLayout()
        '
        'label1
        '
        Me.label1.BackColor = System.Drawing.SystemColors.ControlDark
        Me.label1.Location = New System.Drawing.Point(8, 8)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(284, 20)
        Me.label1.TabIndex = 8
        Me.label1.Text = " Editable ListBox"
        Me.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblInfo2
        '
        Me.lblInfo2.BackColor = System.Drawing.SystemColors.ControlDark
        Me.lblInfo2.Location = New System.Drawing.Point(8, 200)
        Me.lblInfo2.Name = "lblInfo2"
        Me.lblInfo2.Size = New System.Drawing.Size(284, 20)
        Me.lblInfo2.TabIndex = 7
        Me.lblInfo2.Text = " Editable Label"
        Me.lblInfo2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblClickToEdit
        '
        Me.lblClickToEdit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblClickToEdit.Location = New System.Drawing.Point(8, 224)
        Me.lblClickToEdit.Name = "lblClickToEdit"
        Me.lblClickToEdit.Size = New System.Drawing.Size(284, 20)
        Me.lblClickToEdit.TabIndex = 6
        Me.lblClickToEdit.Text = "Click to edit in-place"
        Me.lblClickToEdit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtPopupEdit
        '
        Me.txtPopupEdit.AcceptsReturn = True
        Me.txtPopupEdit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPopupEdit.Location = New System.Drawing.Point(128, 240)
        Me.txtPopupEdit.Multiline = True
        Me.txtPopupEdit.Name = "txtPopupEdit"
        Me.txtPopupEdit.Size = New System.Drawing.Size(144, 16)
        Me.txtPopupEdit.TabIndex = 5
        Me.txtPopupEdit.Text = ""
        Me.txtPopupEdit.Visible = False
        '
        'listBox1
        '
        Me.listBox1.IsReadOnly = False
        Me.listBox1.Location = New System.Drawing.Point(8, 32)
        Me.listBox1.Name = "listBox1"
        Me.listBox1.Size = New System.Drawing.Size(284, 160)
        Me.listBox1.TabIndex = 9
        '
        'frmEditPopupDemo
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(300, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.listBox1, Me.label1, Me.lblInfo2, Me.lblClickToEdit, Me.txtPopupEdit})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmEditPopupDemo"
        Me.Text = "vbAccelerator PopupCancel Notifier"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub popupNotifier_PopupCancel(ByVal sender As Object, ByVal e As CancellableEditPopupVB.vbAccelerator.Components.Controls.PopupCancelEventArgs) Handles popupNotifier.PopupCancel
        EndTextEdit(True)

    End Sub


    Private Sub SetTextBoxSize()
        Dim text As String = txtPopupEdit.Text
        If (Text.Length = 0) Then
            Text = "Xg"
        End If
        Dim maxWidth As Integer = lblClickToEdit.Width - 10

        Dim gfx As Graphics = Graphics.FromHwnd(txtPopupEdit.Handle)
        Dim flags As StringFormatFlags = StringFormatFlags.LineLimit Or _
            IIf(txtPopupEdit.RightToLeft = RightToLeft.Yes, StringFormatFlags.DirectionRightToLeft, 0)
        Dim fmt As StringFormat = New StringFormat(flags)
        fmt.Alignment = StringAlignment.Center
        Dim textSize As SizeF = gfx.MeasureString(Text, lblClickToEdit.Font, 10000, fmt)
        textSize.Width += 8
        fmt.Dispose()
        gfx.Dispose()

        If (textSize.Width < 24) Then
            textSize.Width = 24
        ElseIf (textSize.Width > maxWidth) Then
            textSize.Width = maxWidth
        End If
        If (textSize.Height < lblClickToEdit.ClientRectangle.Height) Then
            textSize.Height = lblClickToEdit.ClientRectangle.Height
        End If

        txtPopupEdit.Size = New Size(textSize.Width + 6, textSize.Height)
    End Sub

    Private Sub StartTextEdit()
        Me.Focus()

        txtPopupEdit.Text = lblClickToEdit.Text
        lblClickToEdit.Tag = lblClickToEdit.Text
        lblClickToEdit.Text = ""
        SetTextBoxSize()
        Dim location As Point = lblClickToEdit.Location
        location.Offset(1, 1)
        txtPopupEdit.Location = location
        txtPopupEdit.Visible = True
        txtPopupEdit.BringToFront()
        txtPopupEdit.Focus()

        popupNotifier.StartTracking(txtPopupEdit)
    End Sub

    Private Sub EndTextEdit(ByVal commit As Boolean)
        If (commit) Then
            lblClickToEdit.Text = txtPopupEdit.Text
        Else
            lblClickToEdit.Text = lblClickToEdit.Tag
        End If
        txtPopupEdit.Visible = False
        popupNotifier.StopTracking()
    End Sub


    Private Sub lblClickToEdit_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lblClickToEdit.MouseDown
        If ((e.Button = MouseButtons.Left) And Not (txtPopupEdit.Visible)) Then
            StartTextEdit()
        End If
    End Sub

    Private Sub txtPopupEdit_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtPopupEdit.TextChanged
        SetTextBoxSize()
    End Sub

    Private Sub txtPopupEdit_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtPopupEdit.KeyDown
        Select Case (e.KeyData)
            Case Keys.Return
                '// end editing:
                EndTextEdit(True)

            Case Keys.Escape
                '// cancel editing:
                EndTextEdit(False)
        End Select
    End Sub
End Class
