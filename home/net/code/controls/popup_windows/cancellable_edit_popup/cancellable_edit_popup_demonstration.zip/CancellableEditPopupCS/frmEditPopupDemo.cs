using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using vbAccelerator.Components.Controls;

namespace CancellableEditPopupCS
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmEditPopupDemo : System.Windows.Forms.Form
	{
		private PopupCancelNotifier popupNotifier;

		private System.Windows.Forms.TextBox txtPopupEdit;
		private System.Windows.Forms.Label lblClickToEdit;
		private EditableListBox listBox1;
		private System.Windows.Forms.Label lblInfo2;
		private System.Windows.Forms.Label label1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmEditPopupDemo()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// Set up the notifier for the label and text box:
			popupNotifier = new PopupCancelNotifier();
			popupNotifier.PopupCancel += new PopupCancelEventHandler(popupNotifier_PopupCancel);

			lblClickToEdit.MouseDown += new MouseEventHandler(lblClickToEdit_MouseDown);
			txtPopupEdit.KeyDown += new KeyEventHandler(txtPopupEdit_KeyDown);
			txtPopupEdit.TextChanged += new EventHandler(txtPopupEdit_TextChanged);

			// Add some items to the listbox
			for (int i = 0; i < 100; i++)
			{
				listBox1.Items.Add(String.Format("Test Item {0}", i));
			}

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmEditPopupDemo));
			this.txtPopupEdit = new System.Windows.Forms.TextBox();
			this.lblClickToEdit = new System.Windows.Forms.Label();
			this.listBox1 = new vbAccelerator.Components.Controls.EditableListBox();
			this.lblInfo2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// txtPopupEdit
			// 
			this.txtPopupEdit.AcceptsReturn = true;
			this.txtPopupEdit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtPopupEdit.Location = new System.Drawing.Point(124, 236);
			this.txtPopupEdit.Multiline = true;
			this.txtPopupEdit.Name = "txtPopupEdit";
			this.txtPopupEdit.Size = new System.Drawing.Size(144, 16);
			this.txtPopupEdit.TabIndex = 0;
			this.txtPopupEdit.Text = "";
			this.txtPopupEdit.Visible = false;
			// 
			// lblClickToEdit
			// 
			this.lblClickToEdit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblClickToEdit.Location = new System.Drawing.Point(4, 220);
			this.lblClickToEdit.Name = "lblClickToEdit";
			this.lblClickToEdit.Size = new System.Drawing.Size(284, 20);
			this.lblClickToEdit.TabIndex = 1;
			this.lblClickToEdit.Text = "Click to edit in-place";
			this.lblClickToEdit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// listBox1
			// 
			this.listBox1.ColumnWidth = 96;
			this.listBox1.Location = new System.Drawing.Point(4, 28);
			this.listBox1.Name = "listBox1";
			this.listBox1.ReadOnly = false;
			this.listBox1.Size = new System.Drawing.Size(284, 160);
			this.listBox1.TabIndex = 2;
			// 
			// lblInfo2
			// 
			this.lblInfo2.BackColor = System.Drawing.SystemColors.ControlDark;
			this.lblInfo2.Location = new System.Drawing.Point(4, 196);
			this.lblInfo2.Name = "lblInfo2";
			this.lblInfo2.Size = new System.Drawing.Size(284, 20);
			this.lblInfo2.TabIndex = 3;
			this.lblInfo2.Text = " Editable Label";
			this.lblInfo2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.SystemColors.ControlDark;
			this.label1.Location = new System.Drawing.Point(4, 4);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(284, 20);
			this.label1.TabIndex = 4;
			this.label1.Text = " Editable ListBox";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// frmEditPopupDemo
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.label1,
																		  this.lblInfo2,
																		  this.listBox1,
																		  this.lblClickToEdit,
																		  this.txtPopupEdit});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmEditPopupDemo";
			this.Text = "vbAccelerator PopupCancel Notifier";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmEditPopupDemo());
		}

		private void popupNotifier_PopupCancel(object sender, PopupCancelEventArgs e)
		{
			EndTextEdit(true);			
		}

		private void lblClickToEdit_MouseDown(object sender, MouseEventArgs e)
		{
			if ((e.Button == MouseButtons.Left) && (!txtPopupEdit.Visible))
			{
				StartTextEdit();
			}
		}

		private void txtPopupEdit_TextChanged(object sender, System.EventArgs e)
		{
			SetTextBoxSize();
		}

		private void txtPopupEdit_KeyDown(object sender, KeyEventArgs e)
		{
			switch (e.KeyData)			
			{
				case Keys.Return:
					// end editing:
					EndTextEdit(true);
					break;

				case Keys.Escape:
					// cancel editing:
					EndTextEdit(false);
					break;				
			}
		}

		
		private void SetTextBoxSize()
		{
			string text = txtPopupEdit.Text;
			if (text.Length == 0)
			{
				text = "Xg";
			}
			
			int maxWidth = lblClickToEdit.Width - 10;

			Graphics gfx = Graphics.FromHwnd(txtPopupEdit.Handle);
			StringFormat fmt = new StringFormat(StringFormatFlags.LineLimit | 
				(txtPopupEdit.RightToLeft == RightToLeft.Yes ? StringFormatFlags.DirectionRightToLeft : 0));
			fmt.Alignment = StringAlignment.Center;
			SizeF textSize = gfx.MeasureString(text, lblClickToEdit.Font, 10000, fmt);
			// leeway
			textSize.Width += 8;
			fmt.Dispose();
			gfx.Dispose();						
			
			if (textSize.Width < 24)
			{
				textSize.Width = 24;
			}
			else if (textSize.Width > maxWidth)
			{
				textSize.Width = maxWidth;
			}
			if (textSize.Height < lblClickToEdit.ClientRectangle.Height)
			{
				textSize.Height = lblClickToEdit.ClientRectangle.Height;
			}
			
			txtPopupEdit.Size = new Size((int)textSize.Width + 6, (int) textSize.Height);
		}

		private void StartTextEdit()
		{
			this.Focus();
			
			txtPopupEdit.Text = lblClickToEdit.Text;
			lblClickToEdit.Tag = lblClickToEdit.Text;
			lblClickToEdit.Text = "";
			SetTextBoxSize();
			Point location = lblClickToEdit.Location;
			location.Offset(1, 1);
			txtPopupEdit.Location = location;
			txtPopupEdit.Visible = true;				
			txtPopupEdit.BringToFront();
			txtPopupEdit.Focus();

			popupNotifier.StartTracking(txtPopupEdit);

		}

		private void EndTextEdit(bool commit)
		{
			if (commit)
			{
				lblClickToEdit.Text = txtPopupEdit.Text;
			}
			else
			{
				lblClickToEdit.Text = (string) lblClickToEdit.Tag;
			}
			txtPopupEdit.Visible = false;
			popupNotifier.StopTracking();
		}

	}
}
