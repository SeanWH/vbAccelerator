using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using vbAccelerator.Components.Controls;

namespace DesktopParent
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmFloatControl : System.Windows.Forms.Form
	{
		private FloatControl sponsorMessage;
		private FloatControl listBoxHover;
		private int lastListItemOver = -1;

		private System.Windows.Forms.Button btnHover;
		private System.Windows.Forms.ListBox lstLongItemPopup;
		private System.Windows.Forms.PictureBox picRes;
		private System.Windows.Forms.Label lblInfo;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmFloatControl()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// Resizable form:
			this.SizeChanged += new EventHandler(frmFloatControl_OnSizeChanged);

			// 
			// Set up the floating "SponsorMessage" control
			// 
			this.sponsorMessage = new FloatControl();
			// Here 
			this.sponsorMessage.BackgroundImage = 
				((System.Drawing.Bitmap)(new System.Resources.ResourceManager(typeof(frmFloatControl)).GetObject("picRes.Image")));
			this.sponsorMessage.Name = "sponsorMessage";
			this.sponsorMessage.TabStop = false;
			this.sponsorMessage.Visible = false;
			this.sponsorMessage.Size = this.sponsorMessage.BackgroundImage.Size;

			btnHover.MouseHover += new EventHandler(btnHover_MouseHover);
			btnHover.MouseLeave += new EventHandler(btnHover_MouseLeave);

			// Add some items to the ListBox which go beyond the visibility of the box
			for (int i = 0; i < 100; i++)
			{
				if ((i % 2) == 0)
				{
					this.lstLongItemPopup.Items.Add(
						String.Format("This is long item {0} which can go beyond the width of the list box.", i));
				}
				else
				{
					this.lstLongItemPopup.Items.Add(String.Format("Short Item {0}", i));
				}
			}

			// Create the control which will show the item the mouse is over in the 
			// list box:
			this.listBoxHover = new FloatControl();
			this.listBoxHover.Name = "listBoxHover";
			this.listBoxHover.TabStop = false;
			this.listBoxHover.Visible = false;
			this.listBoxHover.BackColor = SystemColors.Info;
			this.listBoxHover.ForeColor = SystemColors.InfoText;

			this.lstLongItemPopup.MouseEnter += new EventHandler(lstLongItemPopup_MouseEnter);
			this.lstLongItemPopup.MouseDown += new MouseEventHandler(lstLongItemPopup_MouseDown);
			this.lstLongItemPopup.MouseMove += new MouseEventHandler(lstLongItemPopup_MouseMove);
			this.lstLongItemPopup.MouseLeave += new EventHandler(lstLongItemPopup_MouseLeave);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFloatControl));
			this.btnHover = new System.Windows.Forms.Button();
			this.lstLongItemPopup = new System.Windows.Forms.ListBox();
			this.picRes = new System.Windows.Forms.PictureBox();
			this.lblInfo = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// btnHover
			// 
			this.btnHover.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnHover.Location = new System.Drawing.Point(8, 200);
			this.btnHover.Name = "btnHover";
			this.btnHover.Size = new System.Drawing.Size(100, 40);
			this.btnHover.TabIndex = 1;
			this.btnHover.Text = "&Visit our Sponsor...";
			// 
			// lstLongItemPopup
			// 
			this.lstLongItemPopup.Location = new System.Drawing.Point(8, 48);
			this.lstLongItemPopup.Name = "lstLongItemPopup";
			this.lstLongItemPopup.Size = new System.Drawing.Size(276, 147);
			this.lstLongItemPopup.TabIndex = 2;
			// 
			// picRes
			// 
			this.picRes.Image = ((System.Drawing.Bitmap)(resources.GetObject("picRes.Image")));
			this.picRes.Location = new System.Drawing.Point(164, 200);
			this.picRes.Name = "picRes";
			this.picRes.Size = new System.Drawing.Size(92, 48);
			this.picRes.TabIndex = 3;
			this.picRes.TabStop = false;
			this.picRes.Visible = false;
			// 
			// lblInfo
			// 
			this.lblInfo.Location = new System.Drawing.Point(8, 4);
			this.lblInfo.Name = "lblInfo";
			this.lblInfo.Size = new System.Drawing.Size(276, 40);
			this.lblInfo.TabIndex = 4;
			this.lblInfo.Text = "This sample demonstrates how to make a control float over other controls and make" +
				" it transparent to the mouse.";
			// 
			// frmFloatControl
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(292, 246);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lblInfo,
																		  this.picRes,
																		  this.lstLongItemPopup,
																		  this.btnHover});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmFloatControl";
			this.Text = "vbAccelerator Float Control Demonstration";
			this.Load += new System.EventHandler(this.frmFloatControl_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmFloatControl());
		}


		private void frmFloatControl_Load(object sender, System.EventArgs e)
		{
		
		}

		private void frmFloatControl_OnSizeChanged(object sender, EventArgs e)
		{
			try
			{
				this.SuspendLayout();
				int listHeight = this.ClientRectangle.Height - lstLongItemPopup.Top - btnHover.Height - 4;
				lstLongItemPopup.Size = new Size(this.ClientRectangle.Width - lstLongItemPopup.Left * 2, 
					listHeight);
				btnHover.Top = lstLongItemPopup.Top + listHeight;
				lblInfo.Width = this.ClientRectangle.Width - lblInfo.Left * 2;
				this.ResumeLayout();
			}
			catch
			{
			}
		}

		private void btnHover_MouseHover(object sender, EventArgs e)
		{
			if (!sponsorMessage.Visible)
			{
				Point pt = btnHover.Location;
				pt.Offset(0, btnHover.Height / 2);
				pt = this.PointToScreen(pt);
				sponsorMessage.Location = pt;
				sponsorMessage.ShowFloating();
			}
		}

		private void btnHover_MouseLeave(object sender, EventArgs e)
		{
			if (sponsorMessage.Visible)
			{
				sponsorMessage.Hide();
			}
		}

		private void lstLongItemPopup_MouseMove(object sender, MouseEventArgs e)
		{
			if (e.Button == 0)
			{
				OnListBoxMouseMove();			
			}
			else
			{
				OnListBoxMouseCancel();
			}
		}

		private void lstLongItemPopup_MouseDown(object sender, MouseEventArgs e)
		{
			OnListBoxMouseCancel();
		}

		private void lstLongItemPopup_MouseEnter(object sender, EventArgs e)
		{
			OnListBoxMouseMove();
		}

		private void lstLongItemPopup_MouseLeave(object sender, EventArgs e)
		{			
			OnListBoxMouseCancel();
		}

		private void OnListBoxMouseCancel()
		{
			if (listBoxHover.Visible)
			{
				listBoxHover.Hide();
				lastListItemOver = -1;
			}
		}

		private void OnListBoxMouseMove()
		{
			int itemOver = -1;
			int newPopupItemOver = -1;

			Point pt = GetHoverItemLocation(ref itemOver);
			Size hoverItemSize = new Size(0, 0);
			if (itemOver != lastListItemOver)
			{
				if (itemOver > -1)
				{
					listBoxHover.Font = lstLongItemPopup.Font;
					hoverItemSize = GetHoverItemSize(itemOver);
					if (hoverItemSize.Width > lstLongItemPopup.ClientRectangle.Width)
					{
						newPopupItemOver = itemOver;
					}
				}

				if (newPopupItemOver > -1)
				{
					listBoxHover.Location = pt;
					listBoxHover.Size = hoverItemSize;
					if (!listBoxHover.Visible)
					{
						listBoxHover.ShowFloating();
					}
					listBoxHover.Text = lstLongItemPopup.Items[itemOver].ToString();
				}
				else
				{
					OnListBoxMouseCancel();
				}
			}
			
			lastListItemOver = newPopupItemOver;

		}

		private Point GetHoverItemLocation(ref int itemOver)
		{
			itemOver = -1;

			Point cursorPosition = Cursor.Position;
			Point location = new Point(0,0);			

			// Convert cursor position to ListBox coordinates:
			cursorPosition = lstLongItemPopup.PointToClient(cursorPosition);
			if (lstLongItemPopup.ClientRectangle.Contains(cursorPosition))
			{
				// Determine which item (if any) we are over:
				int height = lstLongItemPopup.ItemHeight;
				int y = 0;
				for (int i = lstLongItemPopup.TopIndex; i < lstLongItemPopup.Items.Count; i++)
				{
					if (cursorPosition.Y >= y && cursorPosition.Y <= y + height)
					{
						location = new Point(0, y);
						itemOver = i;
						break;
					}
					y += height;
				}
			}
			return lstLongItemPopup.PointToScreen(location);
		}

		private Size GetHoverItemSize(int itemOver)
		{
			Graphics graphics = Graphics.FromHwnd(listBoxHover.Handle);
			SizeF size = graphics.MeasureString(lstLongItemPopup.Items[itemOver].ToString(),
					lstLongItemPopup.Font);			
			graphics.Dispose();
			return new Size(((int) size.Width) + 4, Math.Max(lstLongItemPopup.ItemHeight, ((int) size.Height) + 1));
		}

	}
}
