Public Class frmFloatControl
    Inherits System.Windows.Forms.Form

    Private sponsorMessage As vbAccelerator.Components.Controls.FloatControl
    Private listBoxHover As vbAccelerator.Components.Controls.FloatControl
    Private lastListItemOver As Integer = -1


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'Me call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

        ' 
        ' Set up the floating "SponsorMessage" control
        ' 
        Me.sponsorMessage = New vbAccelerator.Components.Controls.FloatControl()
        Me.sponsorMessage.BackgroundImage = picRes.Image
        Me.sponsorMessage.Name = "sponsorMessage"
        Me.sponsorMessage.TabStop = False
        Me.sponsorMessage.Visible = False
        Me.sponsorMessage.Size = picRes.Image.Size

        ' Add some items to the ListBox which go beyond the visibility of the box
        Dim i As Integer
        For i = 0 To 99
            If ((i Mod 2) = 0) Then
                Me.lstLongItemPopup.Items.Add( _
                    String.Format("This is long item {0} which can go beyond the width of the list box.", i))
            Else
                Me.lstLongItemPopup.Items.Add(String.Format("Short Item {0}", i))
            End If
        Next i

        ' Create the control which will show the item the mouse is over in the 
        ' list box:
        Me.listBoxHover = New vbAccelerator.Components.Controls.FloatControl()
        Me.listBoxHover.Name = "listBoxHover"
        Me.listBoxHover.TabStop = False
        Me.listBoxHover.Visible = False
        Me.listBoxHover.BackColor = SystemColors.Info
        Me.listBoxHover.ForeColor = SystemColors.InfoText

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lblInfo As System.Windows.Forms.Label
    Friend WithEvents picRes As System.Windows.Forms.PictureBox
    Friend WithEvents lstLongItemPopup As System.Windows.Forms.ListBox
    Friend WithEvents btnHover As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmFloatControl))
        Me.lblInfo = New System.Windows.Forms.Label()
        Me.picRes = New System.Windows.Forms.PictureBox()
        Me.lstLongItemPopup = New System.Windows.Forms.ListBox()
        Me.btnHover = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblInfo
        '
        Me.lblInfo.Location = New System.Drawing.Point(8, 4)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(276, 40)
        Me.lblInfo.TabIndex = 8
        Me.lblInfo.Text = "This sample demonstrates how to make a control float over other controls and make" & _
        " it transparent to the mouse."
        '
        'picRes
        '
        Me.picRes.Image = CType(resources.GetObject("picRes.Image"), System.Drawing.Bitmap)
        Me.picRes.Location = New System.Drawing.Point(164, 200)
        Me.picRes.Name = "picRes"
        Me.picRes.Size = New System.Drawing.Size(92, 48)
        Me.picRes.TabIndex = 7
        Me.picRes.TabStop = False
        Me.picRes.Visible = False
        '
        'lstLongItemPopup
        '
        Me.lstLongItemPopup.Location = New System.Drawing.Point(8, 48)
        Me.lstLongItemPopup.Name = "lstLongItemPopup"
        Me.lstLongItemPopup.Size = New System.Drawing.Size(276, 147)
        Me.lstLongItemPopup.TabIndex = 6
        '
        'btnHover
        '
        Me.btnHover.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnHover.Location = New System.Drawing.Point(8, 200)
        Me.btnHover.Name = "btnHover"
        Me.btnHover.Size = New System.Drawing.Size(100, 40)
        Me.btnHover.TabIndex = 5
        Me.btnHover.Text = "&Visit our Sponsor..."
        '
        'frmFloatControl
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblInfo, Me.picRes, Me.lstLongItemPopup, Me.btnHover})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmFloatControl"
        Me.Text = "vbAccelerator Float Control Demonstration"
        Me.ResumeLayout(False)

    End Sub

#End Region




    Private Sub frmFloatControl_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.SizeChanged
        Try
            Me.SuspendLayout()
            Dim listHeight As Integer = Me.ClientRectangle.Height - lstLongItemPopup.Top - btnHover.Height - 4
			lstLongItemPopup.Size = new Size(me.ClientRectangle.Width - lstLongItemPopup.Left * 2, _
					listHeight)
            btnHover.Top = lstLongItemPopup.Top + listHeight
            lblInfo.Width = Me.ClientRectangle.Width - lblInfo.Left * 2
            Me.ResumeLayout()
        Catch
        End Try
    End Sub

    Private Sub btnHover_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnHover.MouseHover
        If Not (sponsorMessage.Visible) Then
            Dim pt As Point = btnHover.Location
            pt.Offset(0, btnHover.Height / 2)
            pt = Me.PointToScreen(pt)
            sponsorMessage.Location = pt
            sponsorMessage.ShowFloating()
        End If
    End Sub

    Private Sub btnHover_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnHover.MouseLeave
        If (sponsorMessage.Visible) Then
            sponsorMessage.Hide()
        End If
    End Sub

    Private Sub lstLongItemPopup_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lstLongItemPopup.MouseMove
        If (e.Button = 0) Then
            OnListBoxMouseMove()
        Else
            OnListBoxMouseCancel()
        End If
    End Sub

    Private Sub lstLongItemPopup_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lstLongItemPopup.MouseDown
        OnListBoxMouseCancel()
    End Sub

    Private Sub lstLongItemPopup_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstLongItemPopup.MouseEnter
        OnListBoxMouseMove()
    End Sub

    Private Sub lstLongItemPopup_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstLongItemPopup.MouseLeave
        OnListBoxMouseCancel()
    End Sub

    Private Sub OnListBoxMouseCancel()
        If (listBoxHover.Visible) Then
            listBoxHover.Hide()
            lastListItemOver = -1
        End If
    End Sub

    Private Sub OnListBoxMouseMove()
        Dim itemOver As Integer = -1
        Dim newPopupItemOver As Integer = -1

        Dim pt As Point = GetHoverItemLocation(itemOver)
        Dim hoverItemSize As Size = New Size(0, 0)
        If (itemOver <> lastListItemOver) Then
            If (itemOver > -1) Then
                listBoxHover.Font = lstLongItemPopup.Font
                hoverItemSize = GetHoverItemSize(itemOver)
                If (hoverItemSize.Width > lstLongItemPopup.ClientRectangle.Width) Then
                    newPopupItemOver = itemOver
                End If

                If (newPopupItemOver > -1) Then
                    listBoxHover.Location = pt
                    listBoxHover.Size = hoverItemSize
                    If Not (listBoxHover.Visible) Then
                        listBoxHover.ShowFloating()
                    End If
                    listBoxHover.Text = lstLongItemPopup.Items(itemOver).ToString()
                Else
                    OnListBoxMouseCancel()
                End If
            End If
        End If

        lastListItemOver = newPopupItemOver

    End Sub

    Private Function GetHoverItemLocation(ByRef itemOver As Integer) As Point
        itemOver = -1

        Dim cursorPosition As Point = Cursor.Position
        Dim location As Point = New Point(0, 0)

        ' Convert cursor position to ListBox coordinates:
        cursorPosition = lstLongItemPopup.PointToClient(cursorPosition)
        If (lstLongItemPopup.ClientRectangle.Contains(cursorPosition)) Then
            ' Determine which item (if any) we are over:
            Dim height As Integer = lstLongItemPopup.ItemHeight
            Dim y As Integer = 0
            Dim i As Integer
            For i = lstLongItemPopup.TopIndex To lstLongItemPopup.Items.Count - 1
                If (cursorPosition.Y >= y And cursorPosition.Y <= y + height) Then
                    location = New Point(0, y)
                    itemOver = i
                    Exit For
                End If
                y += height
            Next i
        End If
        Return lstLongItemPopup.PointToScreen(location)
    End Function

    Private Function GetHoverItemSize(ByVal itemOver As Integer) As Size
        Dim graphics As Graphics = graphics.FromHwnd(listBoxHover.Handle)
        Dim size As SizeF = graphics.MeasureString(lstLongItemPopup.Items(itemOver).ToString(), _
          lstLongItemPopup.Font)
        graphics.Dispose()
        Return New Size((size.Width + 4), Math.Max(lstLongItemPopup.ItemHeight, (size.Height) + 1))
    End Function

End Class
