Public Class frmPopup
    Inherits System.Windows.Forms.Form

    '/// <summary>
    '/// The selected item in the ListView
    '/// </summary>
    Private m_selectedItem As String = ""


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        Dim i As Integer
        For i = 0 To 19
            Dim item As ListViewItem = New ListViewItem(String.Format("Test {0}", i))
            item.SubItems.Add(String.Format("{0:d}", DateTime.Now))
            lvwDemo.Items.Add(item)
        Next i

        Me.Size = New Size(lvwDemo.Right + lvwDemo.Left, btnFind.Bottom + lvwDemo.Left)

        lvwDemo.Select()

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtFind As System.Windows.Forms.TextBox
    Friend WithEvents colName As System.Windows.Forms.ColumnHeader
    Friend WithEvents btnFind As System.Windows.Forms.Button
    Friend WithEvents lvwDemo As System.Windows.Forms.ListView
    Friend WithEvents colDate As System.Windows.Forms.ColumnHeader
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtFind = New System.Windows.Forms.TextBox()
        Me.colName = New System.Windows.Forms.ColumnHeader()
        Me.btnFind = New System.Windows.Forms.Button()
        Me.lvwDemo = New System.Windows.Forms.ListView()
        Me.colDate = New System.Windows.Forms.ColumnHeader()
        Me.SuspendLayout()
        '
        'txtFind
        '
        Me.txtFind.Location = New System.Drawing.Point(6, 231)
        Me.txtFind.Name = "txtFind"
        Me.txtFind.Size = New System.Drawing.Size(224, 21)
        Me.txtFind.TabIndex = 4
        Me.txtFind.Text = ""
        '
        'colName
        '
        Me.colName.Width = 128
        '
        'btnFind
        '
        Me.btnFind.Location = New System.Drawing.Point(238, 231)
        Me.btnFind.Name = "btnFind"
        Me.btnFind.Size = New System.Drawing.Size(48, 24)
        Me.btnFind.TabIndex = 5
        Me.btnFind.Text = "&Find..."
        '
        'lvwDemo
        '
        Me.lvwDemo.AllowColumnReorder = True
        Me.lvwDemo.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colName, Me.colDate})
        Me.lvwDemo.FullRowSelect = True
        Me.lvwDemo.HideSelection = False
        Me.lvwDemo.Location = New System.Drawing.Point(6, 11)
        Me.lvwDemo.MultiSelect = False
        Me.lvwDemo.Name = "lvwDemo"
        Me.lvwDemo.Size = New System.Drawing.Size(280, 216)
        Me.lvwDemo.TabIndex = 3
        Me.lvwDemo.View = System.Windows.Forms.View.Details
        '
        'colDate
        '
        Me.colDate.Width = 96
        '
        'frmPopup
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtFind, Me.btnFind, Me.lvwDemo})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmPopup"
        Me.ShowInTaskbar = False
        Me.TopMost = True
        Me.ResumeLayout(False)

    End Sub

#End Region

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        MyBase.OnPaint(e)
        Dim borderRect As Rectangle = New Rectangle(ClientRectangle.Location, ClientRectangle.Size)
        borderRect.Width -= 1
        borderRect.Height -= 1
        e.Graphics.DrawRectangle(SystemPens.ControlDark, borderRect)
    End Sub


    Private Sub btnFind_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnFind.Click
        MessageBox.Show(Me, "Perform a find on the text here.", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub selectItem()
        If (lvwDemo.SelectedItems.Count > 0) Then
            selectedItem = lvwDemo.Items(lvwDemo.SelectedIndices(0)).Text
            Close()
        End If
    End Sub

    Public Property SelectedItem() As String
        Get
            Return m_selectedItem
        End Get
        Set(ByVal Value As String)
            m_selectedItem = Value
        End Set
    End Property

    Private Sub lvwDemo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvwDemo.Click
        selectItem()
    End Sub


    Private Sub lvwDemo_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles lvwDemo.KeyDown
        '// If an item is selected and we get a return, then close
        If (e.KeyCode = Keys.Return) Then
            selectItem()
        End If
    End Sub

    Private Sub frmPopup_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim itm As ListViewItem
        For Each itm In lvwDemo.Items
            If (itm.Text.Equals(SelectedItem)) Then
                itm.Selected = True
                itm.EnsureVisible()
                Return
            End If
        Next

    End Sub
End Class
