Public Class frmMain
    Inherits System.Windows.Forms.Form

    Private WithEvents popupHelper As vbAccelerator.Components.Controls.PopupWindowHelper = Nothing

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        popupHelper = New vbAccelerator.Components.Controls.PopupWindowHelper()
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lblInfo As System.Windows.Forms.Label
    Friend WithEvents lblSelectedItem As System.Windows.Forms.Label
    Friend WithEvents btnDrop As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMain))
        Me.lblInfo = New System.Windows.Forms.Label()
        Me.lblSelectedItem = New System.Windows.Forms.Label()
        Me.btnDrop = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblInfo
        '
        Me.lblInfo.Location = New System.Drawing.Point(8, 12)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(288, 48)
        Me.lblInfo.TabIndex = 6
        Me.lblInfo.Text = "This sample demonstrates how to convert a .NET Framework form into a popup which " & _
        "acts like the drop-down portion of a ComboBox."
        '
        'lblSelectedItem
        '
        Me.lblSelectedItem.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSelectedItem.Location = New System.Drawing.Point(32, 80)
        Me.lblSelectedItem.Name = "lblSelectedItem"
        Me.lblSelectedItem.Size = New System.Drawing.Size(212, 24)
        Me.lblSelectedItem.TabIndex = 5
        Me.lblSelectedItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnDrop
        '
        Me.btnDrop.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnDrop.Location = New System.Drawing.Point(244, 80)
        Me.btnDrop.Name = "btnDrop"
        Me.btnDrop.Size = New System.Drawing.Size(28, 24)
        Me.btnDrop.TabIndex = 4
        Me.btnDrop.Text = "..."
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(304, 158)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblInfo, Me.lblSelectedItem, Me.btnDrop})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "vbAccelerator PopupForm Demonstration"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnDrop_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDrop.Click
        Dim popup As frmPopup = New frmPopup()
        popup.SelectedItem = lblSelectedItem.Text
        Dim location As Point = Me.PointToScreen(New Point(lblSelectedItem.Left, btnDrop.Bottom))
        popupHelper.ShowPopup(Me, popup, location)
    End Sub

    Private Sub popupHelper_PopupCancel(ByVal sender As Object, ByVal e As PopupControlVB.vbAccelerator.Components.Controls.PopupCancelEventArgs) Handles popupHelper.PopupCancel
        Console.WriteLine("Popup Cancel, mouse clicked at {0}", e.CursorLocation)
    End Sub

    Private Sub popupHelper_PopupClosed(ByVal sender As Object, ByVal e As PopupControlVB.vbAccelerator.Components.Controls.PopupClosedEventArgs) Handles popupHelper.PopupClosed
        Console.WriteLine("Popup Closed")
        Dim popup As frmPopup = e.Popup
        lblSelectedItem.Text = popup.SelectedItem
    End Sub

    Protected Overrides Sub OnHandleCreated(ByVal e As System.EventArgs)
        popupHelper.AssignHandle(Me.Handle)
    End Sub
End Class
