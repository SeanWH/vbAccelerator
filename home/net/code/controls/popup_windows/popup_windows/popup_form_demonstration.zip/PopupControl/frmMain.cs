using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using vbAccelerator.Components.Controls;

namespace PopupControl
{
	/// <summary>
	/// The main application form for the vbAccelerator PopupWindowHelper
	/// demonstration.  This form uses the PopupWindowHelper to associate
	/// a form containing a ListView and find controls to show as a popup
	/// in response to a button press.  The UI is basic but here to 
	/// demonstrate how the technique works.
	/// </summary>
	public class frmMain : System.Windows.Forms.Form
	{
		private PopupWindowHelper popupHelper = null;

		private System.Windows.Forms.Button btnDrop;
		private System.Windows.Forms.Label lblSelectedItem;
		private System.Windows.Forms.Label lblInfo;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			popupHelper = new PopupWindowHelper();
			popupHelper.PopupClosed += new PopupClosedEventHandler(popupHelper_PopupClosed);
			popupHelper.PopupCancel += new PopupCancelEventHandler(popupHelper_PopupCancel);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMain));
			this.btnDrop = new System.Windows.Forms.Button();
			this.lblSelectedItem = new System.Windows.Forms.Label();
			this.lblInfo = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// btnDrop
			// 
			this.btnDrop.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnDrop.Location = new System.Drawing.Point(240, 76);
			this.btnDrop.Name = "btnDrop";
			this.btnDrop.Size = new System.Drawing.Size(28, 24);
			this.btnDrop.TabIndex = 1;
			this.btnDrop.Text = "...";
			this.btnDrop.Click += new System.EventHandler(this.btnDrop_Click);
			// 
			// lblSelectedItem
			// 
			this.lblSelectedItem.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblSelectedItem.Location = new System.Drawing.Point(28, 76);
			this.lblSelectedItem.Name = "lblSelectedItem";
			this.lblSelectedItem.Size = new System.Drawing.Size(212, 24);
			this.lblSelectedItem.TabIndex = 2;
			this.lblSelectedItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblInfo
			// 
			this.lblInfo.Location = new System.Drawing.Point(4, 8);
			this.lblInfo.Name = "lblInfo";
			this.lblInfo.Size = new System.Drawing.Size(288, 48);
			this.lblInfo.TabIndex = 3;
			this.lblInfo.Text = "This sample demonstrates how to convert a .NET Framework form into a popup which " +
				"acts like the drop-down portion of a ComboBox.";
			// 
			// frmMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(300, 170);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lblInfo,
																		  this.lblSelectedItem,
																		  this.btnDrop});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmMain";
			this.Text = "vbAccelerator PopupForm Demonstration";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmMain());
		}

		protected override void OnHandleCreated(EventArgs e)
		{
			popupHelper.AssignHandle(this.Handle);
		}

		private void btnDrop_Click(object sender, System.EventArgs e)
		{
			frmPopup popup = new frmPopup();
			popup.SelectedItem = lblSelectedItem.Text;
			Point location = this.PointToScreen(new Point(lblSelectedItem.Left, btnDrop.Bottom));
			popupHelper.ShowPopup(this, popup, location);			
		}

		private void popupHelper_PopupClosed(object sender, PopupClosedEventArgs e)
		{
			Console.WriteLine("Popup Closed");
			frmPopup popup = (frmPopup) e.Popup;
			lblSelectedItem.Text = popup.SelectedItem;
		}

		private void popupHelper_PopupCancel(object sender, PopupCancelEventArgs e)
		{
			Console.WriteLine("Popup Cancel, mouse clicked at {0}", e.CursorLocation);
		}


	}
}
