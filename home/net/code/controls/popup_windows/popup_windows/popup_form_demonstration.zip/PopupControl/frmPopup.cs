using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace PopupControl
{
	/// <summary>
	/// A simple demonstration form to show how the vbAccelerator
	/// PopupWindowHelper class can convert a standard form into
	/// a popup.  This form probably doesn't have the sort of
	/// UI you would use in a real popup window, its just here
	/// for demonstration.
	/// </summary>
	public class frmPopup : System.Windows.Forms.Form
	{
		/// <summary>
		/// The selected item in the ListView
		/// </summary>
		private string selectedItem = "";

		private System.Windows.Forms.ColumnHeader colName;
		private System.Windows.Forms.ColumnHeader colDate;
		private System.Windows.Forms.ListView lvwDemo;
		private System.Windows.Forms.Button btnFind;
		private System.Windows.Forms.TextBox txtFind;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary>
		/// Create a new instance of this form and populate the
		/// controls.
		/// </summary>
		public frmPopup()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			for (int i = 0; i < 20; i++)
			{
				ListViewItem item = new ListViewItem(String.Format("Test {0}", i));
				item.SubItems.Add(String.Format("{0:d}", DateTime.Now));
				lvwDemo.Items.Add(item);
			}
			this.lvwDemo.Click += new EventHandler(lvwDemo_Click);
			this.lvwDemo.KeyDown += new KeyEventHandler(lvwDemo_KeyDown);

			this.Size = new Size(lvwDemo.Right + lvwDemo.Left, btnFind.Bottom + lvwDemo.Left);

			lvwDemo.Select();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lvwDemo = new System.Windows.Forms.ListView();
			this.colName = new System.Windows.Forms.ColumnHeader();
			this.colDate = new System.Windows.Forms.ColumnHeader();
			this.btnFind = new System.Windows.Forms.Button();
			this.txtFind = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// lvwDemo
			// 
			this.lvwDemo.AllowColumnReorder = true;
			this.lvwDemo.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																					  this.colName,
																					  this.colDate});
			this.lvwDemo.FullRowSelect = true;
			this.lvwDemo.HideSelection = false;
			this.lvwDemo.Location = new System.Drawing.Point(4, 4);
			this.lvwDemo.MultiSelect = false;
			this.lvwDemo.Name = "lvwDemo";
			this.lvwDemo.Size = new System.Drawing.Size(280, 216);
			this.lvwDemo.TabIndex = 0;
			this.lvwDemo.View = System.Windows.Forms.View.Details;
			// 
			// colName
			// 
			this.colName.Width = 128;
			// 
			// colDate
			// 
			this.colDate.Width = 96;
			// 
			// btnFind
			// 
			this.btnFind.Location = new System.Drawing.Point(236, 224);
			this.btnFind.Name = "btnFind";
			this.btnFind.Size = new System.Drawing.Size(48, 24);
			this.btnFind.TabIndex = 2;
			this.btnFind.Text = "&Find...";
			this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
			// 
			// txtFind
			// 
			this.txtFind.Location = new System.Drawing.Point(4, 224);
			this.txtFind.Name = "txtFind";
			this.txtFind.Size = new System.Drawing.Size(224, 21);
			this.txtFind.TabIndex = 1;
			this.txtFind.Text = "";
			// 
			// frmPopup
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(292, 252);
			this.ControlBox = false;
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.txtFind,
																		  this.btnFind,
																		  this.lvwDemo});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmPopup";
			this.ShowInTaskbar = false;
			this.TopMost = true;
			this.Load += new System.EventHandler(this.frmPopup_Load);
			this.ResumeLayout(false);

		}
		#endregion


		/// <summary>
		/// Paint the form and draw a neat border.
		/// </summary>
		/// <param name="e">Information about the paint event</param>
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			Rectangle borderRect = new Rectangle(this.ClientRectangle.Location, this.ClientRectangle.Size);
			borderRect.Width -= 1;
			borderRect.Height -= 1;
			e.Graphics.DrawRectangle(SystemPens.ControlDark, borderRect);			
		}

		/// <summary>
		/// Responds to Find button clicks.
		/// </summary>
		/// <param name="sender">Button which was clicked</param>
		/// <param name="e">Not used</param>
		private void btnFind_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show(this, "Perform a find on the text here.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		/// <summary>
		/// Checks if an item is selected in the ListView, if so, 
		/// stores the value and closes the form.
		/// </summary>
		private void selectItem()
		{
			if (lvwDemo.SelectedItems.Count > 0)
			{
				this.selectedItem = lvwDemo.Items[lvwDemo.SelectedIndices[0]].Text;
				this.Close();
			}
		}

		/// <summary>
		/// Gets/sets the item selected in the ListView.
		/// </summary>
		public string SelectedItem
		{
			get
			{
				return this.selectedItem;
			}
			set
			{
				this.selectedItem = value;
			}
		}

		/// <summary>
		/// Respond to clicks on an item in the ListView control.
		/// </summary>
		/// <param name="sender">ListView control which was clicked</param>
		/// <param name="e">Not used</param>
		private void lvwDemo_Click(object sender, System.EventArgs e)
		{
			// If an item has been selected by clicking, then close
			selectItem();
		}

		/// <summary>
		/// Respond to key down events in the ListView control.
		/// </summary>
		/// <param name="sender">ListView control which received the key event</param>
		/// <param name="e">Information about the key that was depressed.</param>
		private void lvwDemo_KeyDown(object sender, KeyEventArgs e)
		{
			// If an item is selected and we get a return, then close
			if (e.KeyCode == Keys.Return)
			{
				selectItem();
			}
		}

		/// <summary>
		/// Select the correct item in the ListView and make it
		/// visible.  We must wait until the form is loaded otherwise the ListViewItem
		/// <see cref="EnsureVisible"/> method will be ignored.
		/// </summary>
		/// <param name="sender">This form</param>
		/// <param name="e">Not used</param>
		private void frmPopup_Load(object sender, System.EventArgs e)
		{
			foreach (ListViewItem itm in lvwDemo.Items)
			{
				if (itm.Text.Equals(selectedItem))
				{
					itm.Selected = true;
					itm.EnsureVisible();
					break;
				}
			}
		}


	}
}
