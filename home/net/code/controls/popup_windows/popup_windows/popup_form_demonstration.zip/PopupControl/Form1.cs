using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace PopupControl
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		[DllImport("user32", CharSet = CharSet.Auto)]
		private extern static int PostMessage(IntPtr handle, int msg, int wParam, IntPtr lParam);

		[DllImport("user32", CharSet = CharSet.Auto)]
		private extern static int SendMessage(IntPtr handle, int msg, int wParam, IntPtr lParam);

		private PopupMessageFilter filter = null;
		private EventHandler popClosedHandler = null;

		private bool locked = false;

		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			filter = new PopupMessageFilter();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(40, 28);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(68, 20);
			this.button1.TabIndex = 0;
			this.button1.Text = "button1";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(192, 84);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(52, 32);
			this.button2.TabIndex = 1;
			this.button2.Text = "button2";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.button2,
																		  this.button1});
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion



		private void button1_Click(object sender, System.EventArgs e)
		{

			frmPopup pop = new frmPopup();
			this.AddOwnedForm(pop);
			

			filter.StartPopup(pop);
			Application.AddMessageFilter(filter);

			popClosedHandler = new EventHandler(pop_Closed);
			pop.Closed += popClosedHandler;
			pop.StartPosition = FormStartPosition.Manual;
			pop.Location = this.PointToScreen(new Point(button1.Left, button1.Bottom));
			pop.Show();


		}

		private void pop_Closed(object sender, EventArgs e)
		{
			((Form) sender).Closed -= popClosedHandler;
			Application.RemoveMessageFilter(filter);
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
		
		}

		protected override void WndProc(ref Message m)
		{
			if (m.Msg == 0x086)
			{
				base.WndProc(ref m);
				if (((int) m.WParam) == 0)
				{
					SendMessage(this.Handle, 0x086, 1, IntPtr.Zero);
				}
			}
			else
			{
				base.WndProc(ref m);
			}
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			Form2 f = new Form2();
			f.Show();
		}		
	}
}
