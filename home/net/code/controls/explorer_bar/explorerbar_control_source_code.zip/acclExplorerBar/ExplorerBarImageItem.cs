using System;
using System.Drawing;
using vbAccelerator.Components.Controls.ExplorerBarFramework;

namespace vbAccelerator.Components.Controls
{
	/// <summary>
	/// Implements an ExplorerBarItem which displays an image.  The Image is
	/// centred and scaled if necessary to fit the available space in the
	/// bar.  Note that although scaling is performed drawing may be slow
	/// if you associate a large image with the item: it is preferrable to
	/// scale the image to a reasonable size before assigning it to an
	/// item of this type.
	/// </summary>
	public class ExplorerBarImageItem : ExplorerBarItem
	{
		private Image image = null;	

		/// <summary>
		/// Construct a new instance of this class.
		/// </summary>
		public ExplorerBarImageItem() : base()
		{
		}

		/// <summary>
		/// Creates a clone of this item.
		/// </summary>
		/// <returns>Cloned item</returns>
		public override object Clone()
		{
			ExplorerBarImageItem cloned = new ExplorerBarImageItem();
			CloneFields(cloned);
			return cloned;
		}

		/// <summary>
		/// Determines whether this object should respond to the specified mnemonic
		/// key
		/// </summary>
		/// <param name="charCode">Mnemonic key character code</param>
		/// <returns><c>true</c> if should respond to the key, <c>false</c>
		/// otherwise.</returns>
		public override bool ContainsMnemonic(char charCode)
		{
			return false;
		}

		/// <summary>
		/// Gets whether the control can get input focus.
		/// </summary>
		public override bool ShowFocus
		{
			get
			{
				return false;
			}
		}

		/// <summary>
		/// Gets whether this item is clickable or not
		/// </summary>
		public override bool Clickable
		{
			get
			{
				return false;
			}
		}

		/// <summary>
		/// Gets/sets an Image which is drawn for this item.
		/// </summary>
		public System.Drawing.Image Image
		{
			get
			{
				return image;
			}
			set
			{
				image = value;
				OnSizeChanged();
			}
		}

		/// <summary>
		/// Draws the image associated with this item, if any.
		/// </summary>
		/// <param name="drawItemParams">Class specifying details needed to draw
		/// the item</param>
		protected override void DrawItem(
			ExplorerBarDrawItemParams drawItemParams
			)
		{			
			if (image != null)
			{
				int availWidth = (drawItemParams.ScrollShowing ? drawItemParams.WidthWithScroll : drawItemParams.WidthWithoutScroll);
				availWidth -= MarginSize * 4;
				int imageWidth = image.Width;
				if (imageWidth > availWidth)
				{
					Rectangle imagePosition = new Rectangle(
						MarginSize * 2, drawItemParams.Top, 
						availWidth, image.Height * (availWidth / imageWidth));						
					drawItemParams.Graphics.DrawImage(
						image, imagePosition, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel);
				}
				else
				{
					Point imagePosition = new Point(
						MarginSize * 2 + (availWidth - image.Width) / 2, 
						drawItemParams.Top);
					drawItemParams.Graphics.DrawImageUnscaled(image, 
						imagePosition.X, imagePosition.Y);
				}
			}
		}


		/// <summary>
		/// Called by the owning control to measure this item.
		/// </summary>
		/// <param name="measureItemParams">Class specifying details required to 
		/// measure the item.</param>
		protected override void MeasureItem(
			ExplorerBarMeasureItemParams measureItemParams
			)
		{
			int calcHeightWithoutScroll = 0;
			int calcHeightWithScroll = 0;
			int calcWidthWithScroll = 0;
			int calcWidthWithoutScroll = 0;

			if (image != null)
			{
				calcHeightWithoutScroll = image.Height;
				calcHeightWithScroll = image.Height;
				calcWidthWithScroll = image.Width;
				calcWidthWithoutScroll = image.Width;

				int measureWidth = measureItemParams.WidthWithoutScroll - MarginSize * 4;
				if (image.Width > measureWidth)
				{
					calcHeightWithoutScroll = calcHeightWithoutScroll * (measureWidth / image.Width);
					calcWidthWithoutScroll = measureWidth;
				}
				measureWidth = measureItemParams.WidthWithScroll - MarginSize * 4;
				if (image.Width > measureWidth)
				{
					calcHeightWithScroll = calcHeightWithScroll * (measureWidth / image.Width);
					calcWidthWithScroll = measureWidth;
				}
			}

			HeightWithScroll = calcHeightWithScroll;
			HeightWithoutScroll = calcHeightWithoutScroll;
			WidthWithScroll = calcWidthWithScroll;
			WidthWithoutScroll = calcWidthWithoutScroll;

		}

		/// <summary>
		/// Clones the fields associated with this object.  Used to support the
		/// Clone method.
		/// </summary>
		/// <param name="cloneTo">Object to clone fields to.</param>
		protected override void CloneFields(ExplorerBarItem cloneTo)
		{
			base.CloneFields(cloneTo);
			ExplorerBarImageItem imageItem = (ExplorerBarImageItem) cloneTo;
			imageItem.Image = image;
		}


	}
}
