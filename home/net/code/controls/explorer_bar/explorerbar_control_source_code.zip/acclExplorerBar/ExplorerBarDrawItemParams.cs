using System;
using System.Drawing;

namespace vbAccelerator.Components.Controls.ExplorerBarFramework
{
	/// <summary>
	/// Provides references to parameters needed to draw a bar or item
	/// on the surface of the ExplorerBar control.
	/// </summary>
	public class ExplorerBarDrawItemParams
	{
		private System.Drawing.Graphics graphics;
		private System.Windows.Forms.ImageList titleImageList;
		private System.Windows.Forms.ImageList imageList;
		private System.Drawing.Font defaultFont;
		private int widthWithoutScroll;
		private int widthWithScroll;
		private bool scrollShowing;
		private ExplorerBarDrawingStyle style;
		private ExplorerBarMode mode;
		private bool rightToLeft;
		private int top;
		private Bitmap animationBitmap;
		private bool showFocusCues;
		private bool showKeyboardCues;

		/// <summary>
		/// Gets the <see cref="Graphics"/> object to draw onto.
		/// </summary>
		public System.Drawing.Graphics Graphics
		{
			get
			{
				return graphics;
			}
		}

		/// <summary>
		/// Gets the <see cref="ImageList"/> to use for the Title of
		/// the bars.
		/// </summary>
		public System.Windows.Forms.ImageList TitleImageList
		{
			get
			{
				return titleImageList;
			}
		}

		/// <summary>
		/// Gets the ImageList to use for items in the bar.
		/// </summary>
		public System.Windows.Forms.ImageList ImageList
		{
			get
			{
				return imageList;
			}
		}

		/// <summary>
		/// Gets the default font to draw items with.
		/// </summary>
		public System.Drawing.Font DefaultFont
		{
			get
			{
				return defaultFont;
			}
		}

		/// <summary>
		/// Gets the client width of the control when the scroll bar is not showing.
		/// </summary>
		public int WidthWithoutScroll
		{
			get
			{
				return widthWithoutScroll;
			}
		}

		/// <summary>
		/// Gets the client width of the control when the scroll bar is showing.
		/// </summary>
		public int WidthWithScroll
		{
			get
			{
				return widthWithScroll;
			}
		}

		/// <summary>
		/// Gets the drawing style currently in effect for the control.
		/// </summary>
		public ExplorerBarDrawingStyle Style
		{
			get
			{
				return style;
			}
		}

		/// <summary>
		/// Gets the drawing mode currently in effect for the control.
		/// </summary>
		public ExplorerBarMode Mode
		{
			get
			{
				return mode;
			}
		}

		/// <summary>
		/// Gets whether the control's contents should be rendered Right - Left.
		/// </summary>
		public bool RightToLeft
		{
			get
			{
				return rightToLeft;
			}
		}

		/// <summary>
		/// Gets whether the scroll bar is showing in the control.
		/// </summary>
		public bool ScrollShowing
		{
			get
			{
				return scrollShowing;
			}
		}

		/// <summary>
		/// Gets whether focus cues should be shown
		/// </summary>
		public bool ShowFocusCues
		{
			get
			{
				return showFocusCues;
			}
		}

		/// <summary>
		/// Gets whether keyboard cues should be shown
		/// </summary>
		public bool ShowKeyboardCues
		{
			get
			{
				return showKeyboardCues;
			}
		}

		/// <summary>
		/// Gets the current top position for drawing.
		/// </summary>
		public int Top
		{
			get
			{
				return top;
			}
		}

		/// <summary>
		/// Gets the offscreen bitmap used to render animations which is later
		/// composited onto the control using an alpha amount.
		/// </summary>
		public Bitmap AnimationBitmap
		{
			get
			{
				return animationBitmap;
			}
		}

		/// <summary>
		/// Sets the top position.
		/// </summary>
		/// <param name="top">New top position</param>
		public void SetTop(int top)
		{
			this.top = top;
		}
		
		/// <summary>
		/// Changes the graphics object to render to.  Classes calling this
		/// method should maintain a reference to the original graphics object
		/// associated with this class and reset it once drawing is complete.
		/// The intention of this method is to allow a bar to redirect drawing
		/// onto an offscreen graphics object used to composite to the animation
		/// bitmap.
		/// </summary>
		/// <param name="graphics">New Graphics object.</param>
		public void SetGraphics(Graphics graphics)
		{
			this.graphics = graphics;
		}

		/// <summary>
		/// Constructs a new instance of the class.
		/// </summary>
		/// <param name="graphics">Graphics object to render to</param>
		/// <param name="titleImageList">Image list to use for bar titles.</param>
		/// <param name="imageList">Image list to use for items.</param>
		/// <param name="defaultFont">Default Font to use.</param>
		/// <param name="widthWithoutScroll">Client width of the control when the 
		/// scroll bar is not showing.</param>
		/// <param name="widthWithScroll">Client width of the control when the scroll
		/// bar is showing.</param>
		/// <param name="scrollShowing">Whether the control is currently showing the
		/// scroll bar or not.</param>
		/// <param name="style">Drawing style in effect for the control.</param>
		/// <param name="mode">Drawing mode in effect for the control.</param>
		/// <param name="rightToLeft">Whether the control should be drawn Right to Left</param>
		/// <param name="top">Current top position in the Graphics object to render to</param>
		/// <param name="animationBitmap">Offscreen bitmap to render bars for animation
		/// to.</param>
		/// <param name="showFocusCues">Whether to show focus cues</param>
		/// <param name="showKeyboardCues">Whether to show keyboard cues</param>
		internal ExplorerBarDrawItemParams(
			System.Drawing.Graphics graphics,
			System.Windows.Forms.ImageList titleImageList,			
			System.Windows.Forms.ImageList imageList,			
			System.Drawing.Font defaultFont,
			int widthWithoutScroll,
			int widthWithScroll,
			bool scrollShowing,
			ExplorerBarDrawingStyle style,
			ExplorerBarMode mode,
			bool rightToLeft,
			int top,
			Bitmap animationBitmap,
			bool showFocusCues,
			bool showKeyboardCues
			)
		{
			this.graphics = graphics;
			this.titleImageList = titleImageList;
			this.imageList = imageList;
			this.defaultFont = defaultFont;
			this.widthWithoutScroll = widthWithoutScroll;
			this.widthWithScroll = widthWithScroll;
			this.style = style;
			this.mode = mode;
			this.rightToLeft = rightToLeft;
			this.scrollShowing = scrollShowing;
			this.top = top;
			this.animationBitmap = animationBitmap;
			this.showFocusCues = showFocusCues;
			this.showKeyboardCues = showKeyboardCues;
		}
	}
}
