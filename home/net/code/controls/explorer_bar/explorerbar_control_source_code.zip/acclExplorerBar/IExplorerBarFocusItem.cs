using System;

namespace vbAccelerator.Components.Controls.ExplorerBarFramework
{
	/// <summary>
	/// Specifies the interface that all bars and items in the control must
	/// support to interact with the focus.
	/// </summary>
	public interface IExplorerBarFocusItem
	{
		/// <summary>
		/// Gets whether this item can gain the focus and display it.
		/// </summary>
		bool ShowFocus
		{
			get;
		}

		/// <summary>
		/// Gets/sets whether this item is focused.
		/// </summary>
		bool Focused
		{
			get;
			set;
		}

		/// <summary>
		/// Determines whether the item contains the specified mnemonic
		/// character code.
		/// </summary>
		/// <param name="charCode">Mnemonic character code to check</param>
		/// <returns><c>true</c> if the item contains the code, <c>false</c>
		/// otherwise.</returns>
		bool ContainsMnemonic(Char charCode);

	}
}
