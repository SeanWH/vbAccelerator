using System;

namespace vbAccelerator.Components.Controls.ExplorerBarFramework
{
	/// <summary>
	/// Summary description for IExplorerBarControlItem.
	/// </summary>
	public interface IExplorerBarControlItem : IExplorerBarFocusItem, IExplorerBarMouseItem, ICloneable
	{
	}
}
