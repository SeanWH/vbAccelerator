using System;
using System.Drawing;
using System.Windows.Forms;
using vbAccelerator.Components.Controls.ExplorerBarFramework;
using vbAccelerator.Components.Controls.ExplorerBarUtility;

namespace vbAccelerator.Components.Controls
{
	/// <summary>
	/// Summary description for ExplorerBarRadioButtonItem.
	/// </summary>
	public class ExplorerBarRadioButtonItem : ExplorerBarItemWithText, IExplorerBarItemWithIcon
	{
		private bool enabled = true;
		private bool isChecked = false;
		private XpThemeAPI xpTheme = null;
		private int checkIconSize = 13;
		
		/// <summary>
		/// Constructs a new instance of the class.
		/// </summary>
		public ExplorerBarRadioButtonItem() : base()
		{
		}

		/// <summary>
		/// Gets whether this item can be clicked.
		/// </summary>
		public override bool Clickable
		{
			get
			{
				return enabled;
			}
		}

		/// <summary>
		/// Called when this item is clicked.
		/// </summary>
		public override void Click()
		{
			base.Click();
			if (!isChecked)
			{
				Checked = true;
			}
		}

		/// <summary>
		/// Returns a copy of this object
		/// </summary>
		/// <returns>Copy</returns>
		public override object Clone()
		{
			ExplorerBarRadioButtonItem cloned = new ExplorerBarRadioButtonItem();
			cloned.CloneFields(cloned);
			cloned.Checked = isChecked;
			cloned.Enabled = enabled;
			return cloned;
		}

		/// <summary>
		/// Gets/sets whether this item can get the input focus.
		/// </summary>
		public override bool ShowFocus
		{
			get
			{
				return enabled;
			}
		}

		/// <summary>
		/// Gets/sets whether this item is enabled or not
		/// </summary>
		public bool Enabled
		{
			get
			{
				return enabled;
			}
			set
			{
				enabled = value;
				OnAppearanceChanged();
			}
		}

		/// <summary>
		/// Gets/sets whether this item is checked.
		/// </summary>
		public bool Checked
		{
			get
			{
				return isChecked;
			}
			set
			{
				if (value)
				{
					// Find any other instances of this class in the 
					// bar and set checked off
					if (Owner != null)
					{
						ExplorerBar owningBar = Bar;
						if (owningBar != null)
						{
							foreach (ExplorerBarItem item in owningBar.Items)
							{
								if (typeof(ExplorerBarRadioButtonItem).IsAssignableFrom(item.GetType()))
								{
									if (item != this)
									{
										((ExplorerBarRadioButtonItem) item).Checked = false;
									}
								}
							}
						}
					}
				}
				isChecked = value;
				OnAppearanceChanged();	
			}
		}

		/// <summary>
		/// Draw the checkbox item
		/// </summary>
		/// <param name="drawItemParams">Object containing information </param>
		/// <param name="itemRectangle"></param>
		/// <returns></returns>
		public int DrawIcon(
			ExplorerBarDrawItemParams drawItemParams,
			Rectangle itemRectangle
			)
		{	
			Rectangle iconRectangle;

			if (UseXpTheme())
			{
				XpThemeAPI.UxThemeRadioButtonStates checkState;
				if (Enabled)
				{
					if (MouseOver || MouseDown)
					{
						if (Checked)
						{
							if (MouseDown)
							{
								checkState = XpThemeAPI.UxThemeRadioButtonStates.RBS_CHECKEDPRESSED;
							}
							else
							{
								checkState = XpThemeAPI.UxThemeRadioButtonStates.RBS_CHECKEDHOT;
							}
						}
						else
						{
							if (MouseDown)
							{
								checkState = XpThemeAPI.UxThemeRadioButtonStates.RBS_UNCHECKEDPRESSED;
							}
							else
							{
								checkState = XpThemeAPI.UxThemeRadioButtonStates.RBS_UNCHECKEDHOT;
							}
						}
					}
					else
					{
						if (Checked)
						{
							checkState = XpThemeAPI.UxThemeRadioButtonStates.RBS_CHECKEDNORMAL;
						}
						else
						{
							checkState = XpThemeAPI.UxThemeRadioButtonStates.RBS_UNCHECKEDNORMAL;
						}
					}
				}
				else
				{
					if (Checked)
					{
						checkState = XpThemeAPI.UxThemeRadioButtonStates.RBS_CHECKEDDISABLED;
					}
					else
					{
						checkState = XpThemeAPI.UxThemeRadioButtonStates.RBS_UNCHECKEDDISABLED;
					}
				}
				Size size = xpTheme.GetThemePartSize(drawItemParams.Graphics, 
					(int) XpThemeAPI.UxThemeButtonParts.BP_CHECKBOX, 
					(int) checkState);
				if (drawItemParams.RightToLeft)
				{
					iconRectangle = new Rectangle(
						itemRectangle.Right - size.Width - 2, 
						itemRectangle.Top + (itemRectangle.Height - size.Height) / 2, 
						size.Width,
						size.Height);
				}
				else
				{
					iconRectangle = new Rectangle(
						itemRectangle.Left + 2,
						itemRectangle.Top + (itemRectangle.Height - size.Height) / 2, 
						size.Width,
						size.Height);						
				}
				xpTheme.DrawThemeBackground(drawItemParams.Graphics, iconRectangle, 
					(int) XpThemeAPI.UxThemeButtonParts.BP_RADIOBUTTON, 
					(int) checkState);
			}
			else
			{
				ButtonState state;
				if (Checked)
				{
					state = ButtonState.Checked;
				}
				else
				{
					state = ButtonState.Normal;
				}
				if (!Enabled)
				{
					state |= ButtonState.Inactive;
				}
				if (drawItemParams.RightToLeft)
				{
					iconRectangle = new Rectangle(
						itemRectangle.Right - checkIconSize - 2, 
						itemRectangle.Top + (itemRectangle.Height - checkIconSize) / 2, 
						checkIconSize, checkIconSize);
				}
				else
				{
					iconRectangle = new Rectangle(
						itemRectangle.Left + 2,
						itemRectangle.Top + (itemRectangle.Height - checkIconSize) / 2, 
						checkIconSize, checkIconSize);						
				}
				ControlPaint.DrawCheckBox(drawItemParams.Graphics, iconRectangle, state);
			}

			return iconRectangle.Width + 4;
		}

		/// <summary>
		/// Measure the check box icon
		/// </summary>
		/// <param name="measureItemParams">Object containing information needed to 
		/// measure the icon</param>
		/// <returns>Size of the check box icon</returns>
		public Size MeasureIcon(			
			ExplorerBarMeasureItemParams measureItemParams
			)
		{
			Size iconSize;
			if (UseXpTheme())
			{
				iconSize = xpTheme.GetThemePartSize(measureItemParams.Graphics, 
					(int) XpThemeAPI.UxThemeButtonParts.BP_CHECKBOX, 
					(int) XpThemeAPI.UxThemeCheckBoxStates.CBS_CHECKEDHOT);
			}
			else
			{
				iconSize = new Size(checkIconSize, checkIconSize);
			}
			return iconSize;
		}

		private bool UseXpTheme()
		{
			if (xpTheme == null)
			{
				if (Owner != null)
				{
					xpTheme = new XpThemeAPI(Owner.Handle, "BUTTON");
				}
				else
				{
					return false;
				}
			}
			return (!xpTheme.hTheme.Equals(IntPtr.Zero));			
		}



		/// <summary>
		/// Draws the item.
		/// </summary>
		/// <param name="drawItemParams">Object. specifying details needed to draw 
		/// item</param>
		protected override void DrawItem(
			ExplorerBarDrawItemParams drawItemParams
			)
		{
			base.DrawItem(this, drawItemParams);
		}

		/// <summary>
		/// Draws the item.
		/// </summary>
		/// <param name="drawItemParams">Object. specifying details needed to draw 
		/// item</param>
		protected override void MeasureItem(
			ExplorerBarMeasureItemParams drawItemParams
			)
		{
			base.MeasureItem(this, drawItemParams);
		}


	}
}
