using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using vbAccelerator.Components.Controls.ExplorerBarFramework;

namespace vbAccelerator.Components.Controls
{
	/// <summary>
	/// An abstract class which all items within the Explorer Bar control
	/// must derive from.  
	/// </summary>
	public abstract class ExplorerBarItem : IExplorerBarControlItem
	{
		/// <summary>
		/// Instance of the <see cref="acclExplorerBar"/> control
		/// which owns this item.
		/// </summary>
		private acclExplorerBar owner = null;

		private object tag = null;
		private string toolTipText = "";
		private int spacingAfter = 0;

		private int marginSize = 12;
		private int heightWithScroll = 0;
		private int heightWithoutScroll = 0;
		private int widthWithScroll = 0;
		private int widthWithoutScroll = 0;
		private int top = 0;

		private bool mouseDown = false;		
		private bool mouseOver = false;
		private bool hasFocus = false;

		/// <summary>
		/// Constructs a new, default instance of this class.
		/// </summary>
		public ExplorerBarItem()
		{
		}

		#region Interface implementation
		/// <summary>
		/// Creates a clone of this object.
		/// </summary>
		/// <returns>Cloned object</returns>
		public abstract object Clone();

		/// <summary>
		/// Determines whether the specified location hits this Item.
		/// </summary>
		/// <param name="location">Point to test</param>
		/// <param name="width">Client width of the owning control.</param>
		/// <param name="scrollShowing">Whether the scroll bar is showing or not</param>
		/// <returns><c>true</c> if the point is within this item, <c>false</c> otherwise</returns>
		public bool HitTest(Point location, int width, bool scrollShowing)
		{
			bool hitTest = false;
			int checkHeight = (scrollShowing ? heightWithScroll : heightWithoutScroll);
			if ((location.Y >= top) && (location.Y <= top + checkHeight))
			{
				int checkWidth = (scrollShowing ? widthWithScroll : widthWithoutScroll);
				if ((location.X >= marginSize * 2) && (location.X <= marginSize * 4 + checkWidth))
				{
					hitTest = true;
				}
			}
			return hitTest;
		}		
		
		/// <summary>
		/// Gets/sets whether this item has the focus
		/// </summary>
		public virtual bool Focused
		{
			get
			{
				return hasFocus;
			}
			set
			{
				hasFocus = value;
				if (value)
				{
					if ((owner != null) && (value))
					{
						owner.InternalOnItemFocus(this);
					}
					EnsureVisible();
				}
				OnAppearanceChanged();
			}
		}

		/// <summary>
		/// Determines whether this item contains the specified mnemonic
		/// </summary>
		/// <param name="charCode">Mnemonic key</param>
		/// <returns><c>true</c> if the item contains the mnemonic, <c>false</c>
		/// otherwise.</returns>
		public abstract bool ContainsMnemonic(char charCode);
		
		/// <summary>
		/// Gets whether the control can get input focus.
		/// </summary>
		public abstract bool ShowFocus
		{
			get;
		}

		/// <summary>
		/// Gets/sets whether the mouse is over the item
		/// </summary>
		public bool MouseOver
		{
			get
			{
				return mouseOver;
			}
			set
			{
				if (mouseOver != value)
				{
					mouseOver = value;
					if (value)
					{
						owner.InternalOnItemMouseOver(this);
					}
					OnAppearanceChanged();
				}
			}
		}

		/// <summary>
		/// Gets/sets whether the mouse is down on the item
		/// </summary>
		public bool MouseDown
		{
			get
			{
				return mouseDown;
			}
			set
			{
				if (mouseDown != value)
				{
					mouseDown = value;
					if (value)
					{
						Focused = value;
					}
					if (value)
					{
						owner.InternalOnItemMouseDown(this);
					}
					OnAppearanceChanged();
				}
			}
		}

		/// <summary>
		/// Gets whether this item can be clicked to perform an action.
		/// </summary>
		public abstract bool Clickable
		{
			get;
		}

		/// <summary>
		/// Called when the item is clicked
		/// </summary>
		public virtual void Click()
		{
		}
		#endregion
			
		/// <summary>
		/// Gets the Bar which owns this item, if any.
		/// </summary>
		public ExplorerBar Bar
		{
			get
			{
				return owner.InternalBarForItem(this);
			}
		}

		/// <summary>
		/// Gets/sets an object to be associated with this Item.
		/// </summary>
		public object Tag
		{
			get
			{
				return tag;
			}
			set
			{
				tag = value;
			}
		}


		/// <summary>
		/// Gets/sets the tool tip text to be shown when the mouse hovers
		/// over this item.
		/// </summary>
		public String ToolTipText
		{
			get
			{
				return toolTipText;
			}
			set
			{
				toolTipText = value;
			}
		}

		/// <summary>
		/// Gets/sets the space to add after this item.
		/// </summary>
		public int SpacingAfter
		{
			get
			{
				return spacingAfter;
			}
			set
			{
				if (spacingAfter != value)
				{
					spacingAfter = value;
					OnSizeChanged();
				}
			}
		}

		/// <summary>
		/// Ensures that this item is visible in the control.
		/// </summary>				 
		public void EnsureVisible()
		{
			if (owner != null)
			{
				owner.InternalEnsureVisible(this);
			}
		}


		/// <summary>
		/// Notifies the owner that the size of this item may have changed and it needs to
		/// be remeasured.
		/// </summary>
		protected virtual void OnSizeChanged()
		{
			if (owner != null)
			{
				owner.InternalOnItemSizeChanged(this);
			}
		}

		/// <summary>
		/// Notifies the owner that the appearance of this item has changed and it needs to
		/// be redrawn.
		/// </summary>
		protected virtual void OnAppearanceChanged()
		{
			if (owner != null)
			{
				owner.InternalOnItemRedraw(this);
			}
		}

		/// <summary>
		/// Sets the Owning Explorer Bar control for this item or bar.
		/// </summary>
		/// <param name="newOwner">Explorer Bar control to make
		/// the owner of this object.</param>
		public virtual void SetOwner(acclExplorerBar newOwner)
		{
			if ((owner == null) || (owner != newOwner))
			{
				if (owner != null)
				{
					owner.InternalOnItemRemoved(this);
				}
				owner = newOwner;
				// notify control that we're there...
				if (owner != null)
				{
					owner.InternalOnItemAdd(this);
				}
			}
		}

		/// <summary>
		/// Called by the owning control to measure this item.
		/// </summary>
		/// <param name="measureItemParams">Class specifying details required to 
		/// measure the item.</param>
		internal void InternalMeasureItem(
			ExplorerBarMeasureItemParams measureItemParams
			)
		{
			MeasureItem(measureItemParams);
		}

		/// <summary>
		/// Called by the owning control to measure this item.
		/// </summary>
		/// <param name="measureItemParams">Class specifying details required to 
		/// measure the item.</param>
		protected abstract void MeasureItem(
			ExplorerBarMeasureItemParams measureItemParams
			);

		/// <summary>
		/// Called by the owning control to draw this item.
		/// </summary>
		/// <param name="drawItemParams">Class specifying details required to 
		/// draw the item.</param>
		internal void InternalDrawItem(
			ExplorerBarDrawItemParams drawItemParams
			)
		{
			top = drawItemParams.Top;
			DrawItem(drawItemParams);
		}

		/// <summary>
		/// Called by the owning control to draw this item.
		/// </summary>
		/// <param name="drawItemParams">Class specifying details required to 
		/// draw the item.</param>
		protected abstract void DrawItem(
			ExplorerBarDrawItemParams drawItemParams
			);

		/// <summary>
		/// Clones the fields associated with this object.  Used to supports the
		/// Clone method for concrete instances of the class.
		/// </summary>
		/// <param name="cloneTo">Object to clone fields to.</param>
		protected virtual void CloneFields(ExplorerBarItem cloneTo)
		{
			cloneTo.SpacingAfter = spacingAfter;
			cloneTo.Tag = tag;
			cloneTo.ToolTipText = toolTipText;			
		}

		/// <summary>
		/// Gets the left and right margin size for this item
		/// </summary>
		protected virtual int MarginSize
		{
			get
			{
				return marginSize;
			}
		}

		/// <summary>
		/// Gets/sets the height of this item when the scroll bar is showing.
		/// Implementations should set this member in the override of 
		/// <see cref="MeasureItem"/> procedure.
		/// </summary>
		public virtual int HeightWithScroll
		{
			get
			{
				return heightWithScroll;
			}
			set
			{
				heightWithScroll = value;
			}
		}

		/// <summary>
		/// Gets/sets the height of this item when the scroll bar is not
		/// showing. Implementations should set this member in the 
		/// override of the <see cref="MeasureItem"/> procedure.
		/// </summary>
		public virtual int HeightWithoutScroll
		{
			get
			{
				return heightWithoutScroll;
			}
			set
			{
				heightWithoutScroll = value;
			}
		}

		/// <summary>
		/// Gets/sets the total width of this item when the scroll
		/// bar is showing. Implementations should set this member in the override of 
		/// <see cref="MeasureItem"/> procedure.
		/// </summary>
		protected virtual int WidthWithScroll
		{
			get
			{
				return widthWithScroll;
			}
			set
			{
				widthWithScroll = value;
			}
		}

		/// <summary>
		/// Gets/sets the total width of this item when the scroll
		/// bar is not showing. Implementations should set this member in the override of 
		/// <see cref="MeasureItem"/> procedure.
		/// </summary>
		protected virtual int WidthWithoutScroll
		{
			get
			{
				return widthWithoutScroll;
			}
			set
			{
				widthWithoutScroll = value;
			}
		}

		/// <summary>
		/// Gets the location of the top of this item relative to the control.
		/// This is provided to allow items to position child controls relative
		/// to the control. 
		/// </summary>
		protected int Top
		{
			get
			{
				return top;
			}
		}

		/// <summary>
		/// Gets the control which currently owns this item.
		/// </summary>
		protected acclExplorerBar Owner
		{
			get
			{
				return owner;
			}
		}

	}
}
