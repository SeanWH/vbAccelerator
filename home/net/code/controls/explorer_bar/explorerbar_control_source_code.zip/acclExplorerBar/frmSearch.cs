using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace vbAccelerator.Components.Controls
{
	/// <summary>
	/// Demonstrates using the Explorer Bar control to create a Windows XP
	/// Explorer Search style interface.
	/// </summary>
	public class frmSearch : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox txtFileName;
		private System.Windows.Forms.TextBox txtWord;
		private System.Windows.Forms.ComboBox cboLookIn;
		private System.Windows.Forms.Panel pnlDateRange;
		private System.Windows.Forms.ComboBox cboDates;
		private System.Windows.Forms.Label lblFrom;
		private System.Windows.Forms.DateTimePicker dtpFrom;
		private System.Windows.Forms.DateTimePicker dtpTo;
		private System.Windows.Forms.Label lblTo;
		private System.Windows.Forms.ComboBox cboSize;
		private System.Windows.Forms.NumericUpDown numericUpDown1;
		private System.Windows.Forms.Button btnSearch;
		private vbAccelerator.Components.Controls.acclExplorerBar barSearch;
		private System.Windows.Forms.Panel pnlSizeRange;
		private System.Windows.Forms.ComboBox cboTypeOfFile;
		private System.Windows.Forms.TextBox txtClient;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;		

		private void LoadSearchBar()
		{
			// Set the search mode.  This runs multiple bars together
			// into the same container.
			barSearch.Mode = ExplorerBarMode.Search;

			// Some convenience variables to use:
			ExplorerBarLinkItem linkItem;
			ExplorerBarTextItem textItem;
			ExplorerBarControlHolderItem controlItem;
			ExplorerBarCheckButtonItem checkItem;
			ExplorerBarRadioButtonItem radioItem;
			ExplorerBar bar;
			RadioCheckHandler handler;

			// Add main search criteria
			bar = new ExplorerBar();
			bar.CanExpand = false;				
			bar.Text = "Search by any or all of the criteria below.";
			
			textItem = new ExplorerBarTextItem();
			textItem.Text = "All or part of the file name:";
			bar.Items.Add(textItem);
			
			controlItem = new ExplorerBarControlHolderItem();
			controlItem.Control = this.txtFileName;
			bar.Items.Add(controlItem);

			textItem = new ExplorerBarTextItem();
			textItem.Text = "A word or phrase in the file:";
			bar.Items.Add(textItem);
			
			controlItem = new ExplorerBarControlHolderItem();
			controlItem.Control = this.txtWord;
			bar.Items.Add(controlItem);
			
			textItem = new ExplorerBarTextItem();
			textItem.Text = "Look in:";
			bar.Items.Add(textItem);
			
			controlItem = new ExplorerBarControlHolderItem();
			controlItem.Control = this.cboLookIn;				
			bar.Items.Add(controlItem );

			barSearch.Bars.Add(bar);


			// Add modified criteria:
			bar = new ExplorerBar();
			bar.Text = "When was it modified?";
			bar.State = ExplorerBarState.Collapsed;

			radioItem = new ExplorerBarRadioButtonItem();
			radioItem.Bold = true;
			radioItem.Checked = true;
			radioItem.Text = "Don't remember";
			handler = new RadioCheckHandler(pnlDateRange, false);
			radioItem.Tag = handler;
			bar.Items.Add(radioItem);

			radioItem = new ExplorerBarRadioButtonItem();
			radioItem.Text = "Within the last week";
			handler = new RadioCheckHandler(pnlDateRange, false);
			radioItem.Tag = handler;
			bar.Items.Add(radioItem);
			
			radioItem = new ExplorerBarRadioButtonItem();
			radioItem.Text = "Past month";
			handler = new RadioCheckHandler(pnlDateRange, false);
			radioItem.Tag = handler;
			bar.Items.Add(radioItem);
			
			radioItem = new ExplorerBarRadioButtonItem();
			radioItem.Text = "Within the past year";
			handler = new RadioCheckHandler(pnlDateRange, false);
			radioItem.Tag = handler;
			bar.Items.Add(radioItem);

			radioItem = new ExplorerBarRadioButtonItem();
			radioItem.Text = "Specify dates";
			handler = new RadioCheckHandler(pnlDateRange, true);
			radioItem.Tag = handler;
			bar.Items.Add(radioItem);			

			controlItem = new ExplorerBarControlHolderItem();
			controlItem.Control = this.pnlDateRange;
			bar.Items.Add(controlItem);
		
			barSearch.Bars.Add(bar);
			bar.State = ExplorerBarState.Collapsed;			

			// Add size criteria
			bar = new ExplorerBar();
			bar.Text = "What size is it?";
			bar.State = ExplorerBarState.Collapsed;

			radioItem = new ExplorerBarRadioButtonItem();
			radioItem.Bold = true;
			radioItem.Checked = true;
			radioItem.Text = "Don't remember";
			handler = new RadioCheckHandler(pnlSizeRange, false);
			radioItem.Tag = handler;
			bar.Items.Add(radioItem);

			radioItem = new ExplorerBarRadioButtonItem();
			radioItem.Text = "Small (less than 100KB)";
			handler = new RadioCheckHandler(pnlSizeRange, false);
			radioItem.Tag = handler;
			bar.Items.Add(radioItem);

			radioItem = new ExplorerBarRadioButtonItem();
			radioItem.Text = "Medium (less than 1MB)";
			handler = new RadioCheckHandler(pnlSizeRange, false);
			radioItem.Tag = handler;
			bar.Items.Add(radioItem);

			radioItem = new ExplorerBarRadioButtonItem();
			radioItem.Text = "Large (more than 1MB)";
			radioItem.Tag = pnlSizeRange;
			handler = new RadioCheckHandler(pnlSizeRange, false);
			radioItem.Tag = handler;
			bar.Items.Add(radioItem);

			controlItem = new ExplorerBarControlHolderItem();
			controlItem.Control = pnlSizeRange;
			handler = new RadioCheckHandler(pnlSizeRange, true);
			radioItem.Tag = handler;
			bar.Items.Add(controlItem );
		
			barSearch.Bars.Add(bar);
			bar.State = ExplorerBarState.Collapsed;


			// Add advanced criteria
			bar = new ExplorerBar();
			bar.Text = "More advanced options";
			bar.State = ExplorerBarState.Collapsed;

			textItem = new ExplorerBarTextItem();
			textItem.Text = "Type of file:";
			bar.Items.Add(textItem);

			controlItem = new ExplorerBarControlHolderItem();
			controlItem.Control = cboTypeOfFile;
			bar.Items.Add(controlItem);

			checkItem = new ExplorerBarCheckButtonItem();
			checkItem.Bold = true;
			checkItem.Text = "Search system folders";
			checkItem.Checked = true;
			bar.Items.Add(checkItem);

			checkItem = new ExplorerBarCheckButtonItem();
			checkItem.Text = "Search hidden files and folders";
			bar.Items.Add(checkItem);

			checkItem = new ExplorerBarCheckButtonItem();
			checkItem.Bold = true;
			checkItem.Text = "Search subfolders";
			checkItem.Checked = true;
			bar.Items.Add(checkItem);

			checkItem = new ExplorerBarCheckButtonItem();
			checkItem.Text = "Case sensitive";
			bar.Items.Add(checkItem);

			checkItem = new ExplorerBarCheckButtonItem();
			checkItem.Text = "Search tape backup";
			bar.Items.Add(checkItem);

			barSearch.Bars.Add(bar);
			bar.State = ExplorerBarState.Collapsed;

			
			// Add the remainder of the options and the button to trigger searching
			bar = new ExplorerBar();
			bar.CanExpand = false;

			linkItem = new ExplorerBarLinkItem();
			linkItem.Text = "Other search options";
			bar.Items.Add(linkItem);

			linkItem = new ExplorerBarLinkItem();
			linkItem.Text = "Change preferences";
			bar.Items.Add(linkItem);

			controlItem = new ExplorerBarControlHolderItem();
			controlItem.Control = btnSearch;
			bar.Items.Add(controlItem);

			barSearch.Bars.Add(bar);


			// Set up some events:
			pnlDateRange.SizeChanged += new EventHandler(containerControl_SizeChanged);
			setColours(pnlDateRange);
			pnlSizeRange.SizeChanged += new EventHandler(containerControl_SizeChanged);
			setColours(pnlSizeRange);

			barSearch.ItemClick += new ExplorerBarItemClickEventHandler(barSearch_ItemClick);

		}

		private void setColours(Panel panel)
		{
			panel.BackColor =  Color.FromKnownColor(KnownColor.InactiveCaptionText);
		}

		/// <summary>
		/// Creates a new instance of this form
		/// </summary>
		public frmSearch()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// Load initial search bar
			LoadSearchBar();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.barSearch = new vbAccelerator.Components.Controls.acclExplorerBar();
			this.txtFileName = new System.Windows.Forms.TextBox();
			this.txtWord = new System.Windows.Forms.TextBox();
			this.cboLookIn = new System.Windows.Forms.ComboBox();
			this.pnlDateRange = new System.Windows.Forms.Panel();
			this.dtpTo = new System.Windows.Forms.DateTimePicker();
			this.lblTo = new System.Windows.Forms.Label();
			this.dtpFrom = new System.Windows.Forms.DateTimePicker();
			this.lblFrom = new System.Windows.Forms.Label();
			this.cboDates = new System.Windows.Forms.ComboBox();
			this.pnlSizeRange = new System.Windows.Forms.Panel();
			this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			this.cboSize = new System.Windows.Forms.ComboBox();
			this.btnSearch = new System.Windows.Forms.Button();
			this.cboTypeOfFile = new System.Windows.Forms.ComboBox();
			this.txtClient = new System.Windows.Forms.TextBox();
			this.pnlDateRange.SuspendLayout();
			this.pnlSizeRange.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
			this.SuspendLayout();
			// 
			// barSearch
			// 
			this.barSearch.AnimateStateChanges = true;
			this.barSearch.BackColorEnd = System.Drawing.Color.Empty;
			this.barSearch.BackColorStart = System.Drawing.Color.Empty;
			this.barSearch.Dock = System.Windows.Forms.DockStyle.Left;
			this.barSearch.DrawingStyle = vbAccelerator.Components.Controls.ExplorerBarDrawingStyle.System;
			this.barSearch.ImageList = null;
			this.barSearch.Mode = vbAccelerator.Components.Controls.ExplorerBarMode.Default;
			this.barSearch.Name = "barSearch";
			this.barSearch.Redraw = true;
			this.barSearch.ShowFocusRect = true;
			this.barSearch.Size = new System.Drawing.Size(240, 434);
			this.barSearch.TabIndex = 0;
			this.barSearch.TitleImageList = null;
			this.barSearch.ToolTip = null;
			// 
			// txtFileName
			// 
			this.txtFileName.Location = new System.Drawing.Point(476, 168);
			this.txtFileName.Name = "txtFileName";
			this.txtFileName.Size = new System.Drawing.Size(176, 21);
			this.txtFileName.TabIndex = 1;
			this.txtFileName.Text = "";
			// 
			// txtWord
			// 
			this.txtWord.Location = new System.Drawing.Point(476, 196);
			this.txtWord.Name = "txtWord";
			this.txtWord.Size = new System.Drawing.Size(176, 21);
			this.txtWord.TabIndex = 2;
			this.txtWord.Text = "";
			// 
			// cboLookIn
			// 
			this.cboLookIn.Location = new System.Drawing.Point(476, 224);
			this.cboLookIn.Name = "cboLookIn";
			this.cboLookIn.Size = new System.Drawing.Size(176, 21);
			this.cboLookIn.TabIndex = 3;
			this.cboLookIn.Text = "comboBox1";
			// 
			// pnlDateRange
			// 
			this.pnlDateRange.Controls.AddRange(new System.Windows.Forms.Control[] {
																					   this.dtpTo,
																					   this.lblTo,
																					   this.dtpFrom,
																					   this.lblFrom,
																					   this.cboDates});
			this.pnlDateRange.Location = new System.Drawing.Point(476, 252);
			this.pnlDateRange.Name = "pnlDateRange";
			this.pnlDateRange.Size = new System.Drawing.Size(180, 68);
			this.pnlDateRange.TabIndex = 4;
			// 
			// dtpTo
			// 
			this.dtpTo.Enabled = false;
			this.dtpTo.Location = new System.Drawing.Point(64, 48);
			this.dtpTo.Name = "dtpTo";
			this.dtpTo.Size = new System.Drawing.Size(116, 21);
			this.dtpTo.TabIndex = 14;
			// 
			// lblTo
			// 
			this.lblTo.Location = new System.Drawing.Point(28, 48);
			this.lblTo.Name = "lblTo";
			this.lblTo.Size = new System.Drawing.Size(36, 16);
			this.lblTo.TabIndex = 13;
			this.lblTo.Text = "to";
			// 
			// dtpFrom
			// 
			this.dtpFrom.Enabled = false;
			this.dtpFrom.Location = new System.Drawing.Point(64, 24);
			this.dtpFrom.Name = "dtpFrom";
			this.dtpFrom.Size = new System.Drawing.Size(116, 21);
			this.dtpFrom.TabIndex = 12;
			// 
			// lblFrom
			// 
			this.lblFrom.Location = new System.Drawing.Point(28, 28);
			this.lblFrom.Name = "lblFrom";
			this.lblFrom.Size = new System.Drawing.Size(36, 20);
			this.lblFrom.TabIndex = 11;
			this.lblFrom.Text = "from";
			// 
			// cboDates
			// 
			this.cboDates.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cboDates.Enabled = false;
			this.cboDates.Items.AddRange(new object[] {
														  "Modified Date",
														  "Created Date",
														  "Accessed Date"});
			this.cboDates.Location = new System.Drawing.Point(24, 0);
			this.cboDates.Name = "cboDates";
			this.cboDates.Size = new System.Drawing.Size(156, 21);
			this.cboDates.TabIndex = 10;
			// 
			// pnlSizeRange
			// 
			this.pnlSizeRange.Controls.AddRange(new System.Windows.Forms.Control[] {
																					   this.numericUpDown1,
																					   this.cboSize});
			this.pnlSizeRange.Location = new System.Drawing.Point(476, 328);
			this.pnlSizeRange.Name = "pnlSizeRange";
			this.pnlSizeRange.Size = new System.Drawing.Size(180, 20);
			this.pnlSizeRange.TabIndex = 15;
			// 
			// numericUpDown1
			// 
			this.numericUpDown1.Enabled = false;
			this.numericUpDown1.Location = new System.Drawing.Point(96, 0);
			this.numericUpDown1.Name = "numericUpDown1";
			this.numericUpDown1.Size = new System.Drawing.Size(84, 21);
			this.numericUpDown1.TabIndex = 22;
			// 
			// cboSize
			// 
			this.cboSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cboSize.Enabled = false;
			this.cboSize.Items.AddRange(new object[] {
														 "at least",
														 "at most"});
			this.cboSize.Location = new System.Drawing.Point(24, 0);
			this.cboSize.Name = "cboSize";
			this.cboSize.Size = new System.Drawing.Size(68, 21);
			this.cboSize.TabIndex = 21;
			// 
			// btnSearch
			// 
			this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnSearch.Location = new System.Drawing.Point(476, 384);
			this.btnSearch.Name = "btnSearch";
			this.btnSearch.Size = new System.Drawing.Size(80, 23);
			this.btnSearch.TabIndex = 29;
			this.btnSearch.Text = "Search";
			// 
			// cboTypeOfFile
			// 
			this.cboTypeOfFile.Location = new System.Drawing.Point(476, 356);
			this.cboTypeOfFile.Name = "cboTypeOfFile";
			this.cboTypeOfFile.Size = new System.Drawing.Size(176, 21);
			this.cboTypeOfFile.TabIndex = 30;
			// 
			// txtClient
			// 
			this.txtClient.Location = new System.Drawing.Point(252, 8);
			this.txtClient.Multiline = true;
			this.txtClient.Name = "txtClient";
			this.txtClient.Size = new System.Drawing.Size(208, 252);
			this.txtClient.TabIndex = 31;
			this.txtClient.Text = "textBox1";
			// 
			// frmSearch
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(676, 434);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.txtClient,
																		  this.cboTypeOfFile,
																		  this.btnSearch,
																		  this.pnlSizeRange,
																		  this.pnlDateRange,
																		  this.cboLookIn,
																		  this.txtWord,
																		  this.txtFileName,
																		  this.barSearch});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "frmSearch";
			this.Text = "frmSearch";
			this.pnlDateRange.ResumeLayout(false);
			this.pnlSizeRange.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion


		private void containerControl_SizeChanged(object sender, EventArgs e)
		{
			Panel panel = (Panel) sender;
			int width = panel.ClientRectangle.Width;
			foreach (Control ctl in panel.Controls)
			{
				ctl.Width = width - ctl.Left;
			}
		}

		private void barSearch_ItemClick(object sender, ExplorerBarItemClickEventArgs e)
		{
			if (e.Item.Tag != null)
			{
				if (typeof(RadioCheckHandler).IsAssignableFrom(e.Item.Tag.GetType()))
				{
					RadioCheckHandler handler = (RadioCheckHandler) e.Item.Tag;
					handler.HandleClick();
				}
			}
		}
	}

	/// <summary>
	/// Class to provide common handling for a radio check button that
	/// enables an associated child control.
	/// </summary>
	class RadioCheckHandler
	{
		private bool makeEnabled = false;
		private Control control = null;
		
		/// <summary>
		/// Construct a new instance of the class.
		/// </summary>
		/// <param name="control">Control to enable/disable</param>
		/// <param name="makeEnabled">Whether the control should be enabled or
		/// disabled when the click occurs</param>
		public RadioCheckHandler(Control control, bool makeEnabled)
		{
			this.control = control;
			this.makeEnabled = makeEnabled;
		}

		/// <summary>
		/// Handles a click event from a radio button that is associated
		/// with a control.
		/// </summary>
		public void HandleClick()
		{
			control.Enabled = makeEnabled;
			foreach (Control childControl in control.Controls)
			{
				childControl.Enabled = makeEnabled;
			}
		}
	}
}
