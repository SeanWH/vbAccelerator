using System;
using System.Collections;

namespace vbAccelerator.Components.Controls
{
	/// <summary>
	/// Contains the collection of items associated with a bar in 
	/// the ExplorerBar control.
	/// </summary>
	public class ExplorerBarItemCollection : ReadOnlyCollectionBase
	{
		/// <summary>
		/// Instance of the <see cref="acclExplorerBar"/> control
		/// which owns this collection.
		/// </summary>
		protected acclExplorerBar owner = null;

		/// <summary>
		/// Constructs a new instance of this collection.
		/// </summary>
		public ExplorerBarItemCollection()
		{
		}

		internal void SetOwner(acclExplorerBar owner)
		{
			this.owner = owner;

			// Make sure that all of the items that
			// belong to this collection are also
			// associated with their owner:
			foreach (ExplorerBarItem item in base.InnerList)
			{
				item.SetOwner(owner);
			}

		}

		/// <summary>
		/// Returns the next item in the bar, if any.
		/// </summary>
		/// <param name="item">Item to find next item for</param>
		/// <returns>Next item if found, otherwise <c>null</c>.</returns>
		public ExplorerBarItem Next(ExplorerBarItem item)
		{
			ExplorerBarItem next = null;
			bool found = false;
			for (int i = 0; i < InnerList.Count; i++)
			{
				ExplorerBarItem testItem = (ExplorerBarItem) InnerList[i];
				
				if (!found)
				{
					if (testItem == item)
					{
						found = true;
					}
				}
				else
				{
					next = testItem;
					break;
				}
			}
			return next;
		}

		/// <summary>
		/// Returns the previous item in the bar, if any.
		/// </summary>
		/// <param name="item">Item to find previous item for.</param>
		/// <returns>Previous item if found, otherwise <c>null</c>.</returns>
		public ExplorerBarItem Previous(ExplorerBarItem item)
		{
			ExplorerBarItem previous = null;
			bool found = false;
			for (int i = InnerList.Count - 1; i >=0; i--)
			{
				ExplorerBarItem testItem = (ExplorerBarItem) InnerList[i];
				
				if (!found)
				{
					if (testItem == item)
					{
						found = true;
					}
				}
				else
				{
					previous = testItem;
					break;
				}
			}
			return previous;
		}

		internal ExplorerBarItem FindFirstFocusableItem()
		{
			ExplorerBarItem firstFocusItem = null;
			for (int i = 0; i < InnerList.Count; i++)
			{
				ExplorerBarItem item = (ExplorerBarItem) InnerList[i];
				if (item.ShowFocus)
				{
					firstFocusItem = item;
					break;
				}
			}
			return firstFocusItem;
		}

		internal ExplorerBarItem NextFocusableItem(ExplorerBarItem item)
		{
			ExplorerBarItem next = null;
			bool found = false;
			for (int i = 0; i < InnerList.Count; i++)
			{
				ExplorerBarItem testItem = (ExplorerBarItem) InnerList[i];
				
				if (!found)
				{
					if (testItem == item)
					{
						found = true;
					}
				}
				else
				{
					if (testItem.ShowFocus)
					{
						next = testItem;
						break;
					}
				}
			}
			return next;
		}


		internal ExplorerBarItem PreviousFocusableItem(ExplorerBarItem item)
		{
			ExplorerBarItem first = null;
			bool found = false;
			for (int i = InnerList.Count - 1; i >=0; i--)
			{
				ExplorerBarItem testItem = (ExplorerBarItem) InnerList[i];
				
				if (!found)
				{
					if (testItem == item)
					{
						found = true;
					}
				}
				else
				{
					if (testItem.ShowFocus)
					{
						first = testItem;
						break;
					}
				}
			}
			return first;
		}

		internal ExplorerBarItem FindLastFocusableItem()
		{
			ExplorerBarItem lastFocusItem = null;
			for (int i = InnerList.Count - 1; i >= 0; i--)
			{
				ExplorerBarItem item = (ExplorerBarItem) InnerList[i];
				if (item.ShowFocus)
				{
					lastFocusItem = item;
					break;
				}
			}
			return lastFocusItem;
		}

		/// <summary>
		/// Gets the bar at the specified 0-based index.
		/// </summary>
		public ExplorerBarItem this[int index]
		{
			get
			{
				return (ExplorerBarItem) base.InnerList[index];
			}
		}

		/// <summary>
		/// Adds a new <see cref="ExplorerBarItem"/> to the control.
		/// </summary>
		/// <param name="item">Item to add.</param>
		public void Add(ExplorerBarItem item)
		{
			base.InnerList.Add(item);
			item.SetOwner(owner);
		}

		/// <summary>
		/// Inserts a new <see cref="ExplorerBarItem"/> before the specified
		/// existing item.
		/// </summary>
		/// <param name="itemBefore">Existing item before which the new item should
		/// be inserted.</param>
		/// <param name="itemNew">New item to insert.</param>
		public void InsertBefore(ExplorerBarItem itemBefore, ExplorerBarItem itemNew)
		{
			int beforeIndex = base.InnerList.IndexOf(itemBefore);
			if (beforeIndex > -1)
			{
				base.InnerList.Insert(beforeIndex, itemNew);
				itemNew.SetOwner(owner);
			}
			else
			{
				throw new ArgumentException("The before item could not be found in the collection.", "itemBefore");
			}
		}

		/// <summary>
		/// Inserts a new <see cref="ExplorerBarItem"/> after the specified
		/// existing item.
		/// </summary>
		/// <param name="itemAfter">Existing item after which the new item should
		/// be inserted.</param>
		/// <param name="itemNew">New item to insert.</param>
		public void InsertAfter(ExplorerBarItem itemAfter, ExplorerBarItem itemNew)
		{
			int afterIndex = base.InnerList.IndexOf(itemAfter);
			if (afterIndex > -1)
			{
				if (afterIndex == (base.InnerList.Count - 1))
				{
					Add(itemNew);
				}
				else
				{
					base.InnerList.Insert(afterIndex + 1, itemNew);
					itemNew.SetOwner(owner);
				}
			}
			else
			{
				throw new ArgumentException("The after item could not be found in the collection.", "itemBefore");
			}
		}

		/// <summary>
		/// Removes the item at the specified 0-based index.
		/// </summary>
		/// <param name="index">0-based index of the <see cref="ExplorerBarItem"/>
		/// to remove.</param>
		public void RemoveAt(int index)
		{
			ExplorerBarItem item = (ExplorerBarItem) base.InnerList[index];
			if (item != null)
			{
				base.InnerList.RemoveAt(index);
				item.SetOwner(null);
			}
			else
			{
				throw new IndexOutOfRangeException("The specified index does not exist.");
			}
		}

		/// <summary>
		/// Removes the specified <see cref="ExplorerBarItem"/>.
		/// </summary>
		/// <param name="item">The <see cref="ExplorerBarItem"/> to remove.</param>
		public void Remove(ExplorerBarItem item)
		{
			if (base.InnerList.Contains(item))
			{
				base.InnerList.Remove(item);
				item.SetOwner(null);
			}
			else
			{
				throw new ArgumentException("The item could not be found in the collection.", "item");
			}
		}

		/// <summary>
		/// Returns <c>true</c> if the collection contains the specified
		/// item, or <c>false</c> otherwise.
		/// </summary>
		/// <param name="item"><see cref="ExplorerBarItem"/> to check if 
		/// present in the collection.</param>
		/// <returns><c>true</c> if the collection contains the specified
		/// bar, or <c>false</c> otherwise.</returns>
		public bool Contains(ExplorerBarItem item)
		{
			return base.InnerList.Contains(item);
		}

		/// <summary>
		/// Sorts the items in the bar using the specified comparator.
		/// </summary>
		/// <param name="comparer">Object which can compare two items.</param>
		public void Sort(IComparer comparer)
		{
			base.InnerList.Sort(comparer);
		}	
	}
}
