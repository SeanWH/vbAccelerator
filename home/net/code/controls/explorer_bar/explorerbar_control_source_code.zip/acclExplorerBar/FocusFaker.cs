using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace vbAccelerator.Components.Controls.ExplorerBarUtility
{
	/// <summary>
	/// Summary description for FocusFaker.
	/// </summary>
	internal class FocusFaker : System.Windows.Forms.UserControl
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private acclExplorerBar owner = null;

		public FocusFaker(acclExplorerBar owner)
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
			this.owner = owner;
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
				owner = null;
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
		#endregion

		/// <summary>
		/// Determines whether the specified key should be
		/// processed by the control.
		/// </summary>
		/// <param name="keyData">Information about the key.</param>
		/// <returns><c>true</c> if the control processes the key,
		/// otherwise <c>false</c>.</returns>
		protected override bool IsInputKey(
			System.Windows.Forms.Keys keyData)
		{
			bool ret = false;
			int key = (int) keyData;
			key &= ~65552;
			Keys checkKeyData = (Keys) key;
			switch (checkKeyData)
			{
				case Keys.Up:
				case Keys.Down:
				case Keys.Right:
				case Keys.Left:
					ret = true;
					break;
				case Keys.Enter:
				case Keys.Tab:
					ret = owner.InternalIsInputKey(this, keyData);
					break;
				default:
					base.IsInputKey(keyData);
					break;
			}			
			return ret;
		}	

		protected override void OnGotFocus(EventArgs e)
		{
			Console.WriteLine("On GotFocus");
			owner.InternalGotFocus(this);
		}

		protected override void OnKeyDown(KeyEventArgs e)
		{
			base.OnKeyDown(e);

			switch (e.KeyCode)
			{
				case Keys.Up:
				case Keys.Down:
				case Keys.PageDown:
				case Keys.PageUp:
				case Keys.Home:
				case Keys.End:
					owner.InternalKeyDown(this, e);
					break;
			}
		}

	}
}
