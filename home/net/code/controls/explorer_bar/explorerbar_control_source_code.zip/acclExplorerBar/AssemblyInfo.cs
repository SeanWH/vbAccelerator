using System.Reflection;
using System.Runtime.CompilerServices;

//
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
//
[assembly: AssemblyTitle("vbAccelerator .NET Explorer Bar Control")]
[assembly: AssemblyDescription("vbAccelerator .NET Explorer Bar Control")]
[assembly: AssemblyConfiguration("Retail")]
[assembly: AssemblyCompany("vbAccelerator")]
[assembly: AssemblyProduct("vbAccelerator .NET Explorer Bar Control")]
[assembly: AssemblyCopyright("Copyright (C) 2004 Steve McMahon for vbAccelerator.com")]
[assembly: AssemblyTrademark("vbAccelerator and vbAccelerator.com are Trademarks of vbAccelerator Ltd.  All Rights Reserved.")]
[assembly: AssemblyCulture("")]		

//
// Default assembly version
//
[assembly: AssemblyVersion("1.0.0.0")]

//
// The control is shipped with a strong name signed by vbAccelerator.
// If you wish to create your own version of the control that has
// a strong name then you will need to revise the options below.
//
[assembly: AssemblyDelaySign(true)]
[assembly: AssemblyKeyFile("..\\..\\vbalPublic.snk")]
[assembly: AssemblyKeyName("")]
