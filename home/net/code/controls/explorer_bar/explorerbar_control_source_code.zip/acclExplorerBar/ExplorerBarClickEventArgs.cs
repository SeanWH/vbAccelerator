using System;
using System.Drawing;
using System.Windows.Forms;

namespace vbAccelerator.Components.Controls
{
	/// <summary>
	/// Event arguments for a click on a bar within the Explorer Bar control.
	/// </summary>
	public class ExplorerBarClickEventArgs : ExplorerBarClickBaseEventArgs
	{
		/// <summary>
		/// The bar which was clicked
		/// </summary>
		private ExplorerBar bar = null;

		/// <summary>
		/// Constructs a new instance of this class
		/// </summary>
		/// <param name="bar">Bar which was clicked</param>
		/// <param name="button">Mouse Button used to click the item</param>
		/// <param name="location">Location in the control that the click occurred</param>
		public ExplorerBarClickEventArgs(ExplorerBar bar, MouseButtons button, Point location) : base(button, location)
		{
			this.bar = bar;
		}

		/// <summary>
		/// Gets the bar that was clicked
		/// </summary>
		public ExplorerBar Bar
		{
			get
			{
				return bar;
			}
		}

	}
}
