using System;
using System.Drawing;
using System.Windows.Forms;

namespace vbAccelerator.Components.Controls
{
	/// <summary>
	/// Event arguments for a click on an Item within the ExplorerBar control.
	/// </summary>
	public class ExplorerBarItemClickEventArgs : ExplorerBarClickBaseEventArgs
	{
		/// <summary>
		/// The Item that was clicked
		/// </summary>
		private ExplorerBarItem item = null;

		/// <summary>
		/// Constructs a new instance of the class
		/// </summary>
		/// <param name="item">Item which was clicked</param>
		/// <param name="button">Button used to click the item</param>
		/// <param name="location">Location at which the click occurred.</param>
		public ExplorerBarItemClickEventArgs(ExplorerBarItem item, MouseButtons button, Point location) : base(button, location)
		{
			this.item = item;
		}

		/// <summary>
		/// Item in the explorer bar which was clicked.
		/// </summary>
		public ExplorerBarItem Item
		{
			get
			{
				return item;
			}
		}

	}
}
