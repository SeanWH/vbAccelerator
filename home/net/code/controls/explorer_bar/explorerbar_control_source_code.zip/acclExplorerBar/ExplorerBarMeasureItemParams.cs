using System;

namespace vbAccelerator.Components.Controls.ExplorerBarFramework
{
	/// <summary>
	/// Summary description for ExplorerBarMeasureItemParams.
	/// </summary>
	public class ExplorerBarMeasureItemParams
	{

		private System.Drawing.Graphics graphics;
		private System.Windows.Forms.ImageList titleImageList;
		private System.Windows.Forms.ImageList imageList;
		private System.Drawing.Font defaultFont;
		private int widthWithoutScroll;
		private int widthWithScroll;
		private ExplorerBarDrawingStyle style;
		private ExplorerBarMode mode;

		internal ExplorerBarMeasureItemParams(
			System.Drawing.Graphics graphics,
			System.Windows.Forms.ImageList titleImageList,			
			System.Windows.Forms.ImageList imageList,
			System.Drawing.Font defaultFont,
			int widthWithoutScroll,
			int widthWithScroll,
			ExplorerBarDrawingStyle style,
			ExplorerBarMode mode
			)
		{
			this.graphics = graphics;
			this.titleImageList = titleImageList;
			this.imageList = imageList;
			this.defaultFont = defaultFont;
			this.widthWithoutScroll = widthWithoutScroll;
			this.widthWithScroll = widthWithScroll;
			this.style = style;
			this.mode = mode;
		}

		/// <summary>
		/// Gets the graphics object to use for measurement of the item
		/// </summary>
		public System.Drawing.Graphics Graphics
		{
			get
			{
				return graphics;
			}
		}

		/// <summary>
		/// Gets the ImageList for icons in the titles of bars.
		/// </summary>
		public System.Windows.Forms.ImageList TitleImageList
		{
			get
			{
				return titleImageList;
			}
		}

		/// <summary>
		/// Gets the ImageList for item icons.
		/// </summary>
		public System.Windows.Forms.ImageList ImageList
		{
			get
			{
				return imageList;
			}
		}

		/// <summary>
		/// Gets the Default Font to use.
		/// </summary>
		public System.Drawing.Font DefaultFont
		{
			get
			{
				return defaultFont;
			}
		}

		/// <summary>
		/// Gets the client width of the control when the scroll bar
		/// is not showing.
		/// </summary>
		public int WidthWithoutScroll
		{
			get
			{
				return widthWithoutScroll;
			}
		}

		/// <summary>
		/// Gets the client width of the control when the scroll bar
		/// is showing.
		/// </summary>
		public int WidthWithScroll
		{
			get
			{
				return widthWithScroll;
			}
		}

		/// <summary>
		/// Gets the current drawing style of the control.
		/// </summary>
		public ExplorerBarDrawingStyle Style
		{
			get
			{
				return style;
			}
		}

		/// <summary>
		/// Gets the current drawing mode of the control.
		/// </summary>
		public ExplorerBarMode Mode
		{
			get
			{
				return mode;
			}
		}

	}
}
