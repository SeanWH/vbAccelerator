using System;
using System.Drawing;

namespace vbAccelerator.Components.Controls.ExplorerBarFramework
{
	/// <summary>
	/// Interface describing
	/// </summary>
	public interface IExplorerBarItemWithIcon
	{

		/// <summary>
		/// Draws the icon for this item and returns its width.
		/// </summary>
		/// <param name="drawItemParams">Object containing details
		/// needed to draw the item</param>
		/// <param name="itemRectangle">Rectangle to render item within</param>
		/// <returns>Width of the drawn icon</returns>
		int DrawIcon(ExplorerBarDrawItemParams drawItemParams, Rectangle itemRectangle);

		/// <summary>
		/// Measures the icon for this item and returns its size.
		/// </summary>
		/// <param name="drawItemParams">Object containing detailsd
		/// needed to meausre the item</param>
		/// <returns>Size of the measured icon</returns>
		Size MeasureIcon(ExplorerBarMeasureItemParams drawItemParams);

	}
}
