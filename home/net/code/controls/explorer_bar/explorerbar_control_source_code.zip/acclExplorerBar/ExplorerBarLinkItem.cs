using System;
using System.Drawing;
using System.Windows.Forms;
using vbAccelerator.Components.Controls.ExplorerBarFramework;
using vbAccelerator.Components.Controls.ExplorerBarUtility;

namespace vbAccelerator.Components.Controls
{
	/// <summary>
	/// Summary description for ExplorerBarLinkItem.
	/// </summary>
	public class ExplorerBarLinkItem  : ExplorerBarItemWithText, IExplorerBarItemWithIcon
	{
		/// <summary>
		/// Constructs a new instance of this class
		/// </summary>
		public ExplorerBarLinkItem() : base()
		{
		}

		/// <summary>
		/// Returns a clone of this object.
		/// </summary>
		/// <returns>Cloned object.</returns>
		public override object Clone()
		{
			ExplorerBarLinkItem cloned = new ExplorerBarLinkItem();
			CloneFields(cloned);
			return cloned;
		}

		/// <summary>
		/// Gets whether the control can get input focus.
		/// </summary>
		public override bool ShowFocus
		{
			get
			{
				return true;
			}
		}

		/// <summary>
		/// Gets whether this item is clickable or not
		/// </summary>
		public override bool Clickable
		{
			get
			{
				return true;
			}
		}

		/// <summary>
		/// Draws the icon for this item
		/// </summary>
		/// <param name="drawItemParams">Object containing information needed to draw the
		/// icon</param>
		/// <param name="itemRectangle">Bounding rectangle for item to draw</param>
		/// <returns>Width of the icon.</returns>
		public int DrawIcon(
			ExplorerBarDrawItemParams drawItemParams,
			Rectangle itemRectangle
			)
		{
			int width = 0;
			if ((IconIndex > -1) && (drawItemParams.ImageList != null))
			{
				width = drawItemParams.ImageList.ImageSize.Width;
				if (drawItemParams.RightToLeft)
				{
					drawItemParams.ImageList.Draw(drawItemParams.Graphics,
						itemRectangle.Right - drawItemParams.ImageList.ImageSize.Width, 
						itemRectangle.Top, IconIndex);
				}
				else
				{
					drawItemParams.ImageList.Draw(drawItemParams.Graphics,
						itemRectangle.Left, itemRectangle.Top, IconIndex);
				}				
			}
			return width;
		}


		/// <summary>
		/// Measures the size of the icon for this item.
		/// </summary>
		/// <param name="measureItemParams">Object containing information needed to measure
		/// an item</param>
		/// <returns>Size of the icon</returns>
		public Size MeasureIcon(			
			ExplorerBarMeasureItemParams measureItemParams
			)
		{
			Size iconSize = new Size(0, 0);
			if ((measureItemParams.ImageList != null) && (IconIndex > -1))
			{
				iconSize.Width = measureItemParams.ImageList.ImageSize.Width;
				iconSize.Height = measureItemParams.ImageList.ImageSize.Height;
			}
			return iconSize;
		}


		/// <summary>
		/// Draws this item
		/// </summary>
		/// <param name="drawItemParams">Object specifying details needed to draw 
		/// item</param>
		protected override void DrawItem(
			ExplorerBarDrawItemParams drawItemParams
			)
		{
			base.DrawItem(this, drawItemParams);
		}

		/// <summary>
		/// Measures this item
		/// </summary>
		/// <param name="measureItemParams">Object specifying details needed to measure
		/// item</param>
		protected override void MeasureItem(
			ExplorerBarMeasureItemParams measureItemParams
			)
		{
			base.MeasureItem(this, measureItemParams);
		}

	}
}
