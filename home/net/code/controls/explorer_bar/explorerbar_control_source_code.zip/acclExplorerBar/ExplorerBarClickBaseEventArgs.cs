using System;
using System.Drawing;
using System.Windows.Forms;

namespace vbAccelerator.Components.Controls
{
	/// <summary>
	/// Base class for ExplorerBar Click events.  This class is used
	/// when the user clicks on the ExplorerBar control itself, and
	/// extended for Bar and Item clicks.
	/// </summary>
	public class ExplorerBarClickBaseEventArgs
	{
		private MouseButtons button = MouseButtons.None;
		private Point location;

		/// <summary>
		/// Constructs a new instance of this class
		/// </summary>
		/// <param name="button">MouseButton that was clicked</param>
		/// <param name="location">Location at which the click occurred</param>
		public ExplorerBarClickBaseEventArgs(MouseButtons button, Point location)
		{
			this.button = button;
			this.location = location;
		}

		/// <summary>
		/// Gets the Button that was clicked
		/// </summary>
		public MouseButtons Button
		{
			get
			{
				return button;
			}
		}

		/// <summary>
		/// Gets the mouse location at which the click occurred.
		/// </summary>
		public Point Location
		{
			get
			{
				return location;
			}
		}

	}
}
