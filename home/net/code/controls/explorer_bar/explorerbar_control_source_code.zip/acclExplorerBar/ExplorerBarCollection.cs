using System;
using System.Collections;
using vbAccelerator.Components.Controls.ExplorerBarFramework;

namespace vbAccelerator.Components.Controls
{
	/// <summary>
	/// The collection of bars associated with an ExplorerBar control.
	/// </summary>
	public class ExplorerBarCollection : ReadOnlyCollectionBase
	{
		private acclExplorerBar owner = null;

		/// <summary>
		/// Constructs a new instance of this class. The Bars
		/// collection is created automatically by the owning
		/// <see cref="acclExplorerBar"/> control.
		/// </summary>
		/// <param name="owner">The <see cref="acclExplorerBar"/>
		/// which owns the collection of bars.</param>
		public ExplorerBarCollection(acclExplorerBar owner)
		{
			this.owner = owner;
		}

		/// <summary>
		/// Gets the <see cref="ExplorerBar"/> at the specified
		/// 0-based index.
		/// </summary>
		public ExplorerBar this[int index]
		{
			get
			{
				return (ExplorerBar) base.InnerList[index];
			}
		}

		/// <summary>
		/// Adds a new ExplorerBar to the control.
		/// </summary>
		/// <param name="bar">Bar to add.</param>
		public void Add(ExplorerBar bar)
		{
			base.InnerList.Add(bar);
			bar.SetOwner(owner);
		}

		/// <summary>
		/// Inserts a new <see cref="ExplorerBar"/> before the specified
		/// existing bar.
		/// </summary>
		/// <param name="barBefore">Existing bar before which the new bar should
		/// be inserted.</param>
		/// <param name="barNew">New bar to insert.</param>
		public void InsertBefore(ExplorerBar barBefore, ExplorerBar barNew)
		{
			int beforeIndex = base.InnerList.IndexOf(barBefore);
			if (beforeIndex > -1)
			{
				base.InnerList.Insert(beforeIndex, barNew);
				barNew.SetOwner(owner);
			}
			else
			{
				throw new ArgumentException("The before bar could not be found in the collection.", "barBefore");
			}
		}

		/// <summary>
		/// Inserts a new <see cref="ExplorerBar"/> after the specified
		/// existing bar.
		/// </summary>
		/// <param name="barAfter">Existing bar after which the new bar should
		/// be inserted.</param>
		/// <param name="barNew">New bar to insert.</param>
		public void InsertAfter(ExplorerBar barAfter, ExplorerBar barNew)
		{
			int afterIndex = base.InnerList.IndexOf(barAfter);
			if (afterIndex > -1)
			{
				if (afterIndex == (base.InnerList.Count - 1))
				{
					Add(barNew);
				}
				else
				{
					base.InnerList.Insert(afterIndex + 1, barNew);
					barNew.SetOwner(owner);
				}
			}
			else
			{
				throw new ArgumentException("The before bar could not be found in the collection.", "barBefore");
			}
		}

		/// <summary>
		/// Removes the bar at the specified 0-based index.
		/// </summary>
		/// <param name="index">0-based index of <see cref="ExplorerBar"/>
		/// to remove.</param>
		public void RemoveAt(int index)
		{
			ExplorerBar bar = (ExplorerBar) base.InnerList[index];
			if (bar != null)
			{
				base.InnerList.RemoveAt(index);
				bar.SetOwner(null);
			}
			else
			{
				throw new IndexOutOfRangeException("The specified index does not exist.");
			}
		}

		/// <summary>
		/// Removes the specified <see cref="ExplorerBar"/>.
		/// </summary>
		/// <param name="bar">The <see cref="ExplorerBar"/> to remove.</param>
		public void Remove(ExplorerBar bar)
		{
			if (base.InnerList.Contains(bar))
			{
				base.InnerList.Remove(bar);
				bar.SetOwner(null);
			}
			else
			{
				throw new ArgumentException("The bar could not be found in the collection.", "bar");
			}
		}

		/// <summary>
		/// Returns <c>true</c> if the collection contains the specified
		/// bar, or <c>false</c> otherwise.
		/// </summary>
		/// <param name="bar"><see cref="ExplorerBar"/> to check if 
		/// present in the collection.</param>
		/// <returns><c>true</c> if the collection contains the specified
		/// bar, or <c>false</c> otherwise.</returns>
		public bool Contains(ExplorerBar bar)
		{
			return base.InnerList.Contains(bar);
		}

		/// <summary>
		/// Gets the bar that owns the specified item, if any 
		/// </summary>
		/// <param name="item">Item to find bar for</param>
		/// <returns>Bar containing the item, if item is associated with a bar, otherwise 
		/// <c>null</c></returns>
		public ExplorerBar BarForItem(ExplorerBarItem item)
		{
			ExplorerBar returnBar = null;
			foreach (ExplorerBar bar in InnerList)
			{
				if (bar.Items.Contains(item))
				{
					returnBar = bar;
					break;
				}
			}
			return returnBar;
		}

		/// <summary>
		/// Gets the next Bar in the collection from the specified bar.
		/// </summary>
		/// <param name="bar">Bar to find next bar for.</param>
		/// <returns>Next bar if found, otherwise <c>null</c>.</returns>
		public ExplorerBar Next(ExplorerBar bar)
		{
			ExplorerBar nextBar = null;
			for (int i = 0; i < InnerList.Count; i++)
			{
				ExplorerBar testBar = (ExplorerBar) InnerList[i];
				if (testBar == bar)
				{
					if (i < InnerList.Count - 1)
					{
						nextBar = (ExplorerBar) InnerList[i + 1];
					}
					break;
				}
			}
			return nextBar;
		}

		/// <summary>
		/// Gets the previous Bar in the collection from the specified bar.
		/// </summary>
		/// <param name="bar">Bar to find previous bar for.</param>
		/// <returns>Previous bar if found, otherwise <c>null</c>.</returns>
		public ExplorerBar Previous(ExplorerBar bar)
		{
			ExplorerBar prevBar = null;
			for (int i = 0; i < InnerList.Count; i++)
			{
				ExplorerBar testBar = (ExplorerBar) InnerList[i];
				if (testBar == bar)
				{
					if (i > 0)
					{
						prevBar = (ExplorerBar) InnerList[i - 1];
					}
					break;
				}
			}
			return prevBar;
		}

		/// <summary>
		/// Sorts the bars in this collection using the specified comparer.
		/// </summary>
		/// <param name="comparer">Object which can compare two ExplorerBars with
		/// each other.</param>
		public void Sort(IComparer comparer)
		{
			base.InnerList.Sort(comparer);
		}
	}
}
