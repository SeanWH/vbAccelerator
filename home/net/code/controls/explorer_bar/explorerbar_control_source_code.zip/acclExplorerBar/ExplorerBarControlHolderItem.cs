using System;	
using vbAccelerator.Components.Controls.ExplorerBarFramework;

namespace vbAccelerator.Components.Controls
{
	/// <summary>
	/// Implements an ExplorerBarItem which can hold a control.
	/// </summary>
	public class ExplorerBarControlHolderItem : ExplorerBarItem
	{
		private System.Windows.Forms.Control control = null;

		/// <summary>
		/// Construct a new instance of this class
		/// </summary>
		public ExplorerBarControlHolderItem() : base()
		{
		}

		/// <summary>
		/// Gets a clone of this object.  The control associated with
		/// this object is <strong>not</strong> associated with the new object.
		/// </summary>
		/// <returns>Clone</returns>
		public override object Clone()
		{
			ExplorerBarControlHolderItem cloned = new ExplorerBarControlHolderItem();
			base.CloneFields(cloned);
			return cloned;
		}

		/// <summary>
		/// Gets/sets whether this item is focused or not
		/// </summary>
		public override bool Focused
		{
			get
			{
				return base.Focused;
			}
			set
			{
				base.Focused = value;
				if (control != null)
				{
					try
					{	
						control.Focus();
					}
					catch (Exception)
					{
						// ignored
					}
				}
			}
		}

		/// <summary>
		/// Gets whether the control can get input focus.
		/// </summary>
		public override bool ShowFocus
		{
			get
			{
				bool canGetFocus = false;
				if (control != null)
				{
					if (control.Visible)
					{
						canGetFocus = true;
					}
				}
				return canGetFocus;
			}
		}


		/// <summary>
		/// Determines whether this object should respond to the specified mnemonic
		/// key
		/// </summary>
		/// <param name="charCode">Mnemonic key character code</param>
		/// <returns><c>true</c> if should respond to the key, <c>false</c>
		/// otherwise.</returns>
		public override bool ContainsMnemonic(char charCode)
		{
			return false;
		}

		/// <summary>
		/// Gets whether this item is clickable or not
		/// </summary>
		public override bool Clickable
		{
			get
			{
				return false;
			}
		}

		/// <summary>
		/// Gets/sets the control associated with this item.
		/// </summary>
		public System.Windows.Forms.Control Control
		{
			get
			{
				return control;
			}
			set
			{
				bool changed = false;
				if (control == null)
				{
					if (value != null)
					{
						changed = true;
					}
				}
				else
				{
					if (value == null)
					{
						changed = true;
					}
					else
					{
						if (control != value)
						{
							changed = true;
						}
					}
				}
				if (changed)
				{
					System.Windows.Forms.Control oldControl = control;
					control = value;
					OnControlChanged(oldControl, control);
				}
			}
		}

		/// <summary>
		/// Sets the owning ExplorerBar control for this item
		/// </summary>
		/// <param name="newOwner">Owning control.</param>
		public override void SetOwner(acclExplorerBar newOwner)
		{
			base.SetOwner(newOwner);
			if ((control != null) && (newOwner != null))
			{
				newOwner.OnItemControlChanged(this, null, control);
			}
		}


		/// <summary>
		/// Notifies the owner that the Control associated with this item has
		/// changed.
		/// </summary>
		/// <param name="oldControl">Control that used to be associated with this
		/// item, if any</param>
		/// <param name="newControl">New control to associate with this item, if any</param>
		protected virtual void OnControlChanged(System.Windows.Forms.Control oldControl, System.Windows.Forms.Control newControl)
		{
			if (Owner != null)
			{
				Owner.OnItemControlChanged(this, oldControl, newControl);
			}
		}

		/// <summary>
		/// Ensures that the control associated with this item, if any, is correctly positioned.
		/// </summary>
		/// <param name="drawItemParams">Class specifying details needed to draw this
		/// item</param>
		protected override void DrawItem(
			ExplorerBarDrawItemParams drawItemParams
			)
		{
			if (control != null)
			{
				control.Top = Top;
				control.Left = MarginSize * 2;
				control.Width = (drawItemParams.ScrollShowing ? 
					drawItemParams.WidthWithScroll : drawItemParams.WidthWithoutScroll) 
					- MarginSize * 4;
				control.Visible = true;
			}
		}


		/// <summary>
		/// Called by the owning control to measure this item.
		/// </summary>
		/// <param name="measureItemParams">Class specifying details required to 
		/// measure the item.</param>
		protected override void MeasureItem(
			ExplorerBarMeasureItemParams measureItemParams
			)
		{

			int calcHeightWithoutScroll = 0;
			int calcHeightWithScroll = 0;
			int calcWidthWithScroll = 0;
			int calcWidthWithoutScroll = 0;

			if (control != null)
			{
				calcHeightWithoutScroll = control.Height + 4;
				calcHeightWithScroll = control.Height + 4;
				calcWidthWithoutScroll = measureItemParams.WidthWithoutScroll - MarginSize * 4;
				calcWidthWithScroll = measureItemParams.WidthWithScroll - MarginSize * 4;						
			}

			HeightWithScroll = calcHeightWithScroll;
			HeightWithoutScroll = calcHeightWithoutScroll;
			WidthWithScroll = calcWidthWithScroll;
			WidthWithoutScroll = calcWidthWithoutScroll;

		}

	}
}
