using System;
using System.Drawing;
using System.Windows.Forms;
using vbAccelerator.Components.Controls.ExplorerBarFramework;
using vbAccelerator.Components.Controls.ExplorerBarUtility;

namespace vbAccelerator.Components.Controls
{
	/// <summary>
	/// Implements an <see cref="ExplorerBarItem"/> which operates as a CheckBox.
	/// The checkbox will be rendered in XP style if possible.
	/// </summary>
	public class ExplorerBarCheckButtonItem : ExplorerBarItemWithText, IExplorerBarItemWithIcon
	{
		private bool enabled = true;
		private bool isChecked = false;
		private XpThemeAPI xpTheme = null;
		private int checkIconSize = 13;

		/// <summary>
		/// Constructs a new instance of this class
		/// </summary>
		public ExplorerBarCheckButtonItem() : base()
		{
		}

		/// <summary>
		/// Determines whether this item responds to click events or not
		/// </summary>
		public override bool Clickable
		{
			get
			{
				return enabled;
			}
		}

		/// <summary>
		/// Called when this item is clicked.
		/// </summary>
		public override void Click()
		{
			base.Click();
			Checked = !isChecked;
		}

		/// <summary>
		/// Returns a clone of this object.
		/// </summary>
		/// <returns>Cloned object.</returns>
		public override object Clone()
		{
			ExplorerBarCheckButtonItem cloned = new ExplorerBarCheckButtonItem();
			cloned.CloneFields(cloned);
			cloned.Checked = isChecked;
			cloned.Enabled = enabled;
			return cloned;
		}

		/// <summary>
		/// Gets whether the focus should be shown for this item
		/// </summary>
		public override bool ShowFocus
		{
			get
			{
				return enabled;
			}
		}

		/// <summary>
		/// Gets/sets whether this item is enabled.
		/// </summary>
		public bool Enabled
		{
			get
			{
				return enabled;
			}
			set
			{
				enabled = value;
				OnAppearanceChanged();
			}
		}

		/// <summary>
		/// Gets/sets whether this item is checked.
		/// </summary>
		public bool Checked
		{
			get
			{
				return isChecked;
			}
			set
			{
				isChecked = value;
				OnAppearanceChanged();	
			}
		}

		/// <summary>
		/// Draw the checkbox item
		/// </summary>
		/// <param name="drawItemParams">Object containing information </param>
		/// <param name="itemRectangle"></param>
		/// <returns></returns>
		public int DrawIcon(
			ExplorerBarDrawItemParams drawItemParams,
			Rectangle itemRectangle
			)
		{	
			Rectangle iconRectangle;

			if (UseXpTheme())
			{
				XpThemeAPI.UxThemeCheckBoxStates checkState;
				if (Enabled)
				{
					if (MouseOver || MouseDown)
					{
						if (Checked)
						{
							if (MouseDown)
							{
								checkState = XpThemeAPI.UxThemeCheckBoxStates.CBS_CHECKEDPRESSED;
							}
							else
							{
								checkState = XpThemeAPI.UxThemeCheckBoxStates.CBS_CHECKEDHOT;
							}
						}
						else
						{
							if (MouseDown)
							{
								checkState = XpThemeAPI.UxThemeCheckBoxStates.CBS_UNCHECKEDPRESSED;
							}
							else
							{
								checkState = XpThemeAPI.UxThemeCheckBoxStates.CBS_UNCHECKEDHOT;
							}
						}
					}
					else
					{
						if (Checked)
						{
							checkState = XpThemeAPI.UxThemeCheckBoxStates.CBS_CHECKEDNORMAL;
						}
						else
						{
							checkState = XpThemeAPI.UxThemeCheckBoxStates.CBS_UNCHECKEDNORMAL;
						}
					}
				}
				else
				{
					if (Checked)
					{
						checkState = XpThemeAPI.UxThemeCheckBoxStates.CBS_CHECKEDDISABLED;
					}
					else
					{
						checkState = XpThemeAPI.UxThemeCheckBoxStates.CBS_UNCHECKEDDISABLED;
					}
				}
				Size size = xpTheme.GetThemePartSize(drawItemParams.Graphics, 
					(int) XpThemeAPI.UxThemeButtonParts.BP_CHECKBOX, 
					(int) checkState);
				if (drawItemParams.RightToLeft)
				{
					iconRectangle = new Rectangle(
						itemRectangle.Right - size.Width - 2, 
						itemRectangle.Top + (itemRectangle.Height - size.Height) / 2, 
						size.Width,
						size.Height);
				}
				else
				{
					iconRectangle = new Rectangle(
						itemRectangle.Left + 2,
						itemRectangle.Top + (itemRectangle.Height - size.Height) / 2, 
						size.Width,
						size.Height);						
				}
				xpTheme.DrawThemeBackground(drawItemParams.Graphics, iconRectangle, 
					(int) XpThemeAPI.UxThemeButtonParts.BP_CHECKBOX, 
					(int) checkState);
			}
			else
			{
				ButtonState state;
				if (Checked)
				{
					state = ButtonState.Checked;
				}
				else
				{
					state = ButtonState.Normal;
				}
				if (!Enabled)
				{
					state |= ButtonState.Inactive;
				}
				if (drawItemParams.RightToLeft)
				{
					iconRectangle = new Rectangle(
						itemRectangle.Right - checkIconSize - 2, 
						itemRectangle.Top + (itemRectangle.Height - checkIconSize) / 2, 
						checkIconSize, checkIconSize);
				}
				else
				{
					iconRectangle = new Rectangle(
						itemRectangle.Left + 2,
						itemRectangle.Top + (itemRectangle.Height - checkIconSize) / 2, 
						checkIconSize, checkIconSize);						
				}
				ControlPaint.DrawCheckBox(drawItemParams.Graphics, iconRectangle, state);
			}

			return iconRectangle.Width + 4;
		}

		/// <summary>
		/// Measure the check box icon
		/// </summary>
		/// <param name="measureItemParams">Object containing information needed to 
		/// measure the icon</param>
		/// <returns>Size of the check box icon</returns>
		public Size MeasureIcon(			
			ExplorerBarMeasureItemParams measureItemParams
			)
		{
			Size iconSize;
			if (UseXpTheme())
			{
				iconSize = xpTheme.GetThemePartSize(measureItemParams.Graphics, 
					(int) XpThemeAPI.UxThemeButtonParts.BP_CHECKBOX, 
					(int) XpThemeAPI.UxThemeCheckBoxStates.CBS_CHECKEDHOT);
			}
			else
			{
				iconSize = new Size(checkIconSize, checkIconSize);
			}
			return iconSize;
		}

		private bool UseXpTheme()
		{
			if (xpTheme == null)
			{
				if (Owner != null)
				{
					xpTheme = new XpThemeAPI(Owner.Handle, "BUTTON");
				}
				else
				{
					return false;
				}
			}
			return (!xpTheme.hTheme.Equals(IntPtr.Zero));			
		}


		/// <summary>
		/// Draws the item.
		/// </summary>
		/// <param name="drawItemParams">Object. specifying details needed to draw 
		/// item</param>
		protected override void DrawItem(
			ExplorerBarDrawItemParams drawItemParams
			)
		{
			base.DrawItem(this, drawItemParams);
		}

		/// <summary>
		/// Measures the item.
		/// </summary>
		/// <param name="drawItemParams">Object. specifying details needed to measure
		/// the item</param>
		protected override void MeasureItem(
			ExplorerBarMeasureItemParams drawItemParams
			)
		{
			base.MeasureItem(this, drawItemParams);
		}

	}
}
