using System;

namespace vbAccelerator.Components.Controls
{
	/// <summary>
	/// Summary description for ExplorerBarTextAndControlHolderItem.
	/// </summary>
	public class ExplorerBarTextAndControlHolderItem : ExplorerBarControlHolderItem
	{
		private String text = "";

		/// <summary>
		/// Constructs a new instance of this class
		/// </summary>
		public ExplorerBarTextAndControlHolderItem() : base()
		{
		}

		/// <summary>
		/// Returns a clone of this object.
		/// </summary>
		/// <returns>Cloned object.</returns>
		public override object Clone()
		{
			ExplorerBarTextAndControlHolderItem cloned = new ExplorerBarTextAndControlHolderItem();
			base.CloneFields(cloned);
			//cloned.Text = text;
			return cloned;
		}


	}
}
