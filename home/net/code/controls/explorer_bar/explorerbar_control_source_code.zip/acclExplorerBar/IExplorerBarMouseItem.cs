using System;
using System.Drawing;

namespace vbAccelerator.Components.Controls.ExplorerBarFramework
{
	/// <summary>
	/// Specifies the interface that all bars and items in the Explorer Bar control
	/// must support to interact with the mouse.
	/// </summary>
	public interface IExplorerBarMouseItem
	{

		/// <summary>
		/// Determines whether the specified location is a hit inside the item
		/// </summary>
		/// <param name="location">Location to test</param>
		/// <param name="width">Client width of the control</param>
		/// <param name="scrollShowing">Whether the scroll bar is showing in
		/// the control</param>
		/// <returns><c>true</c> if the location is within the item, <c>false</c>
		/// otherwise.</returns>
		bool HitTest(Point location, int width, bool scrollShowing);

		/// <summary>
		/// Gets whether the specified item is clickable in the control.
		/// </summary>
		bool Clickable
		{
			get;
		}

		/// <summary>
		/// Gets/sets whether the mouse is over this item.
		/// </summary>
		bool MouseOver
		{
			get;
			set;
		}

		/// <summary>
		/// Gets/sets whether the mouse is down on this item
		/// </summary>
		bool MouseDown
		{
			get;
			set;
		}

		/// <summary>
		/// Gets/sets the tooltip text for the item
		/// </summary>
		string ToolTipText
		{
			get;
			set;
		}

		/// <summary>
		/// Called when the item is clicked.
		/// </summary>
		void Click();
		
	}
}
