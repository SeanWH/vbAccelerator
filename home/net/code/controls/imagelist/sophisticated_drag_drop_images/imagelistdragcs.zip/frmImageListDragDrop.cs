using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;

using vbAccelerator.Controls.Demo;
using vbAccelerator.Components.ImageList;
using vbAccelerator.Controls.TextBox;

namespace ImageListDragCS
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmImageListDragDrop : System.Windows.Forms.Form
	{
		private IconDragDropDemoControl iconDragDropDemoControl1;
		private DragDropTextBox txtTest;
		private System.Windows.Forms.ImageList iconImageList;
		private System.Windows.Forms.ImageList customDragImageList;
		private System.ComponentModel.IContainer components;

		/// <summary>
		/// A demonstration form showing how to use the ImageList
		/// Dragging functionality with a System.Windows.Forms
		/// control (a TextBox) as well as a custom control.
		/// </summary>
		public frmImageListDragDrop()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// Set the ImageList for the demo control:
			this.iconDragDropDemoControl1.ImageList = this.iconImageList;

			// enable us to set whether dragging is allowed or not:			
			txtTest.DragOver += new DragEventHandler(txtTest_DragOver);
			// drag image:
			txtTest.DrawDragImage = true;
			txtTest.ImageList = this.customDragImageList;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmImageListDragDrop));
			this.iconDragDropDemoControl1 = new vbAccelerator.Controls.Demo.IconDragDropDemoControl();
			this.iconImageList = new System.Windows.Forms.ImageList(this.components);
			this.txtTest = new vbAccelerator.Controls.TextBox.DragDropTextBox();
			this.customDragImageList = new System.Windows.Forms.ImageList(this.components);
			this.SuspendLayout();
			// 
			// iconDragDropDemoControl1
			// 
			this.iconDragDropDemoControl1.AllowDrop = true;
			this.iconDragDropDemoControl1.Dock = System.Windows.Forms.DockStyle.Left;
			this.iconDragDropDemoControl1.ImageList = null;
			this.iconDragDropDemoControl1.ItemSize = new System.Drawing.Size(64, 50);
			this.iconDragDropDemoControl1.Name = "iconDragDropDemoControl1";
			this.iconDragDropDemoControl1.Size = new System.Drawing.Size(150, 266);
			this.iconDragDropDemoControl1.TabIndex = 0;
			this.iconDragDropDemoControl1.Load += new System.EventHandler(this.iconDragDropDemoControl1_Load);
			// 
			// iconImageList
			// 
			this.iconImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.iconImageList.ImageSize = new System.Drawing.Size(32, 32);
			this.iconImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("iconImageList.ImageStream")));
			this.iconImageList.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// txtTest
			// 
			this.txtTest.AllowDrop = true;
			this.txtTest.Dock = System.Windows.Forms.DockStyle.Fill;
			this.txtTest.DrawDragImage = false;
			this.txtTest.ImageList = null;
			this.txtTest.Location = new System.Drawing.Point(150, 0);
			this.txtTest.Multiline = true;
			this.txtTest.Name = "txtTest";
			this.txtTest.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txtTest.Size = new System.Drawing.Size(302, 266);
			this.txtTest.TabIndex = 1;
			this.txtTest.Text = @"The standard System.Windows.Forms drag-drop functionality provides a cursor to indicate that a drag-drop function is in progress. This article demonstrates how to add an image of the object being dragged to the drag-drop control, in the same way that Explorer does, using the ImageList APIs.";
			this.txtTest.TextChanged += new System.EventHandler(this.txtTest_TextChanged);
			// 
			// customDragImageList
			// 
			this.customDragImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.customDragImageList.ImageSize = new System.Drawing.Size(128, 32);
			this.customDragImageList.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// frmImageListDragDrop
			// 
			this.AllowDrop = true;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(452, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.txtTest,
																		  this.iconDragDropDemoControl1});
			this.Name = "frmImageListDragDrop";
			this.Text = "vbAccelerator Image List DragDrop Demonstration";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmImageListDragDrop());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			// Add some items into the drag-drop demo control:
			for (int i = 0; i < this.iconImageList.Images.Count; i++)
			{
				IconDragDropDemoControlItem item = new IconDragDropDemoControlItem(
					String.Format("Item{0}", i), i);
				this.iconDragDropDemoControl1.Items.Add(item);
			}
		}

		private void iconDragDropDemoControl1_Load(object sender, System.EventArgs e)
		{
			//
		}

		private void txtTest_DragOver(object sender, DragEventArgs e)
		{
			if (e.Data.GetDataPresent(typeof(IconDragDropDemoControlItem)))
			{
				e.Effect = DragDropEffects.All;
			}
			else
			{
				e.Effect = DragDropEffects.Move;
			}
		}

		private void txtTest_TextChanged(object sender, System.EventArgs e)
		{
			//
		}
	}
}
