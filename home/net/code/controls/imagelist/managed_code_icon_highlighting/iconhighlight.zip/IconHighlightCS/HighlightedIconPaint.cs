using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace vbAccelerator.Components.ImageList
{

	/// <summary>
	/// A class for performing managed code icon highlighting.
	/// Provides methods to blend an icon with the specified
	/// amount of a highlight colour, and/or to draw the icon
	/// lightened or darkened using gamma.
	/// </summary>
	public class HighlightedIconPaint
	{
	
		// <summary>Draws a highlighted icon with the default highlight colour
		// and blend amount.</summary>
		// <param name="graphics">Graphics object to draw onto.</param>
		// <param name="iconImageList">ImageList to source icon from.</param>
		// <param name="iconIndex">0-based index of icon within the ImageList</param>
		// <param name="destRect">Rectangle to draw the icon into.</param>
		public static void DrawHighlightedIcon( 
			Graphics graphics, 
			System.Windows.Forms.ImageList iconImageList, 
			int iconIndex, 
			Rectangle destRect
			)
		{
			HighlightedIconPaint.DrawHighlightedIcon(
				graphics, iconImageList, iconIndex, destRect, 
				Color.FromKnownColor(KnownColor.Highlight), 128, 1.0F);
		}

		// <summary>Draws a highlighted icon using gamma to lighten or darken
		// it.</summary>
		// <param name="graphics">Graphics object to draw onto.</param>
		// <param name="iconImageList">ImageList to source icon from.</param>
		// <param name="iconIndex">0-based index of icon within the ImageList</param>
		// <param name="destRect">Rectangle to draw the icon into.</param>
		// <param name="gamma">The amount of gamma to apply.  Valid values range
		// between 0.1 (very light) and 5.0 (very dark).</param>
		public static void DrawHighlightedIcon( 
			Graphics graphics, 
			System.Windows.Forms.ImageList iconImageList, 
			int iconIndex, 
			Rectangle destRect, 
			float gamma 
			)
		{

			// Now set up the gamma:
			ImageAttributes imageAttr = new ImageAttributes();
			imageAttr.SetGamma(gamma);

			// Draw the image with the gamma applied:
			Image img = iconImageList.Images[iconIndex];
			graphics.DrawImage( 
				img, 
				destRect, 
				1, 1, iconImageList.ImageSize.Width, iconImageList.ImageSize.Height, 
				GraphicsUnit.Pixel, imageAttr);
			// Done.
			imageAttr.Dispose();
		}


		// <summary>Draws a highlighted icon with a customised highlight colour
		// and a default blend amount.</summary>
		// <param name="graphics">Graphics object to draw onto.</param>
		// <param name="iconImageList">ImageList to source icon from.</param>
		// <param name="iconIndex">0-based index of icon within the ImageList</param>
		// <param name="destRect">Rectangle to draw the icon into.</param>
		// <param name="highlightColor"><code>Color</code> to use for highlighting the 
		// icon.</param>
		public static void DrawHighlightedIcon( 
			Graphics graphics, 
			System.Windows.Forms.ImageList iconImageList, 
			int iconIndex, 
			Rectangle destRect, 
			Color highlightColor
			)
		{
			HighlightedIconPaint.DrawHighlightedIcon(
				graphics, iconImageList, iconIndex, destRect, 
				highlightColor, 128, 1.0F);
		}

		// <summary>Draws a highlighted icon with a customised highlight colour
		// and blend amount.</summary>
		// <param name="graphics">Graphics object to draw onto.</param>
		// <param name="iconImageList">ImageList to source icon from.</param>
		// <param name="iconIndex">0-based index of icon within the ImageList</param>
		// <param name="destRect">Rectangle to draw the icon into.</param>
		// <param name="highlightColor"><code>Color</code> to use for highlighting the 
		// icon.</param>
		// <param name="highlightAmount">Alpha amount to use when blending the highlight
		// colour with the icon.</param>
		public static void DrawHighlightedIcon( 
			Graphics graphics, 
			System.Windows.Forms.ImageList iconImageList, 
			int iconIndex, 
			Rectangle destRect, 
			Color highlightColor, 
			int highlightAmount
			)
		{
			DrawHighlightedIcon(
				graphics, iconImageList, iconIndex, destRect, 
				highlightColor, highlightAmount, 1.0F);
		}

		// <summary>Draws a highlighted icon with a customised highlight colour
		// and blend amount.</summary>
		// <param name="graphics">Graphics object to draw onto.</param>
		// <param name="iconImageList">ImageList to source icon from.</param>
		// <param name="iconIndex">0-based index of icon within the ImageList</param>
		// <param name="destRect">Rectangle to draw the icon into.</param>
		// <param name="highlightColor"><code>Color</code> to use for highlighting the 
		// icon.</param>
		// <param name="highlightAmount">Alpha amount to use when blending the highlight
		// colour with the icon.</param>
		// <param name="gamma">The amount of gamma to apply.  Valid values range
		// between 0.1 (very light) and 5.0 (very dark).  A value of 1.0 results
		// in no gamma being applied.</param>
		public static void DrawHighlightedIcon( 
			Graphics graphics, 
			System.Windows.Forms.ImageList iconImageList, 
			int iconIndex, 
			Rectangle destRect, 
			Color highlightColor , 
			int highlightAmount, 
			float gamma 
			)
		{
			// Create an offscreen bitmap for working on.  This is one bigger than
			// the icon so we know for sure that the top row of pixels will be
			// transparent
			Bitmap bm = new Bitmap( 
				iconImageList.ImageSize.Width, iconImageList.ImageSize.Height + 1 
				);
			Graphics gfx = Graphics.FromImage(bm);
		
			// Set the background colour to a colour that "won't" appear in the icon:
			Brush br = new SolidBrush(Color.FromArgb(254, 253, 254));
			gfx.FillRectangle(br, 0, 0, bm.Width, bm.Height);
			br.Dispose();
			// Draw the icon starting at the second row in the bitmap:
			iconImageList.Draw(gfx, 0, 1, iconIndex);
			// Overdraw with the highlight colour:
			br = new SolidBrush(Color.FromArgb(highlightAmount, highlightColor));
			gfx.FillRectangle(br, 0, 0, bm.Width, bm.Height);
			br.Dispose();
			gfx.Dispose();

			// Now set up a colour mapping from the colour of the pixel
			// at 0,0 to transparent:
			ImageAttributes imageAttr = new ImageAttributes();
			ColorMap[] map = new ColorMap[1] { new ColorMap() };
			map[0].OldColor = bm.GetPixel(0, 0);
			map[0].NewColor = Color.FromArgb(0, 0, 0, 0);
			imageAttr.SetRemapTable(map);
			if (gamma != 1.0F)
			{
				imageAttr.SetGamma(1.0F);
			}
			// Draw the image with the colour mapping, so that only the 
			// portion of the image with the new colour over the top 
			// gets mapped:
			graphics.DrawImage(
				bm, destRect, 
				1, 1, iconImageList.ImageSize.Width, iconImageList.ImageSize.Height, 
				GraphicsUnit.Pixel, imageAttr);
			// Done.
			imageAttr.Dispose();
			bm.Dispose();

		}

		// Private constructor, contains only static methods
		private HighlightedIconPaint()
		{
			// Intentionally blank
		}
	}
}
