using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using vbAccelerator.Components.ImageList;

namespace IconHighlightCS
{
	/// <summary>
	/// Summary description for frmTestIconHighlights.
	/// </summary>
	public class frmTestIconHighlights : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.Label lblInfo;
		private System.Windows.Forms.ImageList iconImageList;
		private System.ComponentModel.IContainer components;

		public frmTestIconHighlights()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTestIconHighlights));
			this.lblInfo = new System.Windows.Forms.Label();
			this.iconImageList = new System.Windows.Forms.ImageList(this.components);
			this.SuspendLayout();
			// 
			// lblInfo
			// 
			this.lblInfo.Location = new System.Drawing.Point(16, 8);
			this.lblInfo.Name = "lblInfo";
			this.lblInfo.Size = new System.Drawing.Size(456, 48);
			this.lblInfo.TabIndex = 1;
			this.lblInfo.Text = "The System.Windows.Forms ImageList does not provide any method to show the icon s" +
				"elected.  However, you can achieve this effect using either the ComCtl32 API or," +
				" as demonstrated here, using Managed Code.";
			// 
			// iconImageList
			// 
			this.iconImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.iconImageList.ImageSize = new System.Drawing.Size(32, 32);
			this.iconImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("iconImageList.ImageStream")));
			this.iconImageList.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// frmTestIconHighlights
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(524, 310);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lblInfo});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmTestIconHighlights";
			this.Text = "ImageList Icon Highlighting with Managed Code";
			this.Load += new System.EventHandler(this.frmTestIconHighlights_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmTestIconHighlights());
		}

		protected override void OnPaint(PaintEventArgs e)
		{
			int y = lblInfo.Top + lblInfo.Height + 8;

			Rectangle destRect = new Rectangle(
				32, y, 
				iconImageList.ImageSize.Width, iconImageList.ImageSize.Height);

			for (int i = 0; i < iconImageList.Images.Count; i++)
			{
				// Draw standard image:
				iconImageList.Draw(e.Graphics, destRect.X, destRect.Y, i);

				// Draw highlighted image 50%:
				destRect.Offset(iconImageList.ImageSize.Width + 16, 0);
				HighlightedIconPaint.DrawHighlightedIcon( 
					e.Graphics, iconImageList, i, destRect);

				// Draw highlighted image 25%:
				destRect.Offset(iconImageList.ImageSize.Width + 16, 0);
				HighlightedIconPaint.DrawHighlightedIcon( 
					e.Graphics, iconImageList, i, destRect, 
					Color.FromKnownColor(KnownColor.Highlight), 
					64);

				// Draw whitened image 50%:
				destRect.Offset(iconImageList.ImageSize.Width + 16, 0);
				HighlightedIconPaint.DrawHighlightedIcon( 
					e.Graphics, iconImageList, i, destRect, 
					Color.White);

				// Draw whitened image 75%
				destRect.Offset(iconImageList.ImageSize.Width + 16, 0);
				HighlightedIconPaint.DrawHighlightedIcon( 
					e.Graphics, iconImageList, i, destRect, 
					Color.White, 192);

				// With a high highlightamount the result is almost
				// colourised:
				destRect.Offset(iconImageList.ImageSize.Width + 16, 0);
				HighlightedIconPaint.DrawHighlightedIcon( 
					e.Graphics, iconImageList, i, destRect, 
					Color.FromKnownColor(KnownColor.ControlDarkDark), 225);

				// Using Gamma - lighter:
				destRect.Offset(iconImageList.ImageSize.Width + 16, 0);
					HighlightedIconPaint.DrawHighlightedIcon( 
						e.Graphics, iconImageList, i, destRect, 
						0.5F);
				
				// Using Gamma - darker:
				destRect.Offset(iconImageList.ImageSize.Width + 16, 0);
				HighlightedIconPaint.DrawHighlightedIcon( 
					e.Graphics, iconImageList, i, destRect, 
					2.2F);

				// Shadow fun: here we use a lightened version of 
				// a control dark saturated icon:
				destRect.Offset(iconImageList.ImageSize.Width + 18, 2);
            
				HighlightedIconPaint.DrawHighlightedIcon( 
					e.Graphics, iconImageList, i, destRect, 
					Color.FromKnownColor(KnownColor.ControlDark), 230, 0.8F);
				destRect.Offset(-2, -2);
				iconImageList.Draw(e.Graphics, destRect.X, destRect.Y, i);

				// prepare for next icon row
				destRect.Offset(0, iconImageList.ImageSize.Height + 4);
				destRect.X = 32;
			}

		}

		private void frmTestIconHighlights_Load(object sender, System.EventArgs e)
		{
		
		}
	}
}
