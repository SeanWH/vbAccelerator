Public Class HighlightedIconPaint

    ' Shared? not a good keyword choice. Surely "shared" implies 
    ' access/synchronisation, not that the method is static. 
    ' VB strikes again/I have no right/to take my place/in the human race...



    ' <summary>Draws a highlighted icon with the default highlight colour
    ' and blend amount.</summary>
    ' <param name="graphics">Graphics object to draw onto.</param>
    ' <param name="iconImageList">ImageList to source icon from.</param>
    ' <param name="iconIndex">0-based index of icon within the ImageList</param>
    ' <param name="destRect">Rectangle to draw the icon into.</param>
    Public Shared Sub DrawHighlightedIcon( _
        ByVal graphics As Graphics, _
        ByVal iconImageList As ImageList, _
        ByVal iconIndex As Integer, _
        ByVal destRect As Rectangle _
        )
        HighlightedIconPaint.DrawHighlightedIcon(graphics, iconImageList, iconIndex, destRect, _
            Color.FromKnownColor(KnownColor.Highlight), 128, 1.0)
    End Sub

    ' <summary>Draws a highlighted icon using gamma to lighten or darken
    ' it.</summary>
    ' <param name="graphics">Graphics object to draw onto.</param>
    ' <param name="iconImageList">ImageList to source icon from.</param>
    ' <param name="iconIndex">0-based index of icon within the ImageList</param>
    ' <param name="destRect">Rectangle to draw the icon into.</param>
    ' <param name="gamma">The amount of gamma to apply.  Valid values range
    ' between 0.1 (very light) and 5.0 (very dark).</param>
    Public Shared Sub DrawHighlightedIcon( _
        ByVal graphics As Graphics, _
        ByVal iconImageList As ImageList, _
        ByVal iconIndex As Integer, _
        ByVal destRect As Rectangle, _
        ByVal gamma As Single _
        )

        ' Now set up the gamma:
        Dim imageAttr As System.Drawing.Imaging.ImageAttributes = _
            New System.Drawing.Imaging.ImageAttributes()
        imageAttr.SetGamma(gamma)

        ' Draw the image with the gamma applied:
        Dim img As Image = iconImageList.Images(iconIndex)
        graphics.DrawImage( _
            img, _
            destRect, _
            1, 1, iconImageList.ImageSize.Width, iconImageList.ImageSize.Height, _
            GraphicsUnit.Pixel, imageAttr)
        ' Done.
        imageAttr.Dispose()

    End Sub


    ' <summary>Draws a highlighted icon with a customised highlight colour
    ' and a default blend amount.</summary>
    ' <param name="graphics">Graphics object to draw onto.</param>
    ' <param name="iconImageList">ImageList to source icon from.</param>
    ' <param name="iconIndex">0-based index of icon within the ImageList</param>
    ' <param name="destRect">Rectangle to draw the icon into.</param>
    ' <param name="highlightColor"><code>Color</code> to use for highlighting the 
    ' icon.</param>
    Public Shared Sub DrawHighlightedIcon( _
        ByVal graphics As Graphics, _
        ByVal iconImageList As ImageList, _
        ByVal iconIndex As Integer, _
        ByVal destRect As Rectangle, _
        ByVal highlightColor As Color _
        )
        HighlightedIconPaint.DrawHighlightedIcon(graphics, iconImageList, iconIndex, destRect, _
            highlightColor, 128, 1.0)
    End Sub

    ' <summary>Draws a highlighted icon with a customised highlight colour
    ' and blend amount.</summary>
    ' <param name="graphics">Graphics object to draw onto.</param>
    ' <param name="iconImageList">ImageList to source icon from.</param>
    ' <param name="iconIndex">0-based index of icon within the ImageList</param>
    ' <param name="destRect">Rectangle to draw the icon into.</param>
    ' <param name="highlightColor"><code>Color</code> to use for highlighting the 
    ' icon.</param>
    ' <param name="highlightAmount">Alpha amount to use when blending the highlight
    ' colour with the icon.</param>
    Public Shared Sub DrawHighlightedIcon( _
        ByVal graphics As Graphics, _
        ByVal iconImageList As ImageList, _
        ByVal iconIndex As Integer, _
        ByVal destRect As Rectangle, _
        ByVal highlightColor As Color, _
        ByVal highlightAmount As Integer _
        )
        DrawHighlightedIcon(graphics, iconImageList, iconIndex, destRect, _
            highlightColor, highlightAmount, 1.0)
    End Sub

    ' <summary>Draws a highlighted icon with a customised highlight colour
    ' and blend amount.</summary>
    ' <param name="graphics">Graphics object to draw onto.</param>
    ' <param name="iconImageList">ImageList to source icon from.</param>
    ' <param name="iconIndex">0-based index of icon within the ImageList</param>
    ' <param name="destRect">Rectangle to draw the icon into.</param>
    ' <param name="highlightColor"><code>Color</code> to use for highlighting the 
    ' icon.</param>
    ' <param name="highlightAmount">Alpha amount to use when blending the highlight
    ' colour with the icon.</param>
    ' <param name="gamma">The amount of gamma to apply.  Valid values range
    ' between 0.1 (very light) and 5.0 (very dark).  A value of 1.0 results
    ' in no gamma being applied.</param>
    Public Shared Sub DrawHighlightedIcon( _
        ByVal graphics As Graphics, _
        ByVal iconImageList As ImageList, _
        ByVal iconIndex As Integer, _
        ByVal destRect As Rectangle, _
        ByVal highlightColor As Color, _
        ByVal highlightAmount As Integer, _
        ByVal gamma As Single _
        )

        ' Create an offscreen bitmap for working on.  This is one bigger than
        ' the icon so we know for sure that the top row of pixels will be
        ' transparent
        Dim bm As Bitmap = New Bitmap( _
            iconImageList.ImageSize.Width, iconImageList.ImageSize.Height + 1 _
            )
        Dim gfx As Graphics = graphics.FromImage(bm)
        ' Set the background colour to a colour that "won't" appear in the icon:
        Dim br As Brush = New SolidBrush(Color.FromArgb(254, 253, 254))
        gfx.FillRectangle(br, 0, 0, bm.Width, bm.Height)
        br.Dispose()
        ' Draw the icon starting at the second row in the bitmap:
        iconImageList.Draw(gfx, 0, 1, iconIndex)
        ' Overdraw with the highlight colour:
        br = New SolidBrush(Color.FromArgb(highlightAmount, highlightColor))
        gfx.FillRectangle(br, 0, 0, bm.Width, bm.Height)
        br.Dispose()
        gfx.Dispose()

        ' Now set up a colour mapping from the colour of the pixel
        ' at 0,0 to transparent:
        Dim imageAttr As System.Drawing.Imaging.ImageAttributes = _
            New System.Drawing.Imaging.ImageAttributes()
        Dim map(0) As System.Drawing.Imaging.ColorMap
        map(0) = New System.Drawing.Imaging.ColorMap()
        map(0).OldColor = bm.GetPixel(0, 0)
        map(0).NewColor = Color.FromArgb(0, 0, 0, 0)
        imageAttr.SetRemapTable(map)
        If (gamma <> 1.0) Then
            imageAttr.SetGamma(1.0)
        End If
        ' Draw the image with the colour mapping, so that only the 
        ' portion of the image with the new colour over the top 
        ' gets mapped:
        graphics.DrawImage(bm, destRect, 1, 1, iconImageList.ImageSize.Width, iconImageList.ImageSize.Height, GraphicsUnit.Pixel, imageAttr)
        ' Done.
        imageAttr.Dispose()
        bm.Dispose()

    End Sub

    ' Private constructor, contains only static methods
    Private Sub New()
        ' Intentionally blank
    End Sub

End Class
