Imports System.Reflection
Imports System.Runtime.InteropServices

' General assembly details.

<Assembly: AssemblyTitle("vbAccelerator Managed Code ImageList Highlighting Demonstration")> 
<Assembly: AssemblyDescription("Demonstrates a class which enables icons to be highlighted using Managed Code.")> 
<Assembly: AssemblyCompany("vbAccelerator")> 
<Assembly: AssemblyProduct("vbAccelerator Managed Code ImageList Highlighting Demonstration")> 
<Assembly: AssemblyCopyright("Copyright (C) 2003 Steve McMahon for vbAccelerator.")> 
<Assembly: AssemblyTrademark("vbAccelerator is a Trade Mark of vbAccelerator Ltd.  All rights reserved.")> 
<Assembly: CLSCompliant(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("1D323E1C-1F95-4417-B11C-DF4FB81EE20B")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.*")> 
