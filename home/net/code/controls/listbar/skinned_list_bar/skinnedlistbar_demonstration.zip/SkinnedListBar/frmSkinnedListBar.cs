using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using vbAccelerator.Components.ListBarControl;

namespace vbAccelerator.Components.ListBarControl.Demo
{
	/// <summary>
	/// Summary description for frmSkinnedListBar.
	/// </summary>
	public class frmSkinnedListBar : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ImageList ilsIconsSmall;
		private System.Windows.Forms.ImageList ilsIconsLarge;
		private System.Windows.Forms.ToolTip toolTips;
		private vbAccelerator.Components.ListBarControl.SkinnedListBar skinnedListBar1;
		private vbAccelerator.Components.ListBarControl.SkinnedListBar skinnedListBar2;
		private System.ComponentModel.IContainer components;

		/// <summary>
		/// Tests the a skinned ListBar implementation.
		/// </summary>
		public frmSkinnedListBar()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// Set up:
			this.SizeChanged += new EventHandler(frmSkinnedListBar_SizeChanged);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSkinnedListBar));
			this.ilsIconsSmall = new System.Windows.Forms.ImageList(this.components);
			this.ilsIconsLarge = new System.Windows.Forms.ImageList(this.components);
			this.toolTips = new System.Windows.Forms.ToolTip(this.components);
			this.skinnedListBar1 = new vbAccelerator.Components.ListBarControl.SkinnedListBar();
			this.skinnedListBar2 = new vbAccelerator.Components.ListBarControl.SkinnedListBar();
			this.SuspendLayout();
			// 
			// ilsIconsSmall
			// 
			this.ilsIconsSmall.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.ilsIconsSmall.ImageSize = new System.Drawing.Size(16, 16);
			this.ilsIconsSmall.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ilsIconsSmall.ImageStream")));
			this.ilsIconsSmall.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// ilsIconsLarge
			// 
			this.ilsIconsLarge.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.ilsIconsLarge.ImageSize = new System.Drawing.Size(32, 32);
			this.ilsIconsLarge.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ilsIconsLarge.ImageStream")));
			this.ilsIconsLarge.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// skinnedListBar1
			// 
			this.skinnedListBar1.AllowDrop = true;
			this.skinnedListBar1.DrawStyle = vbAccelerator.Components.ListBarControl.ListBarDrawStyle.ListBarDrawStyleOfficeXP;
			this.skinnedListBar1.LargeImageList = null;
			this.skinnedListBar1.Location = new System.Drawing.Point(8, 8);
			this.skinnedListBar1.Name = "skinnedListBar1";
			this.skinnedListBar1.Size = new System.Drawing.Size(156, 252);
			this.skinnedListBar1.SmallImageList = null;
			this.skinnedListBar1.TabIndex = 0;
			this.skinnedListBar1.ToolTip = null;
			// 
			// skinnedListBar2
			// 
			this.skinnedListBar2.AllowDrop = true;
			this.skinnedListBar2.DrawStyle = vbAccelerator.Components.ListBarControl.ListBarDrawStyle.ListBarDrawStyleOfficeXP;
			this.skinnedListBar2.LargeImageList = null;
			this.skinnedListBar2.Location = new System.Drawing.Point(172, 8);
			this.skinnedListBar2.Name = "skinnedListBar2";
			this.skinnedListBar2.Size = new System.Drawing.Size(224, 252);
			this.skinnedListBar2.SmallImageList = null;
			this.skinnedListBar2.TabIndex = 1;
			this.skinnedListBar2.ToolTip = null;
			// 
			// frmSkinnedListBar
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.BackColor = System.Drawing.Color.WhiteSmoke;
			this.BackgroundImage = ((System.Drawing.Bitmap)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = new System.Drawing.Size(404, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.skinnedListBar2,
																		  this.skinnedListBar1});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmSkinnedListBar";
			this.Text = "vbAccelerator Skinned List Bar Demonstration";
			this.Load += new System.EventHandler(this.frmSkinnedListBar_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmSkinnedListBar());
		}

		private void frmSkinnedListBar_Load(object sender, System.EventArgs e)
		{
			skinnedListBar2.BackColor = Color.FromArgb(128, Color.White);

			// Configure the ListBar:
			skinnedListBar1.BackColor = Color.FromArgb(128, Color.White);
			skinnedListBar1.LargeImageList = ilsIconsLarge;
			skinnedListBar1.SmallImageList = ilsIconsSmall;
			skinnedListBar1.ToolTip = toolTips;

			// Add some items to it:
			Random randGen = new Random();
			for (int i = 0; i < 4; i++)
			{
				int jMax = 2 + randGen.Next(10);
				SkinnedListBarItem[] subItems = new SkinnedListBarItem[jMax];
				for (int j = 0; j < jMax; j++)
				{
					subItems[j] = new SkinnedListBarItem(
						String.Format("Test Item {0} in Bar {1}", j + 1, i + 1), 
						j % 4, 
						String.Format("Tooltip text for test item {0}", j + 1));
				}
				skinnedListBar1.Groups.Add(
					new SkinnedListBarGroup(String.Format("Test {0}", i + 1), 
					subItems));
			}
		
		}

		private void frmSkinnedListBar_SizeChanged(object sender, EventArgs e)
		{
			skinnedListBar1.Height = this.ClientRectangle.Height - skinnedListBar1.Top * 2;
			skinnedListBar2.Height = skinnedListBar1.Height;
			skinnedListBar2.Width = this.ClientRectangle.Width - skinnedListBar2.Left - skinnedListBar1.Left;
		}

	}
}
