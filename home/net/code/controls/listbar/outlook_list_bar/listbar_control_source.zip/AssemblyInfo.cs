using System.Reflection;
using System.Runtime.CompilerServices;

//
// General Information about this assembly.
//
[assembly: AssemblyTitle("vbAccelerator .NET ListBar Control")]
[assembly: AssemblyDescription("A Managed .NET Framework ListBar control which can be used to create Outlook and Visual Studio.NET style ListBar controls.")]
[assembly: AssemblyConfiguration("Retail")]
[assembly: AssemblyCompany("vbAccelerator")]
[assembly: AssemblyProduct("vbAccelerator .NET ListBar Control")]
[assembly: AssemblyCopyright("Copyright &#169; Steve McMahon 2003 for vbAccelerator.")]
[assembly: AssemblyTrademark("vbAccelerator is a Trade Mark of vbAccelerator Limited.  All Rights Reserved.")]
[assembly: AssemblyCulture("")]		

//
// Default assembly version
//
[assembly: AssemblyVersion("1.0.1326.27884")]

//
// The control is shipped with a strong name signed by vbAccelerator.
// If you wish to create your own version of the control that has
// a strong name then you will need to revise the options below.
//
[assembly: AssemblyDelaySign(true)]
[assembly: AssemblyKeyFile("..\\..\\vbalPublic.snk")]
[assembly: AssemblyKeyName("")]
