using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace ButtonListBarTestCS
{
	/// <summary>
	/// A extension of the PictureBox control which provides a
	/// banner showing the icon and text for the currently 
	/// area you're working on.
	/// </summary>
	public class PageBanner : System.Windows.Forms.PictureBox
	{
		/// <summary>
		/// The ImageList to obtain the icon from.
		/// </summary>
		private System.Windows.Forms.ImageList m_imageList = null;
		/// <summary>
		/// The 0-based index of the icon within the ImageList.
		/// </summary>
		private int m_iconIndex;

		/// <summary>
		/// Gets/sets the 0-based index of the icon to display in the banner.
		/// </summary>
		public int IconIndex
		{
			get
			{
				return m_iconIndex;
			}
			set
			{
				m_iconIndex = value;
				this.Invalidate();
			}
		}

		/// <summary>
		/// Gets/sets the font used to render the text in the banner.
		/// </summary>
		[Browsable(true)]
		public override System.Drawing.Font Font 
		{
			get
			{
				return base.Font;
			}
			set
			{
				base.Font = value;
				this.Invalidate();
			}
		}

		/// <summary>
		/// Gets/sets the Text displayed in the banner.
		/// </summary>
		[Browsable(true)]
		public override String Text
		{
			get
			{
				return base.Text;
			}
			set
			{
				base.Text = value;
				this.Invalidate();
			}
		}

		/// <summary>
		/// The colour to use to draw the text.
		/// </summary>
		[Browsable(true)]
		public override System.Drawing.Color ForeColor
		{
			get
			{
				return base.ForeColor ;
			}
			set
			{
				base.ForeColor = value;
				this.Invalidate();
			}
		}

		/// <summary>
		/// Gets/sets the ImageList used to draw icons in the banner.
		/// </summary>
		public System.Windows.Forms.ImageList ImageList
		{
			get
			{
				return m_imageList;
			}
			set
			{
				m_imageList = value;
				this.Invalidate();
			}
		}

		/// <summary>
		/// Performs painting of the banner
		/// </summary>
		protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
		{
			base.OnPaint(e);

			int iconEnd = 4;
			// Draw the icon:
			if (m_imageList != null)
			{
				e.Graphics.DrawImage(
					m_imageList.Images[IconIndex], 
					4, (this.Height - m_imageList.ImageSize.Height) / 2
					);

				iconEnd += m_imageList.ImageSize.Width + 4;
			}

			// Draw the caption
			StringFormat fmt = new StringFormat(StringFormatFlags.LineLimit);
			fmt.LineAlignment = StringAlignment.Center;
			fmt.Trimming = StringTrimming.EllipsisCharacter;
			fmt.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.Hide;
			Brush br = new SolidBrush(this.ForeColor);
			SizeF layoutArea = new SizeF(this.Width - iconEnd, this.Height );
			SizeF sz = e.Graphics.MeasureString(
				this.Text, 
				this.Font,
				layoutArea,
				fmt);
			e.Graphics.DrawString(
				this.Text, 
				this.Font, 
				br,
				iconEnd, this.Top + 2 + (this.Height - sz.Height) / 2, 
				fmt);
			br.Dispose();
			fmt.Dispose();
		}

	}
}
