Public Class Form1
    Inherits System.Windows.Forms.Form

    Private m_toolTip As ToolTip

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        m_toolTip = New ToolTip()
        m_toolTip.SetToolTip(txtDemo, "This area of the form would hold the client controls")

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private WithEvents barMain As ButtonListBarTest.vbAccelerator.Controls.ListBar.ButtonListBar
    Private WithEvents ilsIcons32 As System.Windows.Forms.ImageList
    Private WithEvents ilsIcons16 As System.Windows.Forms.ImageList
    Friend WithEvents picBanner As ButtonListBarTest.PageBanner
    Friend WithEvents pnlMain As System.Windows.Forms.Panel
    Friend WithEvents txtDemo As System.Windows.Forms.TextBox
    Private WithEvents mnuContext As System.Windows.Forms.ContextMenu
    Friend WithEvents mnuClearAll As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuAddNew As System.Windows.Forms.MenuItem
    Friend WithEvents mnuInsertNew As System.Windows.Forms.MenuItem
    Friend WithEvents mnuRemove As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuEnableNotes As System.Windows.Forms.MenuItem
    Friend WithEvents mnuChangeFirstIcon As System.Windows.Forms.MenuItem
    Friend WithEvents mnuChangeFirstCaption As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuChangeWidth As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.barMain = New ButtonListBarTest.vbAccelerator.Controls.ListBar.ButtonListBar()
        Me.ilsIcons32 = New System.Windows.Forms.ImageList(Me.components)
        Me.ilsIcons16 = New System.Windows.Forms.ImageList(Me.components)
        Me.pnlMain = New System.Windows.Forms.Panel()
        Me.txtDemo = New System.Windows.Forms.TextBox()
        Me.picBanner = New ButtonListBarTest.PageBanner()
        Me.mnuContext = New System.Windows.Forms.ContextMenu()
        Me.mnuClearAll = New System.Windows.Forms.MenuItem()
        Me.MenuItem2 = New System.Windows.Forms.MenuItem()
        Me.mnuAddNew = New System.Windows.Forms.MenuItem()
        Me.mnuInsertNew = New System.Windows.Forms.MenuItem()
        Me.mnuRemove = New System.Windows.Forms.MenuItem()
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        Me.mnuEnableNotes = New System.Windows.Forms.MenuItem()
        Me.mnuChangeFirstIcon = New System.Windows.Forms.MenuItem()
        Me.mnuChangeFirstCaption = New System.Windows.Forms.MenuItem()
        Me.MenuItem3 = New System.Windows.Forms.MenuItem()
        Me.mnuChangeWidth = New System.Windows.Forms.MenuItem()
        Me.pnlMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'barMain
        '
        Me.barMain.AutoScroll = True
        Me.barMain.BackColor = System.Drawing.SystemColors.Control
        Me.barMain.ButtonWidth = 96
        Me.barMain.Dock = System.Windows.Forms.DockStyle.Left
        Me.barMain.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.barMain.ImageList = Nothing
        Me.barMain.Name = "barMain"
        Me.barMain.Size = New System.Drawing.Size(96, 254)
        Me.barMain.TabIndex = 0
        Me.barMain.ToolTip = Nothing
        '
        'ilsIcons32
        '
        Me.ilsIcons32.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ilsIcons32.ImageSize = New System.Drawing.Size(32, 32)
        Me.ilsIcons32.ImageStream = CType(resources.GetObject("ilsIcons32.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ilsIcons32.TransparentColor = System.Drawing.Color.Transparent
        '
        'ilsIcons16
        '
        Me.ilsIcons16.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ilsIcons16.ImageSize = New System.Drawing.Size(16, 16)
        Me.ilsIcons16.ImageStream = CType(resources.GetObject("ilsIcons16.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ilsIcons16.TransparentColor = System.Drawing.Color.Transparent
        '
        'pnlMain
        '
        Me.pnlMain.BackColor = System.Drawing.SystemColors.Window
        Me.pnlMain.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtDemo, Me.picBanner})
        Me.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlMain.Location = New System.Drawing.Point(96, 0)
        Me.pnlMain.Name = "pnlMain"
        Me.pnlMain.Size = New System.Drawing.Size(368, 254)
        Me.pnlMain.TabIndex = 1
        '
        'txtDemo
        '
        Me.txtDemo.Location = New System.Drawing.Point(8, 39)
        Me.txtDemo.Multiline = True
        Me.txtDemo.Name = "txtDemo"
        Me.txtDemo.Size = New System.Drawing.Size(208, 176)
        Me.txtDemo.TabIndex = 6
        Me.txtDemo.Text = ""
        '
        'picBanner
        '
        Me.picBanner.BackColor = System.Drawing.SystemColors.ControlDark
        Me.picBanner.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.picBanner.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.picBanner.IconIndex = 0
        Me.picBanner.ImageList = Me.ilsIcons16
        Me.picBanner.Location = New System.Drawing.Point(8, 7)
        Me.picBanner.Name = "picBanner"
        Me.picBanner.Size = New System.Drawing.Size(312, 24)
        Me.picBanner.TabIndex = 5
        Me.picBanner.TabStop = False
        Me.picBanner.Text = "Banner Header 22"
        '
        'mnuContext
        '
        Me.mnuContext.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuClearAll, Me.MenuItem2, Me.mnuAddNew, Me.mnuInsertNew, Me.mnuRemove, Me.MenuItem1, Me.mnuEnableNotes, Me.mnuChangeFirstIcon, Me.mnuChangeFirstCaption, Me.MenuItem3, Me.mnuChangeWidth})
        '
        'mnuClearAll
        '
        Me.mnuClearAll.Index = 0
        Me.mnuClearAll.Text = "&Clear All"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.Text = "-"
        '
        'mnuAddNew
        '
        Me.mnuAddNew.Index = 2
        Me.mnuAddNew.Text = "Add &New..."
        '
        'mnuInsertNew
        '
        Me.mnuInsertNew.Index = 3
        Me.mnuInsertNew.Text = "&Insert New..."
        '
        'mnuRemove
        '
        Me.mnuRemove.Index = 4
        Me.mnuRemove.Text = "&Remove..."
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 5
        Me.MenuItem1.Text = "-"
        '
        'mnuEnableNotes
        '
        Me.mnuEnableNotes.Index = 6
        Me.mnuEnableNotes.Text = "&Enable Pinboard Notes"
        '
        'mnuChangeFirstIcon
        '
        Me.mnuChangeFirstIcon.Index = 7
        Me.mnuChangeFirstIcon.Text = "Change &First Icon"
        '
        'mnuChangeFirstCaption
        '
        Me.mnuChangeFirstCaption.Index = 8
        Me.mnuChangeFirstCaption.Text = "Change First Ca&ption"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 9
        Me.MenuItem3.Text = "-"
        '
        'mnuChangeWidth
        '
        Me.mnuChangeWidth.Index = 10
        Me.mnuChangeWidth.Text = "Change &Width"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(464, 254)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.pnlMain, Me.barMain})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Test Button List Bar Control - VB.NET"
        Me.pnlMain.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        barMain.ImageList = ilsIcons32
        barMain.ToolTip = m_toolTip

        Dim item(5) As ButtonListBarTest.vbAccelerator.Controls.ListBar.ButtonListBarItem
        item(0) = New ButtonListBarTest.vbAccelerator.Controls.ListBar.ButtonListBarItem( _
            "Check Your Work &Calendar", 0)
        item(1) = New ButtonListBarTest.vbAccelerator.Controls.ListBar.ButtonListBarItem( _
            "Book &Timecards", 1, "Book and submit your weekly timecards, and track your time.")
        item(2) = New ButtonListBarTest.vbAccelerator.Controls.ListBar.ButtonListBarItem( _
            "Contact &Notes", 2, "View meeting and lead notes")
        item(3) = New ButtonListBarTest.vbAccelerator.Controls.ListBar.ButtonListBarItem( _
            "&Pinboard Notes", 3, "", False)
        item(4) = New ButtonListBarTest.vbAccelerator.Controls.ListBar.ButtonListBarItem( _
            "Confi&gure Options", 4, "Set up offline options and configure the program")

        barMain.Items.Add(item)

        barMain.Items(0).Selected = True

    End Sub

    Private Sub barMain_ItemClick(ByVal sender As Object, ByVal eventArgs As ButtonListBarTest.vbAccelerator.Controls.ListBar.ItemClickEventArgs) Handles barMain.ItemClick
        '
        If (eventArgs.Button And MouseButtons.Right) = MouseButtons.Right Then
            mnuContext.Show(barMain, New Point(eventArgs.X, eventArgs.Y))
        End If
        '
    End Sub

    Private Sub barMain_SelectionChanged(ByVal sender As Object, ByVal eventArgs As ButtonListBarTest.vbAccelerator.Controls.ListBar.SelectionChangedEventArgs) Handles barMain.SelectionChanged
        '
        picBanner.Text = eventArgs.Item.Text
        picBanner.IconIndex = eventArgs.Item.IconIndex
        '
    End Sub

    Private Sub pnlMain_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles pnlMain.Resize
        Try
            picBanner.Location = New Point(4, 4)
            picBanner.Width = pnlMain.Width - 8
            txtDemo.Location = New Point(4, 4 + picBanner.Height + 2)
            txtDemo.Size = New Size(picBanner.Width, pnlMain.Height - picBanner.Top - picBanner.Height - 6)
        Catch

        End Try

    End Sub

    Private Sub pnlMain_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles pnlMain.Paint

    End Sub

    Private Sub mnuAddNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAddNew.Click
        '
        Dim sI As String = InputBox("Enter the text of the item to add:")
        If (sI.Length > 0) Then
            Dim r As New System.Random()
            barMain.Items.Add(New vbAccelerator.Controls.ListBar.ButtonListBarItem( _
                sI, _
                r.NextDouble * ilsIcons32.Images.Count, _
                "New item added at run-time"))
        End If
        '
    End Sub

    Private Sub mnuClearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuClearAll.Click
        barMain.Items.Clear()
    End Sub

    Private Sub mnuEnableNotes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuEnableNotes.Click
        mnuEnableNotes.Checked = Not (mnuEnableNotes.Checked)
        barMain.Items(3).Enabled = mnuEnableNotes.Checked
    End Sub

    Private Sub mnuChangeFirstIcon_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuChangeFirstIcon.Click
        Dim r As New System.Random()        
        barMain.Items(0).IconIndex = r.NextDouble * ilsIcons32.Images.Count
    End Sub

    Private Sub mnuChangeFirstCaption_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuChangeFirstCaption.Click
        If (barMain.Items(0).Text.Equals("T&his is a changed caption")) Then
            barMain.Items(0).Text = "Anot&her change." & vbCrLf & "This is longer and includes a line break."
        Else
            barMain.Items(0).Text = "T&his is a changed caption"
        End If
    End Sub

    Private Sub mnuChangeWidth_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuChangeWidth.Click
        Select Case barMain.ButtonWidth
            Case 64
                barMain.ButtonWidth = 96
            Case 96
                barMain.ButtonWidth = 128
            Case 128
                barMain.ButtonWidth = 256
            Case 256
                barMain.ButtonWidth = 64            
        End Select
    End Sub

    Private Sub barMain_BarClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles barMain.BarClick
        If (e.Button And MouseButtons.Right) = MouseButtons.Right Then
            mnuContext.Show(barMain, New Point(e.X, e.Y))
        End If

    End Sub

    Private Sub mnuRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuRemove.Click
        Dim sI As String = InputBox("Enter 0-based index of item to remove:")
        If (sI.Length > 0) Then
            Dim index As Integer = -1
            Try
                index = Integer.Parse(sI)
                barMain.Items.RemoveAt(index)
            Catch ex As Exception
                MsgBox(String.Format("Error:" & vbCrLf & "{0}", ex.Message, MsgBoxStyle.Exclamation Or MsgBoxStyle.OKOnly))
            End Try
        End If
    End Sub

    Private Sub mnuInsertNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuInsertNew.Click
        Dim sI As String = InputBox("Enter the text of the item to add:")
        If (sI.Length > 0) Then
            Dim sI2 As String = InputBox("Enter 0-base index to insert before:")
            If (sI2.Length > 0) Then
                Try
                    Dim index As Integer = Integer.Parse(sI2)
                    Dim r As New System.Random()
                    barMain.Items.Insert(index, New vbAccelerator.Controls.ListBar.ButtonListBarItem( _
                        sI, _
                        r.NextDouble * ilsIcons32.Images.Count, _
                        "New item added at run-time"))
                Catch ex As Exception
                    MsgBox(String.Format("Error:" & vbCrLf & "{0}", ex.Message, MsgBoxStyle.Exclamation Or MsgBoxStyle.OKOnly))
                End Try
            End If
        End If

    End Sub
End Class
