using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using vbAccelerator.Controls.ListBar;

namespace ButtonListBarTestCS
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{

		private ToolTip m_toolTip = null;
		private System.Windows.Forms.ImageList ilsIcons32;
		private System.Windows.Forms.ImageList ilsIcons16;
		private System.Windows.Forms.ContextMenu mnuContext;
		internal System.Windows.Forms.MenuItem mnuClearAll;
		internal System.Windows.Forms.MenuItem MenuItem2;
		internal System.Windows.Forms.MenuItem mnuAddNew;
		internal System.Windows.Forms.MenuItem mnuInsertNew;
		internal System.Windows.Forms.MenuItem mnuRemove;
		internal System.Windows.Forms.MenuItem MenuItem1;
		internal System.Windows.Forms.MenuItem mnuEnableNotes;
		internal System.Windows.Forms.MenuItem mnuChangeFirstIcon;
		internal System.Windows.Forms.MenuItem mnuChangeFirstCaption;
		internal System.Windows.Forms.MenuItem MenuItem3;
		internal System.Windows.Forms.MenuItem mnuChangeWidth;
		private vbAccelerator.Controls.ListBar.ButtonListBar barMain;
		internal System.Windows.Forms.Panel pnlMain;
		private ButtonListBarTestCS.PageBanner picBanner;
		internal System.Windows.Forms.TextBox txtDemo;
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			pnlMain.Resize += new EventHandler(pnlMain_Resize);
			barMain.SelectionChanged += new SelectionChangedEventHandler(barMain_SelectionChanged);
			barMain.ItemClick += new ItemClickEventHandler(barMain_ItemClick);
			barMain.BarClick += new MouseEventHandler(barMain_BarClick);			
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.ilsIcons16 = new System.Windows.Forms.ImageList(this.components);
			this.ilsIcons32 = new System.Windows.Forms.ImageList(this.components);
			this.mnuContext = new System.Windows.Forms.ContextMenu();
			this.mnuClearAll = new System.Windows.Forms.MenuItem();
			this.MenuItem2 = new System.Windows.Forms.MenuItem();
			this.mnuAddNew = new System.Windows.Forms.MenuItem();
			this.mnuInsertNew = new System.Windows.Forms.MenuItem();
			this.mnuRemove = new System.Windows.Forms.MenuItem();
			this.MenuItem1 = new System.Windows.Forms.MenuItem();
			this.mnuEnableNotes = new System.Windows.Forms.MenuItem();
			this.mnuChangeFirstIcon = new System.Windows.Forms.MenuItem();
			this.mnuChangeFirstCaption = new System.Windows.Forms.MenuItem();
			this.MenuItem3 = new System.Windows.Forms.MenuItem();
			this.mnuChangeWidth = new System.Windows.Forms.MenuItem();
			this.barMain = new vbAccelerator.Controls.ListBar.ButtonListBar();
			this.pnlMain = new System.Windows.Forms.Panel();
			this.picBanner = new ButtonListBarTestCS.PageBanner();
			this.txtDemo = new System.Windows.Forms.TextBox();
			this.pnlMain.SuspendLayout();
			this.SuspendLayout();
			// 
			// ilsIcons16
			// 
			this.ilsIcons16.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.ilsIcons16.ImageSize = new System.Drawing.Size(16, 16);
			this.ilsIcons16.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ilsIcons16.ImageStream")));
			this.ilsIcons16.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// ilsIcons32
			// 
			this.ilsIcons32.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.ilsIcons32.ImageSize = new System.Drawing.Size(32, 32);
			this.ilsIcons32.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ilsIcons32.ImageStream")));
			this.ilsIcons32.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// mnuContext
			// 
			this.mnuContext.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.mnuClearAll,
																					   this.MenuItem2,
																					   this.mnuAddNew,
																					   this.mnuInsertNew,
																					   this.mnuRemove,
																					   this.MenuItem1,
																					   this.mnuEnableNotes,
																					   this.mnuChangeFirstIcon,
																					   this.mnuChangeFirstCaption,
																					   this.MenuItem3,
																					   this.mnuChangeWidth});
			// 
			// mnuClearAll
			// 
			this.mnuClearAll.Index = 0;
			this.mnuClearAll.Text = "&Clear All";
			// 
			// MenuItem2
			// 
			this.MenuItem2.Index = 1;
			this.MenuItem2.Text = "-";
			// 
			// mnuAddNew
			// 
			this.mnuAddNew.Index = 2;
			this.mnuAddNew.Text = "Add &New...";
			// 
			// mnuInsertNew
			// 
			this.mnuInsertNew.Index = 3;
			this.mnuInsertNew.Text = "&Insert New...";
			// 
			// mnuRemove
			// 
			this.mnuRemove.Index = 4;
			this.mnuRemove.Text = "&Remove...";
			// 
			// MenuItem1
			// 
			this.MenuItem1.Index = 5;
			this.MenuItem1.Text = "-";
			// 
			// mnuEnableNotes
			// 
			this.mnuEnableNotes.Index = 6;
			this.mnuEnableNotes.Text = "&Enable Pinboard Notes";
			// 
			// mnuChangeFirstIcon
			// 
			this.mnuChangeFirstIcon.Index = 7;
			this.mnuChangeFirstIcon.Text = "Change &First Icon";
			// 
			// mnuChangeFirstCaption
			// 
			this.mnuChangeFirstCaption.Index = 8;
			this.mnuChangeFirstCaption.Text = "Change First Ca&ption";
			// 
			// MenuItem3
			// 
			this.MenuItem3.Index = 9;
			this.MenuItem3.Text = "-";
			// 
			// mnuChangeWidth
			// 
			this.mnuChangeWidth.Index = 10;
			this.mnuChangeWidth.Text = "Change &Width";
			// 
			// barMain
			// 
			this.barMain.ButtonWidth = 96;
			this.barMain.Dock = System.Windows.Forms.DockStyle.Left;
			this.barMain.ImageList = null;
			this.barMain.Name = "barMain";
			this.barMain.Size = new System.Drawing.Size(96, 354);
			this.barMain.TabIndex = 3;
			this.barMain.ToolTip = null;
			// 
			// pnlMain
			// 
			this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
			this.pnlMain.Controls.AddRange(new System.Windows.Forms.Control[] {
																				  this.picBanner,
																				  this.txtDemo});
			this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnlMain.Location = new System.Drawing.Point(96, 0);
			this.pnlMain.Name = "pnlMain";
			this.pnlMain.Size = new System.Drawing.Size(336, 354);
			this.pnlMain.TabIndex = 4;
			// 
			// picBanner
			// 
			this.picBanner.BackColor = System.Drawing.SystemColors.ControlDark;
			this.picBanner.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.picBanner.ForeColor = System.Drawing.SystemColors.ControlLight;
			this.picBanner.IconIndex = 0;
			this.picBanner.ImageList = this.ilsIcons16;
			this.picBanner.Location = new System.Drawing.Point(36, 12);
			this.picBanner.Name = "picBanner";
			this.picBanner.Size = new System.Drawing.Size(292, 24);
			this.picBanner.TabIndex = 7;
			this.picBanner.TabStop = false;
			this.picBanner.Text = "Page Banner";
			// 
			// txtDemo
			// 
			this.txtDemo.Location = new System.Drawing.Point(40, 52);
			this.txtDemo.Multiline = true;
			this.txtDemo.Name = "txtDemo";
			this.txtDemo.Size = new System.Drawing.Size(292, 260);
			this.txtDemo.TabIndex = 6;
			this.txtDemo.Text = "";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(432, 354);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.pnlMain,
																		  this.barMain});
			this.Name = "Form1";
			this.Text = "Test Button List Bar Control - C#";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.pnlMain.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			m_toolTip = new ToolTip();

			barMain.ImageList = ilsIcons32;
			barMain.ToolTip = m_toolTip;

			ButtonListBarItem[] items = new ButtonListBarItem[5] 
				{
					new ButtonListBarItem(
					"Check Your Work &Calendar", 0),
					new ButtonListBarItem(
					"Book &Timecards", 1, "Book and submit your weekly timecards, and track your time."),
					new ButtonListBarItem( 
					"Contact &Notes", 2, "View meeting and lead notes"),
					new ButtonListBarItem( 
					"&Pinboard Notes", 3, "", false),
					new ButtonListBarItem( 
					"Confi&gure Options", 4, "Set up offline options and configure the program")
				};
			barMain.Items.Add(items );

			barMain.Items[0].Selected = true;

			pnlMain_Resize(barMain, null);
		}

		private void pnlMain_Resize(object sender, System.EventArgs e)
		{
			try
			{
				picBanner.Location = new Point(4, 4);
				picBanner.Width = pnlMain.Width - 8;
				txtDemo.Location = new Point(4, 4 + picBanner.Height + 2);
				txtDemo.Size = new Size(picBanner.Width, pnlMain.Height - picBanner.Top - picBanner.Height - 6);
			}
			catch {}

		}

		private void barMain_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			picBanner.Text = e.Item.Text;
			picBanner.IconIndex = e.Item.IconIndex;
		}

		private void barMain_ItemClick(object sender, ItemClickEventArgs e)
		{
			if (e.Button == MouseButtons.Right)
			{
				mnuContext.Show(barMain, new Point(e.X, e.Y));
			}
		}

		private void barMain_BarClick(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Right)
			{
				mnuContext.Show(barMain, new Point(e.X, e.Y));
			}
		}


	}
}
