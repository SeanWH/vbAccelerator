Public Class PageBanner
    Inherits System.Windows.Forms.PictureBox

    Private m_imageList As System.Windows.Forms.ImageList
    Private m_iconIndex As Integer

    <System.ComponentModel.Description("Gets/sets the 0-based index of the icon to display in the banner.")> _
    Public Property IconIndex() As Integer
        Get
            IconIndex = m_iconIndex
        End Get
        Set(ByVal Value As Integer)
            m_iconIndex = Value
            Invalidate()
        End Set
    End Property

    <System.ComponentModel.Browsable(True), _
    System.ComponentModel.Description("Gets/sets the font used to render the text in the banner.")> _
    Public Overrides Property Font() As System.Drawing.Font
        Get
            Font = MyBase.Font
        End Get
        Set(ByVal Value As System.Drawing.Font)
            MyBase.Font = Value
            Invalidate()
        End Set
    End Property

    <System.ComponentModel.Browsable(True), _
    System.ComponentModel.Description("Gets/sets the Text displayed in the banner.")> _
    Public Overrides Property Text() As String
        Get
            Text = MyBase.Text
        End Get
        Set(ByVal Value As String)
            MyBase.Text = Value
            Invalidate()
        End Set
    End Property

    <System.ComponentModel.Browsable(True), _
    System.ComponentModel.Description("Gets/sets the ForeColor for the banner.")> _
    Public Overrides Property ForeColor() As Color
        Get
            ForeColor = MyBase.ForeColor
        End Get
        Set(ByVal Value As Color)
            MyBase.ForeColor = Value
            Invalidate()
        End Set
    End Property

    <System.ComponentModel.Description("Gets/sets the ImageList used to draw icons in the banner.")> _
    Public Property ImageList() As System.Windows.Forms.ImageList
        Get
            ImageList = m_imageList
        End Get
        Set(ByVal Value As System.Windows.Forms.ImageList)
            m_imageList = Value
        End Set
    End Property

    <System.ComponentModel.Description("Performs painting of the banner.")> _
    Protected Overrides Sub OnPaint(ByVal pe As System.Windows.Forms.PaintEventArgs)
        MyBase.OnPaint(pe)

        Dim iconEnd As Integer = 4
        ' Draw the icon:
        If Not (m_imageList Is Nothing) Then
            pe.Graphics.DrawImage( _
                m_imageList.Images(IconIndex), _
                4, (Me.Height - m_imageList.ImageSize.Height) \ 2 _
                )
            iconEnd += m_imageList.ImageSize.Width + 4
        End If

        ' Draw the caption
        Dim fmt As StringFormat = New StringFormat(StringFormatFlags.LineLimit)
        fmt.LineAlignment = StringAlignment.Center
        fmt.Trimming = StringTrimming.EllipsisCharacter
        fmt.HotkeyPrefix = Drawing.Text.HotkeyPrefix.Hide
        Dim br As Brush = New SolidBrush(Me.ForeColor)
        Dim layoutArea As SizeF = New SizeF(Me.Width - iconEnd, Me.Height)
        Dim sz As SizeF = pe.Graphics.MeasureString( _
                Me.Text, _
                Me.Font, _
                layoutArea, _
                fmt)
        pe.Graphics.DrawString( _
                Me.Text, _
                Me.Font, _
                br, _
                iconEnd, Me.Top + 2 + (Me.Height - sz.Height) / 2, _
                fmt)
        br.Dispose()
        fmt.Dispose()

    End Sub
End Class
