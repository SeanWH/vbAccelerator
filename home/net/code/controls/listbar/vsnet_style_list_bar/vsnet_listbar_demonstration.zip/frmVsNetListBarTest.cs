using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace vbAccelerator.Components.ListBarControl
{
	/// <summary>
	/// Summary description for frmVsNetListBarTest.
	/// </summary>
	public class frmVsNetListBarTest : System.Windows.Forms.Form
	{
		private vbAccelerator.Components.ListBarControl.VSNetListBar vsNetListBar1;
		private System.Windows.Forms.Splitter spltVSNetBar;
		private System.Windows.Forms.Splitter splitProperties;
		private System.Windows.Forms.ImageList ilsIconsSmall;
		private System.Windows.Forms.ImageList ilsIconsLarge;
		private System.Windows.Forms.Panel pnlProperties;
		private System.Windows.Forms.ComboBox cboGroups;
		private System.Windows.Forms.PropertyGrid groupPropertyGrid;
		private System.Windows.Forms.TreeView tvwCustom;
		private System.Windows.Forms.ToolTip toolTips;
		private System.ComponentModel.IContainer components;

		/// <summary>
		/// A form for testing the vbAccelerator VS.NET List Bar control.
		/// </summary>
		public frmVsNetListBarTest()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmVsNetListBarTest));
			this.vsNetListBar1 = new vbAccelerator.Components.ListBarControl.VSNetListBar();
			this.spltVSNetBar = new System.Windows.Forms.Splitter();
			this.splitProperties = new System.Windows.Forms.Splitter();
			this.ilsIconsSmall = new System.Windows.Forms.ImageList(this.components);
			this.ilsIconsLarge = new System.Windows.Forms.ImageList(this.components);
			this.pnlProperties = new System.Windows.Forms.Panel();
			this.cboGroups = new System.Windows.Forms.ComboBox();
			this.groupPropertyGrid = new System.Windows.Forms.PropertyGrid();
			this.tvwCustom = new System.Windows.Forms.TreeView();
			this.toolTips = new System.Windows.Forms.ToolTip(this.components);
			this.pnlProperties.SuspendLayout();
			this.SuspendLayout();
			// 
			// vsNetListBar1
			// 
			this.vsNetListBar1.AllowDragGroups = true;
			this.vsNetListBar1.AllowDragItems = true;
			this.vsNetListBar1.AllowDrop = true;
			this.vsNetListBar1.Dock = System.Windows.Forms.DockStyle.Left;
			this.vsNetListBar1.DrawStyle = vbAccelerator.Components.ListBarControl.ListBarDrawStyle.ListBarDrawStyleOfficeXP;
			this.vsNetListBar1.LargeImageList = null;
			this.vsNetListBar1.Name = "vsNetListBar1";
			this.vsNetListBar1.SelectOnMouseDown = true;
			this.vsNetListBar1.Size = new System.Drawing.Size(164, 398);
			this.vsNetListBar1.SmallImageList = null;
			this.vsNetListBar1.TabIndex = 0;
			this.vsNetListBar1.ToolTip = null;
			// 
			// spltVSNetBar
			// 
			this.spltVSNetBar.Location = new System.Drawing.Point(164, 0);
			this.spltVSNetBar.Name = "spltVSNetBar";
			this.spltVSNetBar.Size = new System.Drawing.Size(3, 398);
			this.spltVSNetBar.TabIndex = 1;
			this.spltVSNetBar.TabStop = false;
			// 
			// splitProperties
			// 
			this.splitProperties.Dock = System.Windows.Forms.DockStyle.Right;
			this.splitProperties.Location = new System.Drawing.Point(261, 0);
			this.splitProperties.MinExtra = 4;
			this.splitProperties.Name = "splitProperties";
			this.splitProperties.Size = new System.Drawing.Size(3, 398);
			this.splitProperties.TabIndex = 8;
			this.splitProperties.TabStop = false;
			// 
			// ilsIconsSmall
			// 
			this.ilsIconsSmall.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.ilsIconsSmall.ImageSize = new System.Drawing.Size(16, 16);
			this.ilsIconsSmall.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ilsIconsSmall.ImageStream")));
			this.ilsIconsSmall.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// ilsIconsLarge
			// 
			this.ilsIconsLarge.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.ilsIconsLarge.ImageSize = new System.Drawing.Size(32, 32);
			this.ilsIconsLarge.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ilsIconsLarge.ImageStream")));
			this.ilsIconsLarge.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// pnlProperties
			// 
			this.pnlProperties.Controls.AddRange(new System.Windows.Forms.Control[] {
																						this.cboGroups,
																						this.groupPropertyGrid});
			this.pnlProperties.Dock = System.Windows.Forms.DockStyle.Right;
			this.pnlProperties.Location = new System.Drawing.Point(264, 0);
			this.pnlProperties.Name = "pnlProperties";
			this.pnlProperties.Size = new System.Drawing.Size(208, 398);
			this.pnlProperties.TabIndex = 7;
			// 
			// cboGroups
			// 
			this.cboGroups.Location = new System.Drawing.Point(4, 4);
			this.cboGroups.Name = "cboGroups";
			this.cboGroups.Size = new System.Drawing.Size(200, 21);
			this.cboGroups.TabIndex = 4;
			this.cboGroups.Text = "comboBox1";
			// 
			// groupPropertyGrid
			// 
			this.groupPropertyGrid.CommandsVisibleIfAvailable = true;
			this.groupPropertyGrid.LargeButtons = false;
			this.groupPropertyGrid.LineColor = System.Drawing.SystemColors.ScrollBar;
			this.groupPropertyGrid.Location = new System.Drawing.Point(4, 28);
			this.groupPropertyGrid.Name = "groupPropertyGrid";
			this.groupPropertyGrid.Size = new System.Drawing.Size(200, 364);
			this.groupPropertyGrid.TabIndex = 3;
			this.groupPropertyGrid.Text = "propertyGrid1";
			this.groupPropertyGrid.ViewBackColor = System.Drawing.SystemColors.Window;
			this.groupPropertyGrid.ViewForeColor = System.Drawing.SystemColors.WindowText;
			// 
			// tvwCustom
			// 
			this.tvwCustom.ImageIndex = -1;
			this.tvwCustom.Location = new System.Drawing.Point(92, 236);
			this.tvwCustom.Name = "tvwCustom";
			this.tvwCustom.SelectedImageIndex = -1;
			this.tvwCustom.TabIndex = 9;
			// 
			// frmVsNetListBarTest
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(472, 398);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.tvwCustom,
																		  this.spltVSNetBar,
																		  this.vsNetListBar1,
																		  this.splitProperties,
																		  this.pnlProperties});
			this.Name = "frmVsNetListBarTest";
			this.Text = "frmVsNetListBarTest";
			this.Load += new System.EventHandler(this.frmVsNetListBarTest_Load);
			this.pnlProperties.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmVsNetListBarTest());
		}

		

		private void frmVsNetListBarTest_Load(object sender, System.EventArgs e)
		{

			Random randGen = new Random();

			// Add some items to the TreeView:
			tvwCustom.ImageList = ilsIconsSmall;
			tvwCustom.ShowLines = true;
			tvwCustom.ShowPlusMinus = true;		
			TreeNode[] childNodes = new TreeNode[10];
			for (int i = 0; i < 10; i++)
			{
				int iconIndex = randGen.Next(ilsIconsSmall.Images.Count);
				childNodes[i] = new TreeNode(
					String.Format("TreeItem {0}", i),
					iconIndex, iconIndex);
			}
			TreeNode nodTop = new TreeNode("Connections", 0, 0, childNodes);
			tvwCustom.Nodes.Add(nodTop);
			nodTop.Expand();			

			// Add some items to the ListBar:
			vsNetListBar1.LargeImageList = ilsIconsLarge;
			vsNetListBar1.SmallImageList = ilsIconsSmall;
			vsNetListBar1.ToolTip = toolTips;

			// Add some items to the ListBar:
			for (int i = 0; i < 4; i++)
			{
				int jMax = 2 + randGen.Next(10);
				VSNetListBarItem[] subItems = new VSNetListBarItem[jMax];
				for (int j = 0; j < jMax; j++)
				{
					subItems[j] = new VSNetListBarItem(
						String.Format("Test Item {0} in Bar {1}", j + 1, i + 1), 
						j % 4, 
						String.Format("Tooltip text for test item {0}", j + 1));
					if (j == 2)
					{
						subItems[j].Enabled = false;
					}
				}
				vsNetListBar1.Groups.Add(
					new VSNetListBarGroup(String.Format("Test {0}", i + 1), 
					subItems));
			}
			// Add a bar containing the Tree control:
			VSNetListBarGroup treeGroup = vsNetListBar1.Groups.Add("Tree");
			treeGroup.ChildControl = tvwCustom;

			// Configure ListBar events:
			this.vsNetListBar1.ItemClicked += new ItemClickedEventHandler(listBar1_ItemClicked);
			this.vsNetListBar1.ItemDoubleClicked += new ItemClickedEventHandler(listBar1_ItemDoubleClicked);
			this.vsNetListBar1.GroupClicked += new GroupClickedEventHandler(listBar1_GroupClicked);
			this.vsNetListBar1.SelectedGroupChanged += new EventHandler(listBar1_SelectedGroupChanged);

			// Group property editor
			this.cboGroups.SelectedIndexChanged += new System.EventHandler(this.cboGroups_SelectedIndexChanged);
			this.pnlProperties.SizeChanged += new System.EventHandler(this.pnlProperties_SizeChanged);

			this.showGroupProperties();
		

		}

	
		private void listBar1_SelectedGroupChanged(object sender, EventArgs e)
		{
			this.showGroupProperties();
		}

		private void listBar1_ItemClicked(object sender, ItemClickedEventArgs e)
		{
			if (e.MouseButton == MouseButtons.Right)
			{
				//contextItem = e.Item;
				//itemContextMenu.Show(listBar1, e.Location);
			}
		}

		private void listBar1_GroupClicked(object sender, GroupClickedEventArgs e)
		{
			if (e.MouseButton == MouseButtons.Right)
			{
				//contextGroup = e.Group;
				//groupContextMenu.Show(listBar1, e.Location);
			}
		}

		private void listBar1_ItemDoubleClicked(object sender, ItemClickedEventArgs e)
		{
			
		}


		private void cboGroups_SelectedIndexChanged(object sender, EventArgs e)
		{
			VSNetListBarGroup grp = (VSNetListBarGroup)cboGroups.SelectedItem;
			groupPropertyGrid.SelectedObject = grp;
			groupPropertyGrid.Update();
		}

		private void pnlProperties_SizeChanged(object sender, EventArgs e)
		{
			int height = pnlProperties.Height - groupPropertyGrid.Top - 4;
			if (height > 0)
			{
				groupPropertyGrid.Height = height;
			}
			int width = pnlProperties.Width - cboGroups.Left * 2;
			if (width > 0)
			{
				cboGroups.Width = width;
				groupPropertyGrid.Width = width;
			}
		}

		private void showGroupProperties()
		{
			cboGroups.Items.Clear();
			foreach (VSNetListBarGroup group in vsNetListBar1.Groups)
			{
				int newIndex = cboGroups.Items.Add(group);				
				if (group.Selected)
				{
					cboGroups.SelectedIndex = newIndex;
				}
			}
		}
	}
}
