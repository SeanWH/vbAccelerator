using System.Reflection;
using System.Runtime.CompilerServices;

//
// General Information about this assembly.
//
[assembly: AssemblyTitle("vbAccelerator VS.NET ListBar Control.")]
[assembly: AssemblyDescription("vbAccelerator VS.NET ListBar Control.")]
[assembly: AssemblyConfiguration("Retail")]
[assembly: AssemblyCompany("vbAccelerator")]
[assembly: AssemblyProduct("vbAccelerator VS.NET ListBar Control.")]
[assembly: AssemblyCopyright("Copyright (C) 2003 Steve McMahon for vbAccelerator")]
[assembly: AssemblyTrademark("vbAccelerator is a Trade Mark of vbAccelerator Limited.  All other Trade Marks duly acknowledged.")]
[assembly: AssemblyCulture("")]		

//
// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using '*'

[assembly: AssemblyVersion("1.0.1327.36198")]

//
// This control is shipped with a strong name signed by vbAccelerator.
// If you wish to create your own version of the control that has
// a strong name then you will need to revise the options below.
//
[assembly: AssemblyDelaySign(true)]
[assembly: AssemblyKeyFile("..\\..\\vbalPublic.snk")]
[assembly: AssemblyKeyName("")]
