Imports System.Runtime.InteropServices

Public Class WinMMInterop
    ''' <summary>
    ''' Structure describing the format of the data in a Wave file.
    ''' </summary>
    <StructLayoutAttribute(LayoutKind.Sequential, Pack:=2)> _
      Public Structure WAVEFORMATEX
        ''' <summary>
        ''' Waveform-audio format type. Format tags are registered with Microsoft 
        ''' Corporation for many compression algorithms.
        ''' </summary>
        Public wFormatTag As Int16
        ''' <summary>
        ''' Number of audio channels
        ''' </summary>
        Public nChannels As Int16
        ''' <summary>
        ''' Number of samples per second for the audio data.
        ''' </summary>
        Public nSamplesPerSec As Integer
        ''' <summary>
        ''' Average number of bytes per second in the audio data.
        ''' For non-compressed audio, the average number of bytes
        ''' is nSamplesPerSec * nBlockAlign.
        ''' </summary>
        Public nAvgBytesPerSec As Integer
        ''' <summary>
        ''' Alignment of samples in bits.
        ''' </summary>
        Public nBlockAlign As Int16
        ''' <summary>
        ''' Number of bits used for each audio sample.
        ''' </summary>
        Public wBitsPerSample As Int16
        ''' <summary>
        ''' Size of the structure (typically not used).
        ''' </summary>
        Public cbSize As Int16
    End Structure

    ''' <summary>
    ''' Contains information about a file opened using multimedia IO.
    ''' </summary>
    <StructLayoutAttribute(LayoutKind.Sequential)> _
      Public Structure MMIOINFO
        ''' <summary>
        ''' Flags specifying how a file was opened. The following values are defined: 
        ''' </summary>
        Public dwFlags As Integer
        ''' <summary>
        ''' Four-character code identifying the file's I/O procedure. If the I/O procedure 
        ''' is not an installed I/O procedure, this member is NULL. 
        ''' </summary>
        Public fccIOProc As Integer
        ''' <summary>
        ''' Pointer to file's IO procedure. 
        ''' </summary>
        Public pIOProc As IntPtr
        ''' <summary>
        ''' Extended error value from the mmioOpen function if it returns NULL.
        ''' </summary>
        Public wErrorRet As Integer
        ''' <summary>
        ''' Handle to a local I/O procedure. Media Control Interface (MCI) devices that 
        ''' perform file I/O in the background and need an I/O procedure can locate 
        ''' a local I/O procedure with this handle. 
        ''' </summary>
        Public hTask As IntPtr
        ''' <summary>
        ''' Size, in bytes, of the file's I/O buffer. If the file does not have an I/O buffer, 
        ''' this member is zero. 
        ''' </summary>
        Public cchBuffer As Integer
        ''' <summary>
        ''' Pointer to the file's I/O buffer. If the file is unbuffered, this member is NULL. 
        ''' </summary>
        Public pchBuffer As IntPtr
        ''' <summary>
        ''' Pointer to the next location in the I/O buffer to be read or written. If no more 
        ''' bytes can be read without calling the mmioAdvance or mmioRead function, this 
        ''' member points to the pchEndRead member. If no more bytes can be written without 
        ''' calling the mmioAdvance or mmioWrite function, this member points to the 
        ''' pchEndWrite member. 
        ''' </summary>
        Public pchNext As IntPtr
        ''' <summary>
        ''' Pointer to the location that is 1 byte past the last location in the buffer 
        ''' that can be read. 
        ''' </summary>
        Public pchEndRead As IntPtr
        ''' <summary>
        ''' Pointer to the location that is 1 byte past the last location in the buffer 
        ''' that can be written. 
        ''' </summary>
        Public pchEndWrite As IntPtr
        ''' <summary>
        ''' Reserved. 
        ''' </summary>
        Public lBufOffset As Integer
        ''' <summary>
        ''' Current file position, which is an offset, in bytes, from the beginning of 
        ''' the file. I/O procedures are responsible for maintaining this member. 
        ''' </summary>
        Public lDiskOffset As Integer
        ''' <summary>
        ''' State information maintained by the I/O procedure. I/O procedures can also 
        ''' use these members to transfer information from the application to the I/O 
        ''' procedure when the application opens a file. 
        ''' </summary>
        Public adwInfo0 As Integer
        ''' <summary>
        ''' State information maintained by the I/O procedure. I/O procedures can also 
        ''' use these members to transfer information from the application to the I/O 
        ''' procedure when the application opens a file. 
        ''' </summary>
        Public adwInfo1 As Integer
        ''' <summary>
        ''' State information maintained by the I/O procedure. I/O procedures can also 
        ''' use these members to transfer information from the application to the I/O 
        ''' procedure when the application opens a file. 
        ''' </summary>
        Public adwInfo2 As Integer
        ''' <summary>
        ''' State information maintained by the I/O procedure. I/O procedures can also 
        ''' use these members to transfer information from the application to the I/O 
        ''' procedure when the application opens a file. 
        ''' </summary>
        Public adwInfo3 As Integer
        ''' <summary>
        ''' Reserved. 
        ''' </summary>
        Public dwReserved1 As Integer
        ''' <summary>
        ''' Reserved. 
        ''' </summary>
        Public dwReserved2 As Integer
        ''' <summary>
        ''' Handle to the open file, as returned by the mmioOpen function. I/O 
        ''' procedures can use this handle when calling other multimedia file I/O 
        ''' functions. 
        ''' </summary>
        Public hMMIO As IntPtr
    End Structure

    ''' <summary>
    ''' Information about a chunk in a RIFF file.
    ''' </summary>
    <StructLayoutAttribute(LayoutKind.Sequential)> _
      Public Structure MMCKINFO
        ''' <summary>
        ''' Chunk identifier. 
        ''' </summary>
        Public ckid As Integer
        ''' <summary>
        ''' Size, in bytes, of the data member of the chunk. The size of the data 
        ''' member does not include the 4-byte chunk identifier, the 4-byte 
        ''' chunk size, or the optional pad byte at the end of the data member. 
        ''' </summary>
        Public ckSize As Integer
        ''' <summary>
        ''' Form type for "RIFF" chunks or the list type for "LIST" chunks. 
        ''' </summary>
        Public fccType As Integer
        ''' <summary>
        ''' File offset of the beginning of the chunk's data member, relative 
        ''' to the beginning of the file. 
        ''' </summary>
        Public dwDataOffset As Integer
        ''' <summary>
        ''' Flags specifying additional information about the chunk. Typically 
        ''' zero but can be MMIO_DIRTY indicating the size of the chunk has
        ''' changed.
        ''' </summary>
        Public dwFlags As Integer
    End Structure

    ''' <summary>
    ''' Closes a file opened using mmioOpen
    ''' </summary>
    ''' <param name="hmmio">Handle to the open file</param>
    ''' <param name="uFlags">flags</param>
    ''' <returns>Error code</returns>
    Public Declare Function mmioClose Lib "winmm" ( _
        ByVal hmmio As IntPtr, _
        ByVal uFlags As Integer) As Integer

    ''' <summary>
    ''' Descends into a chunk within the file
    ''' </summary>
    ''' <param name="hmmio">Handle to the open file</param>
    ''' <param name="lpck">Chunk to descend into</param>
    ''' <param name="lpckParent">Parent chunk to descend from</param>
    ''' <param name="uFlags">Flags controlling how to descend</param>
    ''' <returns>Error code</returns>
    Public Declare Function mmioDescend Lib "winmm" ( _
        ByVal hmmio As IntPtr, _
        ByRef lpck As MMCKINFO, _
        ByRef lpckParent As MMCKINFO, _
        ByVal uFlags As Integer) As Integer

    ''' <summary>
    ''' Same as <see cref="mmioDescend"/> but allows descent into
    ''' the top level chunk.
    ''' </summary>
    ''' <param name="hmmio">Handle to the open file</param>
    ''' <param name="lpck">Chunk to descend into</param>
    ''' <param name="x">Reserved, must be set to 0.</param>
    ''' <param name="uFlags">Flags controlling how to descend</param>
    ''' <returns>Error code</returns>
    Public Declare Function mmioDescendParent Lib "winmm" Alias "mmioDescend" ( _
      ByVal hmmio As IntPtr, _
      ByRef lpck As MMCKINFO, _
      ByVal x As Integer, _
      ByVal uFlags As Integer) As Integer

    ''' <summary>
    ''' Opens a multimedia RIFF file
    ''' </summary>
    ''' <param name="szFileName">File name</param>
    ''' <param name="lpMmioInfo">Pointer to a <see cref="MMIOINFO"/> structure</param>
    ''' <param name="dwOpenFlags">Flags controlling open type</param>
    ''' <returns>Handle to open file, or zero if open fails.</returns>
    Public Declare Auto Function mmioOpen Lib "winmm" ( _
        ByVal szFileName As String, _
        ByVal lpMmioInfo As IntPtr, _
        ByVal dwOpenFlags As Integer) As IntPtr

    ''' <summary>
    ''' Reads from the file into a buffer.
    ''' </summary>
    ''' <param name="hmmio">Handle to the open file</param>
    ''' <param name="pch">Pointer to the buffer</param>
    ''' <param name="cch">Number of bytes to read</param>
    ''' <returns>Number of bytes read</returns>
    Public Declare Function mmioRead Lib "winmm" ( _
        ByVal hmmio As IntPtr, _
        ByVal pch As IntPtr, _
        ByVal cch As Integer) As Integer

    ''' <summary>
    ''' Writes data to the file from a buffer
    ''' </summary>
    ''' <param name="hmmio">Handle to the open file</param>
    ''' <param name="pch">Pointer to the buffer</param>
    ''' <param name="cch">Number of bytes to write</param>
    ''' <returns>Number of bytes written</returns>
    Public Declare Function mmioWrite Lib "winmm" ( _
        ByVal hmmio As IntPtr, _
        ByVal pch As IntPtr, _
        ByVal cch As Integer) As Integer

    ''' <summary>
    ''' Reads a <see cref="WAVEFORMATEX"/> from the file.
    ''' </summary>
    ''' <param name="hmmio">Handle to the open file</param>
    ''' <param name="format">format structure to read</param>
    ''' <param name="cch">Number of bytes to read</param>
    ''' <returns>Number of bytes read</returns>
    Public Declare Function mmioReadWaveFormat Lib "winmm" Alias "mmioRead" ( _
        ByVal hmmio As IntPtr, _
        ByRef format As WAVEFORMATEX, _
        ByVal cch As Integer) As Integer

    ''' <summary>
    ''' Writes a <see cref="WAVEFORMATEX"/> to the file.
    ''' </summary>
    ''' <param name="hmmio">Handle to the open file</param>
    ''' <param name="format">format structure to write</param>
    ''' <param name="cch">Number of bytes to write</param>
    ''' <returns>Number of bytes written</returns>
    Public Declare Function mmioWriteWaveFormat Lib "winmm" Alias "mmioWrite" ( _
        ByVal hmmio As IntPtr, _
        ByRef format As WAVEFORMATEX, _
        ByVal cch As Integer) As Integer

    ''' <summary>
    ''' Seeks to the specified point in the file
    ''' </summary>
    ''' <param name="hmmio">Handle to the open file</param>
    ''' <param name="iOrigin">SEEK_* flag specifying the origin of the seek</param>
    ''' <param name="lOffset">Number of bytes to seek</param>
    ''' <returns>Error code</returns>
    Public Declare Function mmioSeek Lib "winmm" ( _
      ByVal hmmio As IntPtr, _
      ByVal lOffset As Integer, _
      ByVal iOrigin As Integer) As Integer

    ''' <summary>
    ''' Converts a string representing a FOURCC code to an actual
    ''' FOURCC code.
    ''' </summary>
    ''' <param name="sz">String containing the FOURCC code bytes</param>
    ''' <param name="uFlags">Flags controlling the conversion</param>
    ''' <returns>FOURCC code.</returns>
    Public Declare Auto Function mmioStringToFOURCC Lib "winmm" ( _
      <MarshalAs(UnmanagedType.LPTStr)> _
      ByVal sz As String, _
      ByVal uFlags As Integer) As Integer

    ''' <summary>
    ''' Ascends from a chunk in a multimedia file.
    ''' </summary>
    ''' <param name="hmmio">Handle to open file</param>
    ''' <param name="lpck">Chunk to ascend from</param>
    ''' <param name="uFlags">Flags controlling ascend</param>
    ''' <returns>Error code</returns>
    Public Declare Function mmioAscend Lib "winmm" ( _
      ByVal hmmio As IntPtr, _
      ByRef lpck As MMCKINFO, _
      ByVal uFlags As Integer) As Integer

    ''' <summary>
    ''' Creates a new chunk in a multimedia file.
    ''' </summary>
    ''' <param name="fuCreate">Flags describing how to create the chunk</param>
    ''' <param name="hmmio">Handle to open file</param>
    ''' <param name="pmmcki">Chunk to create</param>
    Public Declare Function mmioCreateChunk Lib "winmm" ( _
      ByVal hmmio As IntPtr, _
      ByRef pmmcki As MMCKINFO, _
      ByVal fuCreate As Integer) As Integer


    ''' <summary>
    ''' File read access
    ''' </summary>
    Public Const MMIO_READ As Integer = &H0
    ''' <summary>
    ''' File write access
    ''' </summary>
    Public Const MMIO_WRITE As Integer = &H1
    ''' <summary>
    '''  File read/write access
    ''' </summary>
    Public Const MMIO_READWRITE As Integer = &H2
    ''' <summary>
    ''' Find a chunk in a file
    ''' </summary>
    Public Const MMIO_FINDCHUNK As Integer = &H10
    ''' <summary>
    '''  Find RIFF header
    ''' </summary>
    Public Const MMIO_FINDRIFF As Integer = &H20
    ''' <summary>
    '''  Create RIFF header
    ''' </summary>
    Public Const MMIO_CREATERIFF As Integer = &H20
    ''' <summary>
    '''  Allocate buffer
    ''' </summary>
    Public Const MMIO_ALLOCBUF As Integer = &H10000
    ''' <summary>
    ''' Create file
    ''' </summary>
    Public Const MMIO_CREATE As Integer = &H1000

    ''' <summary>
    ''' Error code representing success
    ''' </summary>
    Public Const MMSYSERR_NOERROR As Integer = 0
    ''' <summary>
    ''' Seek from current position
    ''' </summary>
    Public Const SEEK_CUR As Integer = 1
    ''' <summary>
    ''' Seek from end of file
    ''' </summary>
    Public Const SEEK_END As Integer = 2
    ''' <summary>
    ''' Seek from beginning of file
    ''' </summary>
    Public Const SEEK_SET As Integer = 0

    ''' <summary>
    ''' Prevent instantiation
    ''' </summary>
    Private Sub New()

    End Sub

End Class
