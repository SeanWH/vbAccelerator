''' <summary>
''' Summary description for WaveStreamException.
''' </summary>
Public Class WaveStreamException
    Inherits Exception

    ''' <summary>
    ''' Constructs a new, default exception
    ''' </summary>
    Public Sub New()
        MyBase.New()
    End Sub

    ''' <summary>
    ''' Constructs a new exception.
    ''' </summary>
    ''' <param name="message">Error message</param>
    Public Sub New(ByVal message As String)
        MyBase.New(message)
    End Sub

    ''' <summary>
    ''' Constructs a new exception
    ''' </summary>
    ''' <param name="message">Error message</param>
    ''' <param name="innerException">Exception leading to this exception</param>
    Public Sub New(ByVal message As String, ByVal innerException As Exception)
        MyBase.New(message, innerException)
    End Sub


End Class
