Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("WaveStream")> 
<Assembly: AssemblyDescription(".NET Wrappers for reading and writing PCM Wave Files")> 
<Assembly: AssemblyConfiguration("Release")> 
<Assembly: AssemblyCompany("vbAccelerator")> 
<Assembly: AssemblyProduct("WaveStream")> 
<Assembly: AssemblyCopyright("Copyright (C) 2004 Steve McMahon for vbAccelerator.com")> 
<Assembly: AssemblyTrademark("vbAccelerator and vbAccelerator.com are trademarks of vbAccelerator Ltd.  All Rights Reserved.")> 
<Assembly: AssemblyCulture("")> 

<Assembly: CLSCompliant(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("DF1CA240-7E4C-435D-A74A-7B2F47AE0E1F")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.0.0")> 
