Imports WaveStreamVB

Public Class frmWaveStreamSample
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents prgSave As System.Windows.Forms.ProgressBar
    Friend WithEvents grpProperties As System.Windows.Forms.GroupBox
    Friend WithEvents txtFrequency As System.Windows.Forms.TextBox
    Friend WithEvents txtBitsPerSample As System.Windows.Forms.TextBox
    Friend WithEvents txtChannels As System.Windows.Forms.TextBox
    Friend WithEvents txtLength As System.Windows.Forms.TextBox
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnOpenSource As System.Windows.Forms.Button
    Friend WithEvents txtSourceFile As System.Windows.Forms.TextBox
    Friend WithEvents lblInput As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.prgSave = New System.Windows.Forms.ProgressBar()
        Me.grpProperties = New System.Windows.Forms.GroupBox()
        Me.txtFrequency = New System.Windows.Forms.TextBox()
        Me.txtBitsPerSample = New System.Windows.Forms.TextBox()
        Me.txtChannels = New System.Windows.Forms.TextBox()
        Me.txtLength = New System.Windows.Forms.TextBox()
        Me.label4 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnOpenSource = New System.Windows.Forms.Button()
        Me.txtSourceFile = New System.Windows.Forms.TextBox()
        Me.lblInput = New System.Windows.Forms.Label()
        Me.grpProperties.SuspendLayout()
        Me.SuspendLayout()
        '
        'prgSave
        '
        Me.prgSave.Location = New System.Drawing.Point(172, 224)
        Me.prgSave.Name = "prgSave"
        Me.prgSave.Size = New System.Drawing.Size(184, 24)
        Me.prgSave.TabIndex = 13
        '
        'grpProperties
        '
        Me.grpProperties.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtFrequency, Me.txtBitsPerSample, Me.txtChannels, Me.txtLength, Me.label4, Me.label3, Me.label2, Me.label1})
        Me.grpProperties.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.grpProperties.Location = New System.Drawing.Point(84, 64)
        Me.grpProperties.Name = "grpProperties"
        Me.grpProperties.Size = New System.Drawing.Size(276, 152)
        Me.grpProperties.TabIndex = 12
        Me.grpProperties.TabStop = False
        Me.grpProperties.Text = "&Properties"
        '
        'txtFrequency
        '
        Me.txtFrequency.Location = New System.Drawing.Point(92, 96)
        Me.txtFrequency.Name = "txtFrequency"
        Me.txtFrequency.ReadOnly = True
        Me.txtFrequency.Size = New System.Drawing.Size(180, 21)
        Me.txtFrequency.TabIndex = 8
        Me.txtFrequency.Text = ""
        '
        'txtBitsPerSample
        '
        Me.txtBitsPerSample.Location = New System.Drawing.Point(92, 72)
        Me.txtBitsPerSample.Name = "txtBitsPerSample"
        Me.txtBitsPerSample.ReadOnly = True
        Me.txtBitsPerSample.Size = New System.Drawing.Size(180, 21)
        Me.txtBitsPerSample.TabIndex = 7
        Me.txtBitsPerSample.Text = ""
        '
        'txtChannels
        '
        Me.txtChannels.Location = New System.Drawing.Point(92, 48)
        Me.txtChannels.Name = "txtChannels"
        Me.txtChannels.ReadOnly = True
        Me.txtChannels.Size = New System.Drawing.Size(180, 21)
        Me.txtChannels.TabIndex = 6
        Me.txtChannels.Text = ""
        '
        'txtLength
        '
        Me.txtLength.Location = New System.Drawing.Point(92, 20)
        Me.txtLength.Name = "txtLength"
        Me.txtLength.ReadOnly = True
        Me.txtLength.Size = New System.Drawing.Size(180, 21)
        Me.txtLength.TabIndex = 5
        Me.txtLength.Text = ""
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(8, 100)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(80, 20)
        Me.label4.TabIndex = 4
        Me.label4.Text = "&Frequency"
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(8, 76)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(80, 20)
        Me.label3.TabIndex = 3
        Me.label3.Text = "&Bits/Sample"
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(8, 48)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(80, 20)
        Me.label2.TabIndex = 2
        Me.label2.Text = "&Channels"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(8, 24)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(80, 20)
        Me.label1.TabIndex = 1
        Me.label1.Text = "&Length"
        '
        'btnSave
        '
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnSave.Location = New System.Drawing.Point(84, 224)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(80, 24)
        Me.btnSave.TabIndex = 11
        Me.btnSave.Text = "&Save..."
        '
        'btnOpenSource
        '
        Me.btnOpenSource.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnOpenSource.Location = New System.Drawing.Point(84, 32)
        Me.btnOpenSource.Name = "btnOpenSource"
        Me.btnOpenSource.Size = New System.Drawing.Size(80, 24)
        Me.btnOpenSource.TabIndex = 10
        Me.btnOpenSource.Text = "&Open..."
        '
        'txtSourceFile
        '
        Me.txtSourceFile.Location = New System.Drawing.Point(84, 4)
        Me.txtSourceFile.Name = "txtSourceFile"
        Me.txtSourceFile.Size = New System.Drawing.Size(276, 21)
        Me.txtSourceFile.TabIndex = 9
        Me.txtSourceFile.Text = ""
        '
        'lblInput
        '
        Me.lblInput.Location = New System.Drawing.Point(8, 8)
        Me.lblInput.Name = "lblInput"
        Me.lblInput.Size = New System.Drawing.Size(80, 20)
        Me.lblInput.TabIndex = 8
        Me.lblInput.Text = "&Source File:"
        '
        'frmWaveStreamSample
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(368, 258)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.prgSave, Me.grpProperties, Me.btnSave, Me.btnOpenSource, Me.txtSourceFile, Me.lblInput})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmWaveStreamSample"
        Me.Text = "WaveStream Sample"
        Me.grpProperties.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnOpenSource_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpenSource.Click
        Dim f As OpenFileDialog = New OpenFileDialog()
        f.Filter = "Wave Files (*.WAV)|*.WAV|All Files (*.*)|*.*"
        f.DefaultExt = "WAV"
        If (f.ShowDialog(Me) = DialogResult.OK) Then
            OpenFile(f.FileName)
        End If
        f.Dispose()
    End Sub

    Private Sub OpenFile(ByVal fileName As String)
        txtSourceFile.Text = ""
        btnSave.Enabled = False

        Dim reader As WaveStreamReader = Nothing
        Dim ex As Exception
        Try
            reader = New WaveStreamReader(fileName)
            Dim lengthSeconds As Double = ((reader.Channels * reader.BitsPerSample) / 8)
            lengthSeconds = reader.Length / (reader.SamplingFrequency * lengthSeconds)
            txtLength.Text = lengthSeconds.ToString("#0.00") + "s"
            txtChannels.Text = reader.Channels.ToString()
            txtBitsPerSample.Text = reader.BitsPerSample.ToString()
            txtFrequency.Text = reader.SamplingFrequency.ToString()

            txtSourceFile.Text = fileName
            btnSave.Enabled = True
        Catch ex
            MessageBox.Show(Me, String.Format("Could not open file {0}: {1}", fileName, ex), _
             Text, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Finally
            If Not (reader Is Nothing) Then
                reader.Dispose()
            End If
        End Try
    End Sub


    Private Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim f As SaveFileDialog = New SaveFileDialog()
        f.Filter = "Wave Files (*.WAV)|*.WAV|All Files (*.*)|*.*"
        f.DefaultExt = "WAV"
        If (f.ShowDialog(Me) = DialogResult.OK) Then
            SaveFile(f.FileName)
        End If
        f.Dispose()
    End Sub

    Private Sub SaveFile(ByVal fileName As String)

        Enabled = False
        Dim reader As WaveStreamReader = Nothing
        Dim writer As WaveStreamWriter = Nothing
        Dim ex As Exception

        Try
            reader = New WaveStreamReader(txtSourceFile.Text)
				writer = new WaveStreamWriter(fileName, _
					reader.SamplingFrequency, reader.Channels, reader.BitsPerSample)

            prgSave.Maximum = reader.Length
            Dim readSize As Integer = 65536
            Dim buffer(readSize - 1) As Byte
            Dim size As Integer = 0
            Dim complete As Boolean = False
            Do
                size = reader.Read(buffer, 0, readSize)
                If (size > 0) Then
                    writer.Write(buffer, 0, readSize)
                    If (prgSave.Value + readSize < prgSave.Maximum) Then
                        prgSave.Value += readSize
                    End If
                    'better to multi-thread
                    Application.DoEvents()
                End If
            Loop While (size > 0)
        Catch ex
			MessageBox.Show(Me, String.Format("Failed to save to file {0}: {1}", fileName, ex), _
					Text, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Finally
            If Not (writer Is Nothing) Then
                writer.Dispose()
            End If
            If Not (reader Is Nothing) Then
                reader.Dispose()
            End If
            Enabled = True
        End Try

    End Sub

End Class
