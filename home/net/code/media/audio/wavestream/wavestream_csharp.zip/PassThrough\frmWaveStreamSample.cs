using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using vbAccelerator.Audio.WaveStream;

namespace PassThrough
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label lblInput;
		private System.Windows.Forms.TextBox txtSourceFile;
		private System.Windows.Forms.Button btnOpenSource;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.GroupBox grpProperties;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtLength;
		private System.Windows.Forms.TextBox txtChannels;
		private System.Windows.Forms.TextBox txtBitsPerSample;
		private System.Windows.Forms.TextBox txtFrequency;
		private System.Windows.Forms.ProgressBar prgSave;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblInput = new System.Windows.Forms.Label();
			this.txtSourceFile = new System.Windows.Forms.TextBox();
			this.btnOpenSource = new System.Windows.Forms.Button();
			this.btnSave = new System.Windows.Forms.Button();
			this.grpProperties = new System.Windows.Forms.GroupBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.txtLength = new System.Windows.Forms.TextBox();
			this.txtChannels = new System.Windows.Forms.TextBox();
			this.txtBitsPerSample = new System.Windows.Forms.TextBox();
			this.txtFrequency = new System.Windows.Forms.TextBox();
			this.prgSave = new System.Windows.Forms.ProgressBar();
			this.grpProperties.SuspendLayout();
			this.SuspendLayout();
			// 
			// lblInput
			// 
			this.lblInput.Location = new System.Drawing.Point(8, 8);
			this.lblInput.Name = "lblInput";
			this.lblInput.Size = new System.Drawing.Size(80, 20);
			this.lblInput.TabIndex = 0;
			this.lblInput.Text = "&Source File:";
			// 
			// txtSourceFile
			// 
			this.txtSourceFile.Location = new System.Drawing.Point(84, 4);
			this.txtSourceFile.Name = "txtSourceFile";
			this.txtSourceFile.Size = new System.Drawing.Size(276, 21);
			this.txtSourceFile.TabIndex = 1;
			this.txtSourceFile.Text = "";
			// 
			// btnOpenSource
			// 
			this.btnOpenSource.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnOpenSource.Location = new System.Drawing.Point(84, 32);
			this.btnOpenSource.Name = "btnOpenSource";
			this.btnOpenSource.Size = new System.Drawing.Size(80, 24);
			this.btnOpenSource.TabIndex = 2;
			this.btnOpenSource.Text = "&Open...";
			this.btnOpenSource.Click += new System.EventHandler(this.btnOpenSource_Click);
			// 
			// btnSave
			// 
			this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnSave.Location = new System.Drawing.Point(84, 224);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(80, 24);
			this.btnSave.TabIndex = 5;
			this.btnSave.Text = "&Save...";
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// grpProperties
			// 
			this.grpProperties.Controls.AddRange(new System.Windows.Forms.Control[] {
																						this.txtFrequency,
																						this.txtBitsPerSample,
																						this.txtChannels,
																						this.txtLength,
																						this.label4,
																						this.label3,
																						this.label2,
																						this.label1});
			this.grpProperties.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.grpProperties.Location = new System.Drawing.Point(84, 64);
			this.grpProperties.Name = "grpProperties";
			this.grpProperties.Size = new System.Drawing.Size(276, 152);
			this.grpProperties.TabIndex = 6;
			this.grpProperties.TabStop = false;
			this.grpProperties.Text = "&Properties";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 24);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(80, 20);
			this.label1.TabIndex = 1;
			this.label1.Text = "&Length";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 48);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(80, 20);
			this.label2.TabIndex = 2;
			this.label2.Text = "&Channels";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 76);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(80, 20);
			this.label3.TabIndex = 3;
			this.label3.Text = "&Bits/Sample";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(8, 100);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(80, 20);
			this.label4.TabIndex = 4;
			this.label4.Text = "&Frequency";
			// 
			// txtLength
			// 
			this.txtLength.Location = new System.Drawing.Point(92, 20);
			this.txtLength.Name = "txtLength";
			this.txtLength.ReadOnly = true;
			this.txtLength.Size = new System.Drawing.Size(180, 21);
			this.txtLength.TabIndex = 5;
			this.txtLength.Text = "";
			// 
			// txtChannels
			// 
			this.txtChannels.Location = new System.Drawing.Point(92, 48);
			this.txtChannels.Name = "txtChannels";
			this.txtChannels.ReadOnly = true;
			this.txtChannels.Size = new System.Drawing.Size(180, 21);
			this.txtChannels.TabIndex = 6;
			this.txtChannels.Text = "";
			// 
			// txtBitsPerSample
			// 
			this.txtBitsPerSample.Location = new System.Drawing.Point(92, 72);
			this.txtBitsPerSample.Name = "txtBitsPerSample";
			this.txtBitsPerSample.ReadOnly = true;
			this.txtBitsPerSample.Size = new System.Drawing.Size(180, 21);
			this.txtBitsPerSample.TabIndex = 7;
			this.txtBitsPerSample.Text = "";
			// 
			// txtFrequency
			// 
			this.txtFrequency.Location = new System.Drawing.Point(92, 96);
			this.txtFrequency.Name = "txtFrequency";
			this.txtFrequency.ReadOnly = true;
			this.txtFrequency.Size = new System.Drawing.Size(180, 21);
			this.txtFrequency.TabIndex = 8;
			this.txtFrequency.Text = "";
			// 
			// prgSave
			// 
			this.prgSave.Location = new System.Drawing.Point(172, 224);
			this.prgSave.Name = "prgSave";
			this.prgSave.Size = new System.Drawing.Size(184, 24);
			this.prgSave.TabIndex = 7;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(368, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.prgSave,
																		  this.grpProperties,
																		  this.btnSave,
																		  this.btnOpenSource,
																		  this.txtSourceFile,
																		  this.lblInput});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form1";
			this.Text = "WaveStream Sample";
			this.grpProperties.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void btnOpenSource_Click(object sender, System.EventArgs e)
		{
			using (OpenFileDialog f = new OpenFileDialog())
			{
				f.Filter = "Wave Files (*.WAV)|*.WAV|All Files (*.*)|*.*";
				f.DefaultExt = "WAV";
				if (f.ShowDialog(this) == DialogResult.OK)
				{
					OpenFile(f.FileName);
				}
			}		
		}

		private void OpenFile(string fileName)
		{
			txtSourceFile.Text = "";
			btnSave.Enabled = false;

			WaveStreamReader reader = null;
			try
			{
				reader = new WaveStreamReader(fileName);
				double lengthSeconds = ((reader.Channels * reader.BitsPerSample) / 8);
				lengthSeconds = reader.Length / (reader.SamplingFrequency * lengthSeconds);
				txtLength.Text = lengthSeconds.ToString("#0.00") + "s";
				txtChannels.Text = reader.Channels.ToString();
				txtBitsPerSample.Text = reader.BitsPerSample.ToString();
				txtFrequency.Text = reader.SamplingFrequency.ToString();
				
				txtSourceFile.Text = fileName;
				btnSave.Enabled = true;
			}
			catch (Exception ex)
			{				
				MessageBox.Show(this, String.Format("Could not open file {0}: {1}", fileName, ex),
					Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			finally
			{
				if (reader != null)
				{
					reader.Dispose();
				}
			}
		}

		private void btnSave_Click(object sender, System.EventArgs e)
		{
			using (SaveFileDialog f = new SaveFileDialog())
			{
				f.Filter = "Wave Files (*.WAV)|*.WAV|All Files (*.*)|*.*";
				f.DefaultExt = "WAV";
				if (f.ShowDialog(this) == DialogResult.OK)
				{
					SaveFile(f.FileName);
				}
			}
		}

		private void SaveFile(string fileName)
		{
			Enabled = false;
			WaveStreamReader reader = null;
			WaveStreamWriter writer = null;
			try
			{
				reader = new WaveStreamReader(txtSourceFile.Text);
				writer = new WaveStreamWriter(fileName, 
					reader.SamplingFrequency, reader.Channels, reader.BitsPerSample);

				prgSave.Maximum = (int) reader.Length;
				int readSize = 65536;
				byte[] buffer = new byte[readSize];
				int size = 0;
				while ((size = reader.Read(buffer, 0, readSize)) > 0)
				{
					writer.Write(buffer, 0, readSize);
					if (prgSave.Value + readSize < prgSave.Maximum)
					{
						prgSave.Value += readSize;
					}
					// better to multi-thread
					Application.DoEvents();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(this, String.Format("Failed to save to file {0}: {1}", fileName, ex),
					Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			finally
			{
				if (writer != null)
				{
					writer.Dispose();
				}
				if (reader != null)
				{
					reader.Dispose();
				}
				Enabled = true;
			}

		}
	}
}
