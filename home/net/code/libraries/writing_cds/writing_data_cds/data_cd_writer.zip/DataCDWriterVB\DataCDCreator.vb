Imports System.IO
Imports vbAccelerator.Components.ImapiWrapper

''' <summary>
''' Delegate representing the CreateCD method
''' </summary>
Public Delegate Sub CreateCDDelegate(ByVal simulate As Boolean, ByVal ejectWhenComplete As Boolean, ByVal overwrite As Boolean)

''' <summary>
''' Simple wrapper to create an Audio CD from a series of tracks.  By
''' wrapping the function in a class we can call the burn method on
''' a background thread using <c>BeginInvoke</c>.
''' Note that this class is limited in that it can only write all of the 
''' files from an existing subdirectory to the CD.  This is not a 
''' limitation of the IMAPIWrapper, where you can specify both
''' the source and the destination names of the files independently.
''' </summary>
Public Class DataCDCreator

    Private discMaster As discMaster = Nothing
    Private jolietDiscMaster As JolietDiscMaster = Nothing

    ''' <summary>
    ''' Construct a new instance of the class
    ''' </summary>
    ''' <param name="discMaster">Disc Master</param>
    ''' <param name="jolietDiscMaster">Joliet Disc Master</param>
    Public Sub New(ByVal discMasterParam As discMaster, ByVal jolietDiscMasterParam As jolietDiscMaster)
        discMaster = discMasterParam
        jolietDiscMaster = jolietDiscMasterParam
        jolietDiscMaster.RootStorage.Clear()
    End Sub

    ''' <summary>
    ''' Adds a directory to the storage, optionally including
    ''' any subdirectories.
    ''' </summary>
    ''' <param name="path">Path to the directory to add</param>
    ''' <param name="recurse"><c>true</c> to include subdirectories,
    ''' <c>false</c> otherwise.</param>
    Public Sub AddDirectory(ByVal path As String, ByVal recurse As Boolean)
        Dim storage As JolietDiscMasterStorage = jolietDiscMaster.RootStorage
        AddFilesToStorage(storage, path, recurse)
    End Sub

    Private Sub AddFilesToStorage(ByVal storage As JolietDiscMasterStorage, ByVal startPath As String, ByVal recurse As Boolean)
        If (recurse) Then
            Dim dir As String
            For Each dir In Directory.GetDirectories(startPath)
                Dim subStorage As JolietDiscMasterStorage = storage.CreateSubFolder(Path.GetFileName(dir))
                AddFilesToStorage(subStorage, dir, recurse)				
            Next
        End If

        Dim file As String
        For Each file In Directory.GetFiles(startPath)
            storage.AddFile(file, Path.GetFileName(file))

        Next
    End Sub

    ''' <summary>
    ''' Creates a data CD from the specified files
    ''' </summary>
    ''' <param name="simulate">Simulate CD burning</param>
    ''' <param name="ejectWhenComplete"><c>true</c> to eject the CD
    ''' tray when the burn is complete, <c>false</c> otherwise</param>
    ''' <param name="overwrite"><c>true</c> to overwrite existing files
    ''' on CDRW media, <c>false</c> otherwise</param>
    Public Sub CreateCD(ByVal simulate As Boolean, ByVal ejectWhenComplete As Boolean, ByVal overwrite As Boolean)
        '// Ensure we don't have anything in the stage
        discMaster.ClearFormatContent()

        '// Stage the content
        jolietDiscMaster.AddData(overwrite)

        '// burn the disc
        discMaster.RecordDisc(simulate, ejectWhenComplete)

        '// Easy!
    End Sub

End Class
