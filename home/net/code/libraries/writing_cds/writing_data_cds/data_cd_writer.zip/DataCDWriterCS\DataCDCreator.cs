using System;
using System.IO;
using vbAccelerator.Components.ImapiWrapper;

namespace DataCDWriter
{

	/// <summary>
	/// Delegate representing the CreateCD method
	/// </summary>
	public delegate void CreateCDDelegate(bool simulate, bool ejectWhenComplete, bool overwrite);

	/// <summary>
	/// Simple wrapper to create an Audio CD from a series of tracks.  By
	/// wrapping the function in a class we can call the burn method on
	/// a background thread using <c>BeginInvoke</c>.
	/// Note that this class is limited in that it can only write all of the 
	/// files from an existing subdirectory to the CD.  This is not a 
	/// limitation of the IMAPIWrapper, where you can specify both
	/// the source and the destination names of the files independently.
	/// </summary>
	public class DataCDCreator
	{
		private DiscMaster discMaster = null;
		private JolietDiscMaster jolietDiscMaster = null;

		/// <summary>
		/// Construct a new instance of the class
		/// </summary>
		/// <param name="discMaster">Disc Master</param>
		/// <param name="jolietDiscMaster">Joliet Disc Master</param>
		public DataCDCreator(DiscMaster discMaster, JolietDiscMaster jolietDiscMaster)
		{
			this.discMaster = discMaster;
			this.jolietDiscMaster = jolietDiscMaster;
			jolietDiscMaster.RootStorage.Clear();
		}

		/// <summary>
		/// Adds a directory to the storage, optionally including
		/// any subdirectories.
		/// </summary>
		/// <param name="path">Path to the directory to add</param>
		/// <param name="recurse"><c>true</c> to include subdirectories,
		/// <c>false</c> otherwise.</param>
		public void AddDirectory(string path, bool recurse)
		{
			JolietDiscMasterStorage storage = jolietDiscMaster.RootStorage;
			AddFilesToStorage(storage, path, recurse);
		}

		private void AddFilesToStorage(JolietDiscMasterStorage storage, string startPath, bool recurse)
		{
			if (recurse)
			{
				foreach (string dir in Directory.GetDirectories(startPath))
				{
					JolietDiscMasterStorage subStorage = storage.CreateSubFolder(Path.GetFileName(dir));
					AddFilesToStorage(subStorage, dir, recurse);
				}
			}

			foreach (string file in Directory.GetFiles(startPath))
			{
				storage.AddFile(file, Path.GetFileName(file));
			}
		}

		/// <summary>
		/// Creates a data CD from the specified files
		/// </summary>
		/// <param name="simulate">Simulate CD burning</param>
		/// <param name="ejectWhenComplete"><c>true</c> to eject the CD
		/// tray when the burn is complete, <c>false</c> otherwise</param>
		/// <param name="overwrite"><c>true</c> to overwrite existing files
		/// on CDRW media, <c>false</c> otherwise</param>
		public void CreateCD(bool simulate, bool ejectWhenComplete, bool overwrite)
		{
			// Ensure we don't have anything in the stage
			discMaster.ClearFormatContent();

			// Stage the content
			jolietDiscMaster.AddData(overwrite);

			// burn the disc
			discMaster.RecordDisc(simulate, ejectWhenComplete);

			// Easy!
		}

	}
}
