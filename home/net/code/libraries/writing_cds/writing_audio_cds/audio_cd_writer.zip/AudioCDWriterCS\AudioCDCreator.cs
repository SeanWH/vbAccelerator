using System;
using System.Collections;
using vbAccelerator.Components.ImapiWrapper;
using vbAccelerator.Audio.WaveStream;

namespace AudioCDWriter
{

	/// <summary>
	/// Delegate representing the CreateCD method
	/// </summary>
	public delegate void CreateCDDelegate(bool simulate, bool ejectWhenComplete);

	/// <summary>
	/// Simple wrapper to create an Audio CD from a series of tracks.  By
	/// wrapping the function in a class we can call the burn method on
	/// a background thread using <c>BeginInvoke</c>.
	/// </summary>
	public class AudioCDCreator
	{
		private readonly DiscMaster discMaster;
		private readonly RedbookDiscMaster redbookDiscMaster;
		private ArrayList files;

		/// <summary>
		/// Constructor.  When this class is constructed redbook should
		/// have been set as the active disc master format and a disc
		/// recorder needs to have been made active.		
		/// </summary>
		/// <param name="discMaster">Disc master object</param>
		/// <param name="redbookDiscMaster">Redbook Disc master object</param>
		public AudioCDCreator(DiscMaster discMaster, RedbookDiscMaster redbookDiscMaster)
		{
			this.discMaster = discMaster;
			this.redbookDiscMaster = redbookDiscMaster;
			files = new ArrayList();
		}

		/// <summary>
		/// Adds a file to record.  Files should be added in track order.
		/// </summary>
		/// <param name="fileName">File name of the track</param>
		public void AddFile(string fileName)
		{
			files.Add(fileName);
		}

		/// <summary>
		/// Creates an audio CD from the specified files
		/// </summary>
		/// <param name="simulate">Simulate CD burning</param>
		/// <param name="ejectWhenComplete"><c>true</c> to eject the CD
		/// tray when the burn is complete, <c>false</c> otherwise</param>
		public void CreateCD(bool simulate, bool ejectWhenComplete)
		{
			// Ensure we don't have anything in the stage
			discMaster.ClearFormatContent();

			// Stage the content
			foreach (string file in files)
			{
				WaveStreamReader waveStream = new WaveStreamReader(file);
				redbookDiscMaster.AddAudioTrackFromStream(waveStream);
				waveStream.Dispose();
			}

			// burn the disc
			discMaster.RecordDisc(simulate, ejectWhenComplete);

			/// How easy was that?
		}


	}
}
