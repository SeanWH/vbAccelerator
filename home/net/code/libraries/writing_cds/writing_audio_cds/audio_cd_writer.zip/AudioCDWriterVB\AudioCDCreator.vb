Imports vbAccelerator.Components.ImapiWrapper

''' <summary>
''' Delegate representing the CreateCD method
''' </summary>
Public Delegate Sub CreateCDDelegate(ByVal simulate As Boolean, ByVal ejectWhenComplete As Boolean)

''' <summary>
''' Simple wrapper to create an Audio CD from a series of tracks.  By
''' wrapping the function in a class we can call the burn method on
''' a background thread using <c>BeginInvoke</c>.
''' </summary>
Public Class AudioCDCreator
    Private ReadOnly m_discMaster As DiscMaster
    Private ReadOnly m_redbookDiscMaster As RedbookDiscMaster
    Private ReadOnly m_files As ArrayList

    ''' <summary>
    ''' Constructor.  When this class is constructed redbook should
    ''' have been set as the active disc master format and a disc
    ''' recorder needs to have been made active.		
    ''' </summary>
    ''' <param name="discMaster">Disc master object</param>
    ''' <param name="redbookDiscMaster">Redbook Disc master object</param>
    Public Sub New(ByVal discMasterParam As DiscMaster, ByVal redbookDiscMasterParam As RedbookDiscMaster)
        m_discMaster = discMasterParam
        m_redbookDiscMaster = redbookDiscMasterParam
        m_files = New ArrayList()
    End Sub

    ''' <summary>
    ''' Adds a file to record.  Files should be added in track order.
    ''' </summary>
    ''' <param name="fileName">File name of the track</param>
    Public Sub AddFile(ByVal fileName As String)
        m_files.Add(fileName)
    End Sub

    ''' <summary>
    ''' Creates an audio CD from the specified files
    ''' </summary>
    ''' <param name="simulate">Simulate CD burning</param>
    ''' <param name="ejectWhenComplete"><c>true</c> to eject the CD
    ''' tray when the burn is complete, <c>false</c> otherwise</param>
    Public Sub CreateCD(ByVal simulate As Boolean, ByVal ejectWhenComplete As Boolean)
        '// Ensure we don't have anything in the stage
        m_discMaster.ClearFormatContent()

        '// Stage the content
        Dim file As String
        For Each file In m_files
            Dim waveStream As WaveStreamReader = New WaveStreamReader(file)
            m_redbookDiscMaster.AddAudioTrackFromStream(waveStream)
            waveStream.Dispose()
        Next

        '// burn the disc
        m_discMaster.RecordDisc(simulate, ejectWhenComplete)

        ''' How easy was that?
    End Sub


End Class
