using System;

namespace vbAccelerator.Components.ImapiWrapper
{
	/// <summary>
	/// Collection of properties associated with a Joliet Disc Master instance.
	/// </summary>
	public class JolietDiscMasterProperties : PropertyStorage
	{
		internal JolietDiscMasterProperties(IPropertyStorage propertyStorage) : base(propertyStorage)
		{
		}

	}
}
