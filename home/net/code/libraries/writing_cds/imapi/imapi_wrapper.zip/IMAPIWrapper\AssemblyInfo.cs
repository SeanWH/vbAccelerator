using System.Reflection;
using System.Runtime.CompilerServices;

//
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
//
[assembly: AssemblyTitle("vbAccelerator IMAPI Wrapper")]
[assembly: AssemblyDescription("Wrapper around the Image Mastering API for use from Managed Code")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyCompany("vbAccelerator Ltd")]
[assembly: AssemblyProduct("vbAccelerator IMAPI Wrapper")]
[assembly: AssemblyCopyright("Copyright � 2004 Steve McMahon for vbAccelerator.com")]
[assembly: AssemblyTrademark("vbAccelerator and vbAccelerator.com are trademarks of vbAccelerator Ltd.  All Rights Reserved.")]
[assembly: AssemblyCulture("")]		

//
// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:

[assembly: AssemblyVersion("1.0.0.0")]

//
// This library is shipped with a strong name signed by vbAccelerator.
// If you wish to create your own version of the control that has
// a strong name then you will need to revise the options below.
//
[assembly: AssemblyDelaySign(true)]
[assembly: AssemblyKeyFile("..\\..\\vbalPublic.snk")]
[assembly: AssemblyKeyName("")]
