Imports vbAccelerator.Components.ImapiWrapper

Public Class frmIMAPIProperties
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        Show()
        Refresh()

        DisplayRecorders()

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents tvwRecorders As System.Windows.Forms.TreeView
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmIMAPIProperties))
        Me.tvwRecorders = New System.Windows.Forms.TreeView()
        Me.SuspendLayout()
        '
        'tvwRecorders
        '
        Me.tvwRecorders.ImageIndex = -1
        Me.tvwRecorders.Location = New System.Drawing.Point(8, 7)
        Me.tvwRecorders.Name = "tvwRecorders"
        Me.tvwRecorders.SelectedImageIndex = -1
        Me.tvwRecorders.Size = New System.Drawing.Size(404, 428)
        Me.tvwRecorders.TabIndex = 2
        '
        'frmIMAPIProperties
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(420, 446)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.tvwRecorders})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmIMAPIProperties"
        Me.Text = "IMAPI Properties Demonstration"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub DisplayRecorders()

        Cursor.Current = Cursors.WaitCursor

        tvwRecorders.Nodes.Clear()

        Dim dm As DiscMaster = New DiscMaster()
        Dim simpleRecorder As SimpleDiscRecorder = dm.SimpleDiscRecorder

        Dim simpleNode As TreeNode = tvwRecorders.Nodes.Add("Simple CD Burner")
        If (simpleRecorder.HasRecordableDrive()) Then

            simpleNode.Nodes.Add( _
                String.Format("Drive Letter: {0}", simpleRecorder.GetRecorderDriveLetter()))
            simpleNode.Nodes.Add( _
                String.Format("Staging Area: {0}", simpleRecorder.GetBurnStagingAreaFolder(Handle)))
        Else
            simpleNode.Nodes.Add("Not present")
        End If
        simpleNode.Expand()

        Dim recordersNode As TreeNode = tvwRecorders.Nodes.Add("Recorders")
        Dim recorderIndex As Integer = 0
        Dim recorder As DiscRecorder
        For Each recorder In dm.DiscRecorders
            Dim recorderNode As TreeNode = recordersNode.Nodes.Add( _
             String.Format("Recorder {0}", ++recorderIndex))

            recorderNode.Nodes.Add( _
					String.Format("Vendor: {0}", recorder.Vendor))
			recorderNode.Nodes.Add( _
					String.Format("Product: {0}", recorder.Product))
			recorderNode.Nodes.Add( _
					String.Format("Revision: {0}", recorder.Revision))
			recorderNode.Nodes.Add( _
					String.Format("OSPath: {0}", recorder.OsPath))
			recorderNode.Nodes.Add( _
					String.Format("DriveLetter: {0}", recorder.DriveLetter))

            Dim mediaNode As TreeNode = recorderNode.Nodes.Add("Media")
            recorder.OpenExclusive()
            Dim media As MediaDetails = recorder.GetMediaDetails()
            If (media.MediaPresent) Then
                mediaNode.Nodes.Add( _
                    String.Format("Sessions: {0}", media.Sessions))
                mediaNode.Nodes.Add( _
                    String.Format("LastTrack: {0}", media.LastTrack))
                mediaNode.Nodes.Add( _
                    String.Format("StartAddress: {0}", media.StartAddress))
                mediaNode.Nodes.Add( _
                    String.Format("NextWritable: {0}", media.NextWritable))
                mediaNode.Nodes.Add( _
                    String.Format("FreeBlocks: {0}", media.FreeBlocks))
				mediaNode.Nodes.Add( _
					String.Format("MediaType: {0}", media.MediaType))
				mediaNode.Nodes.Add( _
					String.Format("Flags: {0}", media.MediaFlags))
            Else
                mediaNode.Nodes.Add("No media present")
            End If
            recorder.CloseExclusive()

            Dim props As DiscRecorderProperties = recorder.Properties
            Dim propertyNode As TreeNode = recorderNode.Nodes.Add("Properties")
            Dim prop As [Property]
            For Each prop In props
                propertyNode.Nodes.Add(String.Format("[{0}] {1} = {2}", _
                    prop.Id, prop.Name, prop.Value))
            Next
            props.Dispose()
            recordersNode.ExpandAll()

            dm.Dispose()

            Cursor.Current = Cursors.Default

        Next

    End Sub

End Class
