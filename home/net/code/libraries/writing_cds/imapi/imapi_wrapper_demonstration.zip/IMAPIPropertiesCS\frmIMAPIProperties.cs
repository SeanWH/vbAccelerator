using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using vbAccelerator.Components.ImapiWrapper;

namespace IMAPIProperties
{
	/// <summary>
	/// Summary description for frmIMAPIProperties.
	/// </summary>
	public class frmIMAPIProperties : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TreeView tvwRecorders;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmIMAPIProperties()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			Show();
			Refresh();

			DisplayRecorders();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmIMAPIProperties));
			this.tvwRecorders = new System.Windows.Forms.TreeView();
			this.SuspendLayout();
			// 
			// tvwRecorders
			// 
			this.tvwRecorders.ImageIndex = -1;
			this.tvwRecorders.Location = new System.Drawing.Point(12, 12);
			this.tvwRecorders.Name = "tvwRecorders";
			this.tvwRecorders.SelectedImageIndex = -1;
			this.tvwRecorders.Size = new System.Drawing.Size(396, 428);
			this.tvwRecorders.TabIndex = 1;
			// 
			// frmIMAPIProperties
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(424, 450);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.tvwRecorders});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmIMAPIProperties";
			this.Text = "IMAPI Properties Demonstration";
			this.Load += new System.EventHandler(this.frmIMAPIProperties_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmIMAPIProperties());
		}

		private void frmIMAPIProperties_Load(object sender, System.EventArgs e)
		{
		
		}

		protected override void OnResize(EventArgs e)
		{
			try
			{
				tvwRecorders.Size = new Size(
					ClientRectangle.Width - tvwRecorders.Location.X * 2,
					ClientRectangle.Height - tvwRecorders.Location.Y * 2);
			}
			catch (Exception)
			{
			}
		}

		private void DisplayRecorders()
		{
			Cursor.Current = Cursors.WaitCursor;

			tvwRecorders.Nodes.Clear();

			DiscMaster dm = new DiscMaster();
			SimpleDiscRecorder simpleRecorder = dm.SimpleDiscRecorder;
			
			TreeNode simpleNode = tvwRecorders.Nodes.Add("Simple CD Burner");
			if (simpleRecorder.HasRecordableDrive())
			{
				simpleNode.Nodes.Add(
					String.Format("Drive Letter: {0}", simpleRecorder.GetRecorderDriveLetter()));
				simpleNode.Nodes.Add(
					String.Format("Staging Area: {0}", simpleRecorder.GetBurnStagingAreaFolder(this.Handle)));
			}
			else
			{
				simpleNode.Nodes.Add("Not present");
			}
			simpleNode.Expand();

			TreeNode recordersNode = tvwRecorders.Nodes.Add("Recorders");						
			int recorderIndex = 0;
			foreach (DiscRecorder recorder in dm.DiscRecorders)
			{
				TreeNode recorderNode = recordersNode.Nodes.Add(
					String.Format("Recorder {0}", ++recorderIndex));
				recorderNode.Nodes.Add(
					String.Format("Vendor: {0}", recorder.Vendor));
				recorderNode.Nodes.Add(
					String.Format("Product: {0}", recorder.Product));
				recorderNode.Nodes.Add(
					String.Format("Revision: {0}", recorder.Revision));
				recorderNode.Nodes.Add(
					String.Format("OSPath: {0}", recorder.OsPath));
				recorderNode.Nodes.Add(
					String.Format("DriveLetter: {0}", recorder.DriveLetter));
				TreeNode mediaNode = recorderNode.Nodes.Add("Media");
				recorder.OpenExclusive();
				MediaDetails media = recorder.GetMediaDetails();
				if (media.MediaPresent)
				{
					mediaNode.Nodes.Add(
						String.Format("Sessions: {0}", media.Sessions));
					mediaNode.Nodes.Add(
						String.Format("LastTrack: {0}", media.LastTrack));
					mediaNode.Nodes.Add(
						String.Format("StartAddress: {0}", media.StartAddress));
					mediaNode.Nodes.Add(
						String.Format("NextWritable: {0}", media.NextWritable));
					mediaNode.Nodes.Add(
						String.Format("FreeBlocks: {0}", media.FreeBlocks));
					mediaNode.Nodes.Add(
						String.Format("MediaType: {0}", media.MediaType));
					mediaNode.Nodes.Add(
						String.Format("Flags: {0}", media.MediaFlags));
				}
				else
				{
					mediaNode.Nodes.Add("No media present");
				}
				recorder.CloseExclusive();
				using (DiscRecorderProperties props = recorder.Properties)
				{
					TreeNode propertyNode = recorderNode.Nodes.Add("Properties");
					foreach (Property prop in props)
					{
						propertyNode.Nodes.Add(String.Format("[{0}] {1} = {2}",
							prop.Id, prop.Name, prop.Value));
					}
				}
			}
			recordersNode.ExpandAll();

			dm.Dispose();

			Cursor.Current = Cursors.Default;

		}
	}
}
