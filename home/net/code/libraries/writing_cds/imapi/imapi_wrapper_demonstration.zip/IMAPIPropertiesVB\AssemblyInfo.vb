Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("vbAccelerator .NET CD Properties Demonstration")> 
<Assembly: AssemblyDescription("Shows how to read CD properties using the vbAccelerator IMAPIWrapper library.")> 
<Assembly: AssemblyCompany("Debug")> 
<Assembly: AssemblyProduct("vbAccelerator")> 
<Assembly: AssemblyCopyright("vbAccelerator .NET CD Properties Demonstration")> 
<Assembly: AssemblyTrademark("Copyright � 2004 Steve McMahon for vbAccelerator.com")> 
<Assembly: CLSCompliant(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("8460C968-BF23-4FDD-B034-27F9BA5631E4")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.0.0")> 
