using System;
using System.Data;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using vbAccelerator.Components.HotKey;

namespace HotKeyForm
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : vbAccelerator.Components.HotKey.HotKeyForm 
	{
		private System.Windows.Forms.Label lblLogoBack;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label lblInfo1;
		private System.Windows.Forms.Label lblInfo2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.lblLogoBack = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.lblInfo1 = new System.Windows.Forms.Label();
			this.lblInfo2 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// lblLogoBack
			// 
			this.lblLogoBack.BackColor = System.Drawing.Color.Black;
			this.lblLogoBack.Location = new System.Drawing.Point(8, 8);
			this.lblLogoBack.Name = "lblLogoBack";
			this.lblLogoBack.Size = new System.Drawing.Size(280, 32);
			this.lblLogoBack.TabIndex = 0;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Black;
			this.label2.Image = ((System.Drawing.Bitmap)(resources.GetObject("label2.Image")));
			this.label2.Location = new System.Drawing.Point(12, 12);
			this.label2.Name = "label2";
			this.label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.label2.Size = new System.Drawing.Size(92, 24);
			this.label2.TabIndex = 1;
			// 
			// lblInfo1
			// 
			this.lblInfo1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblInfo1.Location = new System.Drawing.Point(8, 52);
			this.lblInfo1.Name = "lblInfo1";
			this.lblInfo1.Size = new System.Drawing.Size(276, 116);
			this.lblInfo1.TabIndex = 2;
			this.lblInfo1.Text = @"A simple demonstration of the HotKeyForm component.  This component extends a System.Windows.Forms.Form to allow you to register and intercept system wide HotKeys.  When the HotKey is pressed, a HotKeyPressed event is raised.  In this demo all that is done is to activate the window, however you are free to perform whatever action you want.";
			// 
			// lblInfo2
			// 
			this.lblInfo2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblInfo2.Location = new System.Drawing.Point(8, 192);
			this.lblInfo2.Name = "lblInfo2";
			this.lblInfo2.Size = new System.Drawing.Size(276, 36);
			this.lblInfo2.TabIndex = 3;
			this.lblInfo2.Text = "In this case the HotKey has been set to Ctrl+Shift+Up";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(292, 242);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lblInfo2,
																		  this.lblInfo1,
																		  this.label2,
																		  this.lblLogoBack});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "Form1";
			this.Text = ".NET HotKey Form Demonstration";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			// add event handler for HotKeyPressed:
			this.HotKeyPressed += new HotKeyPressedEventHandler(hotKey_Pressed);

			// Add a HotKey for Ctrl+Shift+up:
			HotKey hotKey = new HotKey("MyHotKey", Keys.Up, 
				HotKey.HotKeyModifiers.MOD_CONTROL | HotKey.HotKeyModifiers.MOD_SHIFT);
			HotKeys.Add(hotKey);

		}

		private void hotKey_Pressed(object sender, HotKeyPressedEventArgs e)
		{
			// ensure form is shown:
			this.RestoreAndActivate();

			// show a messagebox:
			MessageBox.Show(this,
				String.Format("HotKey Pressed:\nName: {0}\nKeyCode: {1}\nModifiers: {2}", 
					e.HotKey.Name, 
					e.HotKey.KeyCode.ToString(), 
					e.HotKey.Modifiers.ToString()),
				".NET Hot Key Demonstration", 
				MessageBoxButtons.OK, 
				MessageBoxIcon.Information);
		}

	}
}
