Imports HotKeyFormVB.vbAccelerator.Components.HotKey

Public Class Form1
    Inherits vbAccelerator.Components.HotKey.HotKeyForm

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lblInfo2 As System.Windows.Forms.Label
    Friend WithEvents lblInfo1 As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents lblLogoBack As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.lblInfo2 = New System.Windows.Forms.Label()
        Me.lblInfo1 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.lblLogoBack = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblInfo2
        '
        Me.lblInfo2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInfo2.Location = New System.Drawing.Point(6, 196)
        Me.lblInfo2.Name = "lblInfo2"
        Me.lblInfo2.Size = New System.Drawing.Size(276, 36)
        Me.lblInfo2.TabIndex = 7
        Me.lblInfo2.Text = "In this case the HotKey has been set to Ctrl+Shift+Up"
        '
        'lblInfo1
        '
        Me.lblInfo1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInfo1.Location = New System.Drawing.Point(6, 56)
        Me.lblInfo1.Name = "lblInfo1"
        Me.lblInfo1.Size = New System.Drawing.Size(276, 116)
        Me.lblInfo1.TabIndex = 6
        Me.lblInfo1.Text = "A simple demonstration of the HotKeyForm component.  This component extends a Sys" & _
        "tem.Windows.Forms.Form to allow you to register and intercept system wide HotKey" & _
        "s.  When the HotKey is pressed, a HotKeyPressed event is raised.  In this demo a" & _
        "ll that is done is to activate the window, however you are free to perform whate" & _
        "ver action you want."
        '
        'label2
        '
        Me.label2.BackColor = System.Drawing.Color.Black
        Me.label2.Image = CType(resources.GetObject("label2.Image"), System.Drawing.Bitmap)
        Me.label2.Location = New System.Drawing.Point(10, 16)
        Me.label2.Name = "label2"
        Me.label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.label2.Size = New System.Drawing.Size(92, 24)
        Me.label2.TabIndex = 5
        '
        'lblLogoBack
        '
        Me.lblLogoBack.BackColor = System.Drawing.Color.Black
        Me.lblLogoBack.Location = New System.Drawing.Point(6, 12)
        Me.lblLogoBack.Name = "lblLogoBack"
        Me.lblLogoBack.Size = New System.Drawing.Size(280, 32)
        Me.lblLogoBack.TabIndex = 4
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 242)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblInfo2, Me.lblInfo1, Me.label2, Me.lblLogoBack})
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = ".NET HotKey Form Demonstration"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' add an event handler for hot key pressed (or could just use Handles)
        AddHandler Me.HotKeyPressed, AddressOf hotKey_Pressed

        ' set the hotkey:
        Dim htk As HotKey = New HotKey("My HotKey", Keys.Up, HotKey.HotKeyModifiers.MOD_CONTROL Or HotKey.HotKeyModifiers.MOD_SHIFT)
        Me.HotKeys.Add(htk)

    End Sub

    Private Sub Form1_Closed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        ' remove the dynamic event handler
        RemoveHandler Me.HotKeyPressed, AddressOf hotKey_Pressed
    End Sub

    Private Sub hotKey_Pressed(ByVal sender As System.Object, ByVal e As HotKeyPressedEventArgs)
        ' ensure form is shown:
        Me.RestoreAndActivate()

        'show a messagebox:
        MessageBox.Show(Me, _
                  String.Format("HotKey Pressed:" + vbCrLf + "Name: {0} " + vbCrLf + "KeyCode: {1}" + vbCrLf + "Modifiers: {2}", _
                      e.HotKey.Name, _
                      e.HotKey.KeyCode.ToString(), _
                      e.HotKey.Modifiers.ToString()), _
                          ".NET Hot Key Demonstration", _
                          MessageBoxButtons.OK, _
                          MessageBoxIcon.Information)
    End Sub

End Class
