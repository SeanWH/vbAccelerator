Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("vbAccelerator HotKeyForm Demonstration")> 
<Assembly: AssemblyDescription("Demonstrates extending System.Windows.Forms.Form to register and intercept system-wide HotKeys")> 
<Assembly: AssemblyCompany("vbAccelerator")> 
<Assembly: AssemblyProduct("vbAccelerator HotKeyForm Demonstration")> 
<Assembly: AssemblyCopyright("Copyright 2002 Steve McMahon for vbAccelerator.com")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: CLSCompliant(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("16620F2F-9C83-4D94-850E-4CD613DAF412")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.*")> 
