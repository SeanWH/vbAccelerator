using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Security.Permissions;
using System.Windows.Forms;

using vbAccelerator.Components.Clipboard;

[assembly:UIPermissionAttribute(SecurityAction.RequestMinimum, Clipboard=UIPermissionClipboard.AllClipboard)]
[assembly:UIPermissionAttribute(SecurityAction.RequestMinimum, Window=UIPermissionWindow.AllWindows)]

namespace ClipNotifier
{
	/// <summary>
	/// A form which demonstrates receiving change notifications
	/// from the Clipboard.
	/// </summary>
	public class frmClipboardChangeDemo : System.Windows.Forms.Form
	{
		private ClipboardChangeNotifier clipChange = null;
		private System.Windows.Forms.ListBox lstContents;
		private System.Windows.Forms.Label lblAvailableFormats;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary>
		/// Constructs a new instance of this clipboard change
		/// notification demonstration form.
		/// </summary>
		public frmClipboardChangeDemo()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmClipboardChangeDemo));
			this.lstContents = new System.Windows.Forms.ListBox();
			this.lblAvailableFormats = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// lstContents
			// 
			this.lstContents.Location = new System.Drawing.Point(8, 28);
			this.lstContents.Name = "lstContents";
			this.lstContents.Size = new System.Drawing.Size(276, 225);
			this.lstContents.TabIndex = 0;
			// 
			// lblAvailableFormats
			// 
			this.lblAvailableFormats.Location = new System.Drawing.Point(8, 4);
			this.lblAvailableFormats.Name = "lblAvailableFormats";
			this.lblAvailableFormats.Size = new System.Drawing.Size(276, 20);
			this.lblAvailableFormats.TabIndex = 1;
			this.lblAvailableFormats.Text = "Available Clipboard Formats:";
			// 
			// frmClipboardChangeDemo
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lblAvailableFormats,
																		  this.lstContents});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmClipboardChangeDemo";
			this.Text = "vbAccelerator Clipboard Change Notification";
			this.Load += new System.EventHandler(this.frmClipboardChangeDemo_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmClipboardChangeDemo());
		}

		private void frmClipboardChangeDemo_Load(object sender, System.EventArgs e)
		{
			this.clipChange = new ClipboardChangeNotifier();
			this.clipChange.ClipboardChanged += new EventHandler(clipChange_ClipboardChanged);
			this.clipChange.AssignHandle(this.Handle);
			this.clipChange.Install();
		}

		/*
		 * This is a way of ensuring that you're always installed
		 * even when the handle changes.
		protected override void OnHandleCreated(EventArgs e)
		{
			base.OnHandleCreated(e);
			if (this.clipChange != null)
			{
				this.clipChange.AssignHandle(this.Handle);
				this.clipChange.Install();
			}
		}
		*/

		private void clipChange_ClipboardChanged(object sender, EventArgs e)
		{
			Application.DoEvents();
			showFormats();
		}

		private void showFormats()
		{
			this.lstContents.Items.Clear();
			lstContents.Items.Add("Clipboard Changed at " + DateTime.Now);
			IDataObject dto = Clipboard.GetDataObject();
			foreach (string fmt in dto.GetFormats())
			{
				this.lstContents.Items.Add(fmt);
			}
		}
	}
}
