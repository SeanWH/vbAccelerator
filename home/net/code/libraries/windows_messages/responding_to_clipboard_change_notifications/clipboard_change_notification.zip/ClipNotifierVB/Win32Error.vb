Namespace vbAccelerator.Components.Win32

    ''' <summary>
    ''' Helper method for returning the description associated with a 
    ''' <see cref="System.Runtime.InteropServices.Marshal.GetLastWin32Error"/>
    ''' error code.
    ''' </summary>
    Public Class Win32Error

        Private Const FORMAT_MESSAGE_ALLOCATE_BUFFER As Integer = &H100
        Private Const FORMAT_MESSAGE_ARGUMENT_ARRAY As Integer = &H2000
        Private Const FORMAT_MESSAGE_FROM_HMODULE As Integer = &H800
        Private Const FORMAT_MESSAGE_FROM_STRING As Integer = &H400
        Private Const FORMAT_MESSAGE_FROM_SYSTEM As Integer = &H1000
        Private Const FORMAT_MESSAGE_IGNORE_INSERTS As Integer = &H200
        Private Const FORMAT_MESSAGE_MAX_WIDTH_MASK As Integer = &HFF

        Private Declare Auto Function FormatMessage Lib "kernel32" ( _
            ByVal dwFlags As Integer, _
            ByVal lpSource As IntPtr, _
            ByVal dwMessageId As Integer, _
            ByVal dwLanguageId As Integer, _
            <System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPTStr)> _
            ByVal lpBuffer As System.Text.StringBuilder, _
            ByVal nSize As Integer, _
            ByVal Arguments As IntPtr) As Integer

        ''' <summary>
        ''' Returns a string containing the error message for a Win32 API error code.
        ''' </summary>
        ''' <param name="lastWin32Error">Win32 Error</param>
        ''' <returns>Error Message associated with Win32 Error</returns>
        Public Shared Function ErrorMessage( _
                ByVal lastWin32Error As Integer _
            ) As String
            Dim msg As System.Text.StringBuilder = New System.Text.StringBuilder(256, 256)
			dim size as Integer = FormatMessage( _
				FORMAT_MESSAGE_FROM_SYSTEM or FORMAT_MESSAGE_IGNORE_INSERTS, _
				IntPtr.Zero, lastWin32Error, 0, _
				msg, msg.MaxCapacity, IntPtr.Zero)
            Return msg.ToString()
        End Function

        ''' <summary>
        ''' Private constructor - static methods.
        ''' </summary>
        Private Sub New()
            ' intentionally blank
        End Sub
    End Class

End Namespace
