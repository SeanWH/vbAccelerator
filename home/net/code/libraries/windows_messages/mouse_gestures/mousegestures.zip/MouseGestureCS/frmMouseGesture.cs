using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;

using vbAccelerator.Components.Win32;

namespace MouseGestureCS
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmMouseGesture : System.Windows.Forms.Form
	{
		private Image highlightImage = null;
		private Point highlightCoords;
		private String gestureText = "";
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label lblGestureName;
		private System.Windows.Forms.Timer tmrGestureClear;
		private AxSHDocVw.AxWebBrowser axWebBrowser1;
		private System.Windows.Forms.Label lblInfo;
		private System.ComponentModel.IContainer components;

		public frmMouseGesture()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();


			MouseGestureFilter mgf = new MouseGestureFilter();
			Application.AddMessageFilter(mgf);
			mgf.MouseGesture += new MouseGestureEventHandler(frmMouseGesture_MouseGesture);

			pictureBox1.Paint += new PaintEventHandler(pictureBox1_Paint);
			
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMouseGesture));
			this.lblGestureName = new System.Windows.Forms.Label();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.tmrGestureClear = new System.Windows.Forms.Timer(this.components);
			this.lblInfo = new System.Windows.Forms.Label();
			this.axWebBrowser1 = new AxSHDocVw.AxWebBrowser();
			((System.ComponentModel.ISupportInitialize)(this.axWebBrowser1)).BeginInit();
			this.SuspendLayout();
			// 
			// lblGestureName
			// 
			this.lblGestureName.Location = new System.Drawing.Point(124, 92);
			this.lblGestureName.Name = "lblGestureName";
			this.lblGestureName.Size = new System.Drawing.Size(152, 12);
			this.lblGestureName.TabIndex = 0;
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Bitmap)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(120, 108);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(156, 94);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 1;
			this.pictureBox1.TabStop = false;
			// 
			// tmrGestureClear
			// 
			this.tmrGestureClear.Interval = 600;
			this.tmrGestureClear.Tick += new System.EventHandler(this.tmrGestureClear_Tick);
			// 
			// lblInfo
			// 
			this.lblInfo.Location = new System.Drawing.Point(8, 4);
			this.lblInfo.Name = "lblInfo";
			this.lblInfo.Size = new System.Drawing.Size(408, 76);
			this.lblInfo.TabIndex = 2;
			this.lblInfo.Text = @"This form demonstrates the MouseGestureFilter class.  Mouse Gestures are performed with the right mouse button held down and are shown in the diagram below.  When you perform a gesture, it will be highlighted briefly.  In a real application, gestures are typically used to close windows and navigate.   A gesture is recognised over any form or control in the application.";
			// 
			// axWebBrowser1
			// 
			this.axWebBrowser1.Enabled = true;
			this.axWebBrowser1.Location = new System.Drawing.Point(8, 220);
			this.axWebBrowser1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWebBrowser1.OcxState")));
			this.axWebBrowser1.Size = new System.Drawing.Size(408, 248);
			this.axWebBrowser1.TabIndex = 3;
			// 
			// frmMouseGesture
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(424, 478);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.axWebBrowser1,
																		  this.lblInfo,
																		  this.pictureBox1,
																		  this.lblGestureName});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "frmMouseGesture";
			this.Text = "vbAccelerator Mouse Gestures Demonstration";
			this.Load += new System.EventHandler(this.frmMouseGesture_Load);
			((System.ComponentModel.ISupportInitialize)(this.axWebBrowser1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmMouseGesture());
		}

		private void frmMouseGesture_MouseGesture(object sender, MouseGestureEventArgs args)
		{
			HighlightGestureType(args.GestureType);
			args.AcceptGesture = true;
		}

		private void HighlightGestureType(MouseGestureTypes gesture)
		{
			if (tmrGestureClear.Enabled)
			{
				gestureText = "";
				highlightImage = null;
				tmrGestureClear.Enabled = false;
				pictureBox1.Update();
			}
			gestureText = gesture.ToString();

			Size highlightSize = new Size(30, 30);
			switch (gesture)
			{
				case MouseGestureTypes.NorthGesture:
					highlightCoords = new Point(1, 32);
					break;
				case MouseGestureTypes.SouthGesture:
					highlightCoords = new Point(1, 63);
					break;
				case MouseGestureTypes.EastGesture:
					highlightCoords = new Point(94, 1);
					highlightSize.Width = 61;
					break;
				case MouseGestureTypes.WestGesture:
					highlightCoords = new Point(32, 1);
					highlightSize.Width = 61;
					break;

				case MouseGestureTypes.NorthThenWestGesture:
					highlightCoords = new Point(32, 32);
					break;
				case MouseGestureTypes.WestThenNorthGesture:
					highlightCoords = new Point(63, 32);
					break;
				case MouseGestureTypes.EastThenNorthGesture:
					highlightCoords = new Point(94, 32);
					break;
				case MouseGestureTypes.NorthThenEastGesture:
					highlightCoords = new Point(125, 32);
					break;


				case MouseGestureTypes.SouthThenWestGesture:
					highlightCoords = new Point(32, 63);
					break;
				case MouseGestureTypes.WestThenSouthGesture:
					highlightCoords = new Point(63, 63);
					break;
				case MouseGestureTypes.EastThenSouthGesture:
					highlightCoords = new Point(94, 63);
					break;
				case MouseGestureTypes.SouthThenEastGesture:
					highlightCoords = new Point(125, 63);
					break;
			}

			highlightImage = new Bitmap(pictureBox1.Image, highlightSize);
			Graphics gfx = Graphics.FromImage(highlightImage);
			ImageAttributes imageAttr = new ImageAttributes();
			imageAttr.SetGamma(4F);
			gfx.DrawImage(pictureBox1.Image, 
				new Rectangle(new Point(0, 0), highlightSize), 
				highlightCoords.X, highlightCoords.Y, highlightSize.Width, highlightSize.Height,
				GraphicsUnit.Pixel, imageAttr);
			imageAttr.Dispose();
			Brush br = new SolidBrush(Color.FromArgb(64, Color.FromKnownColor(KnownColor.Highlight)));
			gfx.FillRectangle(br, 0, 0, highlightSize.Width, highlightSize.Height);
			br.Dispose();
			gfx.Dispose();
			
			lblGestureName.Text = gestureText;
			pictureBox1.Invalidate();

			tmrGestureClear.Enabled = true;
		}

		private void pictureBox1_Paint(object sender, PaintEventArgs p)
		{
			if (highlightImage != null)
			{
				p.Graphics.DrawImageUnscaled(highlightImage, highlightCoords.X, highlightCoords.Y);
			}
		}

		private void tmrGestureClear_Tick(object sender, System.EventArgs e)
		{
			lblGestureName.Text = "";
			highlightImage = null;
			pictureBox1.Invalidate();
		}

		private void frmMouseGesture_Load(object sender, System.EventArgs e)
		{
			string urlString = "http://vbaccelerator.com/";
			object url = urlString;
			object flags, targetFrame, postData, headers;
			flags = targetFrame = postData = headers = null;
			axWebBrowser1.Navigate2(ref url, ref flags, ref targetFrame, ref postData, ref headers);
		}
	}
}
