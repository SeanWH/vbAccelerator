Public Class frmMouseGesture
    Inherits System.Windows.Forms.Form

    Private highlightImage As Image = Nothing
    Private highlightCoords As Point
    Private gestureText As String = ""
    Private WithEvents mouseGestureFilter As vbAccelerator.Components.Win32.MouseGestureFilter


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents tmrGestureClear As System.Windows.Forms.Timer
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents pictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents lblGestureName As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMouseGesture))
        Me.tmrGestureClear = New System.Windows.Forms.Timer(Me.components)
        Me.label1 = New System.Windows.Forms.Label()
        Me.pictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblGestureName = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'tmrGestureClear
        '
        Me.tmrGestureClear.Interval = 600
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(4, 4)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(408, 76)
        Me.label1.TabIndex = 5
        Me.label1.Text = "This form demonstrates the MouseGestureFilter class.  Mouse Gestures are performe" & _
        "d with the right mouse button held down and are shown in the diagram below.  Whe" & _
        "n you perform a gesture, it will be highlighted briefly.  In a real application," & _
        " gestures are typically used to close windows and navigate.   A gesture is recog" & _
        "nised over any form or control in the application."
        '
        'pictureBox1
        '
        Me.pictureBox1.Image = CType(resources.GetObject("pictureBox1.Image"), System.Drawing.Bitmap)
        Me.pictureBox1.Location = New System.Drawing.Point(116, 108)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(156, 94)
        Me.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pictureBox1.TabIndex = 4
        Me.pictureBox1.TabStop = False
        '
        'lblGestureName
        '
        Me.lblGestureName.Location = New System.Drawing.Point(120, 92)
        Me.lblGestureName.Name = "lblGestureName"
        Me.lblGestureName.Size = New System.Drawing.Size(152, 12)
        Me.lblGestureName.TabIndex = 3
        '
        'frmMouseGesture
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(420, 406)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.pictureBox1, Me.lblGestureName, Me.label1})
        Me.Name = "frmMouseGesture"
        Me.Text = "vbAccelerator Mouse Gesture Demonstration"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub pictureBox1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles pictureBox1.Paint
        If Not (highlightImage Is Nothing) Then
            e.Graphics.DrawImageUnscaled(highlightImage, highlightCoords.X, highlightCoords.Y)
        End If
    End Sub

    Private Sub frmMouseGesture_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        mouseGestureFilter = New vbAccelerator.Components.Win32.MouseGestureFilter()
        Application.AddMessageFilter(mouseGestureFilter)
    End Sub

    Private Sub mouseGestureFilter_MouseGesture(ByVal sender As Object, ByVal args As MouseGesturesVB.vbAccelerator.Components.Win32.MouseGestureEventArgs) Handles mouseGestureFilter.MouseGesture
        HighlightGestureType(args.GestureType)
        args.AcceptGesture = True
    End Sub

    Private Sub HighlightGestureType(ByVal gesture As vbAccelerator.Components.Win32.MouseGestureTypes)

        If (tmrGestureClear.Enabled) Then
            gestureText = ""
            highlightImage = Nothing
            tmrGestureClear.Enabled = False
            pictureBox1.Update()
        End If

        gestureText = gesture.ToString()

        Dim highlightSize As Size = New Size(30, 30)
        Select Case (gesture)
            Case vbAccelerator.Components.Win32.MouseGestureTypes.NorthGesture
                highlightCoords = New Point(1, 32)
            Case vbAccelerator.Components.Win32.MouseGestureTypes.SouthGesture
                highlightCoords = New Point(1, 63)
            Case vbAccelerator.Components.Win32.MouseGestureTypes.EastGesture
                highlightCoords = New Point(94, 1)
                highlightSize.Width = 61
            Case vbAccelerator.Components.Win32.MouseGestureTypes.WestGesture
                highlightCoords = New Point(32, 1)
                highlightSize.Width = 61

            Case vbAccelerator.Components.Win32.MouseGestureTypes.NorthThenWestGesture
                highlightCoords = New Point(32, 32)
            Case vbAccelerator.Components.Win32.MouseGestureTypes.WestThenNorthGesture
                highlightCoords = New Point(63, 32)
            Case vbAccelerator.Components.Win32.MouseGestureTypes.EastThenNorthGesture
                highlightCoords = New Point(94, 32)
            Case vbAccelerator.Components.Win32.MouseGestureTypes.NorthThenEastGesture
                highlightCoords = New Point(125, 32)

            Case vbAccelerator.Components.Win32.MouseGestureTypes.SouthThenWestGesture
                highlightCoords = New Point(32, 63)
            Case vbAccelerator.Components.Win32.MouseGestureTypes.WestThenSouthGesture
                highlightCoords = New Point(63, 63)
            Case vbAccelerator.Components.Win32.MouseGestureTypes.EastThenSouthGesture
                highlightCoords = New Point(94, 63)
            Case vbAccelerator.Components.Win32.MouseGestureTypes.SouthThenEastGesture
                highlightCoords = New Point(125, 63)
        End Select

        highlightImage = New Bitmap(pictureBox1.Image, highlightSize)
        Dim gfx As Graphics = Graphics.FromImage(highlightImage)
        Dim imageAttr As System.Drawing.Imaging.ImageAttributes = New System.Drawing.Imaging.ImageAttributes()
        imageAttr.SetGamma(4.0)
        gfx.DrawImage(pictureBox1.Image, _
          New Rectangle(New Point(0, 0), highlightSize), _
          highlightCoords.X, highlightCoords.Y, highlightSize.Width, highlightSize.Height, _
          GraphicsUnit.Pixel, imageAttr)
        imageAttr.Dispose()
        Dim br As Brush = New SolidBrush(Color.FromArgb(64, Color.FromKnownColor(KnownColor.Highlight)))
        gfx.FillRectangle(br, 0, 0, highlightSize.Width, highlightSize.Height)
        br.Dispose()
        gfx.Dispose()

        lblGestureName.Text = gestureText
        pictureBox1.Invalidate()

        tmrGestureClear.Enabled = True
    End Sub


    Private Sub tmrGestureClear_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles tmrGestureClear.Tick
        lblGestureName.Text = ""
        highlightImage = Nothing
        pictureBox1.Invalidate()
    End Sub
End Class
