Namespace SimpleInterprocessCommunications

    ''' <summary>
    ''' A simple data object to be passed between instances
    ''' using the <see cref="CopyData"/> class.  This object
    ''' uses the default serialization implementation added by 
    ''' the Framework when the <see cref="Serializable"/>
    ''' attribute is used.
    ''' </summary>
    <Serializable()> _
    Public Class DataClassExample1

        ''' <summary>
        ''' The CommandLine.
        ''' </summary>
        Public CommandLine As String = ""
        ''' <summary>
        ''' Timestamp associated with the CommandLine
        ''' </summary>
        Public TimeStamp As DateTime = DateTime.Now


        ''' <summary>
        ''' Constructs a new instance of this class with the
        ''' specified CommandLine and Timestamp.
        ''' </summary>
        ''' <param name="commandLine">CommandLine</param>
        ''' <param name="timeStamp">Timestamp</param>
        Public Sub New(ByVal commandLineIn As String, ByVal timeStampIn As DateTime)
            Me.CommandLine = commandLineIn
            Me.TimeStamp = timeStampIn
        End Sub

    End Class

End Namespace
