Namespace SimpleInterprocessCommunications
    Public Class frmInterProcessComms
        Inherits System.Windows.Forms.Form

        ''' <summary>
        ''' The CopyData class used for message sending.
        ''' </summary>
        Private WithEvents copyData As vbAccelerator.Components.Win32.CopyData = Nothing


#Region " Windows Form Designer generated code "

        Public Sub New()
            MyBase.New()

            'This call is required by the Windows Form Designer.
            InitializeComponent()

            'Add any initialization after the InitializeComponent() call

        End Sub

        'Form overrides dispose to clean up the component list.
        Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing Then
                If Not (components Is Nothing) Then
                    components.Dispose()
                End If
            End If
            MyBase.Dispose(disposing)
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        Friend WithEvents grpReceive As System.Windows.Forms.GroupBox
        Friend WithEvents btnClear As System.Windows.Forms.Button
        Friend WithEvents lstReceived As System.Windows.Forms.ListBox
        Friend WithEvents grpSend As System.Windows.Forms.GroupBox
        Friend WithEvents lblRecipients As System.Windows.Forms.Label
        Friend WithEvents cboChannels As System.Windows.Forms.ComboBox
        Friend WithEvents txtToSend As System.Windows.Forms.TextBox
        Friend WithEvents btnSend As System.Windows.Forms.Button
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
            Me.grpReceive = New System.Windows.Forms.GroupBox()
            Me.btnClear = New System.Windows.Forms.Button()
            Me.lstReceived = New System.Windows.Forms.ListBox()
            Me.grpSend = New System.Windows.Forms.GroupBox()
            Me.lblRecipients = New System.Windows.Forms.Label()
            Me.cboChannels = New System.Windows.Forms.ComboBox()
            Me.txtToSend = New System.Windows.Forms.TextBox()
            Me.btnSend = New System.Windows.Forms.Button()
            Me.grpReceive.SuspendLayout()
            Me.grpSend.SuspendLayout()
            Me.SuspendLayout()
            '
            'grpReceive
            '
            Me.grpReceive.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnClear, Me.lstReceived})
            Me.grpReceive.Location = New System.Drawing.Point(4, 108)
            Me.grpReceive.Name = "grpReceive"
            Me.grpReceive.Size = New System.Drawing.Size(288, 176)
            Me.grpReceive.TabIndex = 7
            Me.grpReceive.TabStop = False
            Me.grpReceive.Text = "Received Data"
            '
            'btnClear
            '
            Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.System
            Me.btnClear.Location = New System.Drawing.Point(204, 20)
            Me.btnClear.Name = "btnClear"
            Me.btnClear.TabIndex = 5
            Me.btnClear.Text = "&Clear"
            '
            'lstReceived
            '
            Me.lstReceived.Location = New System.Drawing.Point(8, 20)
            Me.lstReceived.Name = "lstReceived"
            Me.lstReceived.Size = New System.Drawing.Size(192, 147)
            Me.lstReceived.TabIndex = 3
            '
            'grpSend
            '
            Me.grpSend.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblRecipients, Me.cboChannels, Me.txtToSend, Me.btnSend})
            Me.grpSend.FlatStyle = System.Windows.Forms.FlatStyle.System
            Me.grpSend.Location = New System.Drawing.Point(4, 4)
            Me.grpSend.Name = "grpSend"
            Me.grpSend.Size = New System.Drawing.Size(292, 100)
            Me.grpSend.TabIndex = 6
            Me.grpSend.TabStop = False
            Me.grpSend.Text = "Send Data"
            '
            'lblRecipients
            '
            Me.lblRecipients.Location = New System.Drawing.Point(208, 48)
            Me.lblRecipients.Name = "lblRecipients"
            Me.lblRecipients.Size = New System.Drawing.Size(76, 16)
            Me.lblRecipients.TabIndex = 7
            '
            'cboChannels
            '
            Me.cboChannels.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.cboChannels.Location = New System.Drawing.Point(8, 20)
            Me.cboChannels.Name = "cboChannels"
            Me.cboChannels.Size = New System.Drawing.Size(192, 21)
            Me.cboChannels.TabIndex = 6
            '
            'txtToSend
            '
            Me.txtToSend.Location = New System.Drawing.Point(8, 44)
            Me.txtToSend.Multiline = True
            Me.txtToSend.Name = "txtToSend"
            Me.txtToSend.Size = New System.Drawing.Size(192, 40)
            Me.txtToSend.TabIndex = 5
            Me.txtToSend.Text = "This is the data to send on the selected channel."
            '
            'btnSend
            '
            Me.btnSend.FlatStyle = System.Windows.Forms.FlatStyle.System
            Me.btnSend.Location = New System.Drawing.Point(208, 20)
            Me.btnSend.Name = "btnSend"
            Me.btnSend.TabIndex = 4
            Me.btnSend.Text = "&Send"
            '
            'frmInterProcessComms
            '
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.ClientSize = New System.Drawing.Size(300, 290)
            Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.grpReceive, Me.grpSend})
            Me.Name = "frmInterProcessComms"
            Me.Text = "Form1"
            Me.grpReceive.ResumeLayout(False)
            Me.grpSend.ResumeLayout(False)
            Me.ResumeLayout(False)

        End Sub

#End Region

        Private Sub frmInterProcessComms_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
            ' Create a new instance of the class:
            copyData = New vbAccelerator.Components.Win32.CopyData()

            ' Assign the handle:
            copyData.AssignHandle(Me.Handle)

            ' Create the named channels to send and receive on.  The name
            ' is arbitary; it can be anything you want.
            copyData.Channels.Add("DataClass1")
            copyData.Channels.Add("DataClass2")

            ' Display the channels in the combo box and pick
            ' the first:
            Dim channel As vbAccelerator.Components.Win32.CopyDataChannel
            For Each channel In copyData.Channels
                cboChannels.Items.Add(channel.ChannelName)
            Next
            cboChannels.SelectedIndex = 0

        End Sub

        Private Sub copyData_DataReceived(ByVal sender As Object, ByVal e As SimpleInterprocessCommunicationsVB.vbAccelerator.Components.Win32.DataReceivedEventArgs) Handles copyData.DataReceived
            ' Display the data in the logging list box:
            If (e.ChannelName.Equals("DataClass1")) Then
                Dim data As DataClassExample1 = e.Data
                lstReceived.Items.Add( _
                 String.Format("{0} : {1}", e.ChannelName, data.CommandLine))

            Else
                Dim data As DataClassExample2 = e.Data
                lstReceived.Items.Add( _
                 String.Format("{0} : {1}", e.ChannelName, data.CommandLine))
            End If
            lstReceived.SelectedIndex = lstReceived.Items.Count - 1

        End Sub

        Private Sub btnSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSend.Click
            ' Pick the channel name to send on:
            Dim channelName As String = cboChannels.Items(cboChannels.SelectedIndex)
            Dim recipients As Integer = 0
            ' Create some demonstration data and send it on the named
            ' channel:
            If (channelName.Equals("DataClass1")) Then
                Dim data As DataClassExample1 = New DataClassExample1(txtToSend.Text, DateTime.Now)
                recipients = copyData.Channels(channelName).Send(data)
            Else
                Dim data As DataClassExample2 = New DataClassExample2(txtToSend.Text, DateTime.Now)
                recipients = copyData.Channels(channelName).Send(data)
            End If
            ' Display how many other instances receieved the message:
            lblRecipients.Text = String.Format("{0} recipients", recipients)

        End Sub

        Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
            lstReceived.Items.Clear()
        End Sub
    End Class
End Namespace
