Namespace SimpleInterprocessCommunications

    ''' <summary>
    ''' A slightly more sophisticated DataClassExample
    ''' which performs customised serialization and 
    ''' deserialization of the fields.  Doing custom
    ''' de/serialization gives you more control over how
    ''' the data is manipulated..
    ''' </summary>
    <Serializable()> _
    Public Class DataClassExample2
        Implements System.Runtime.Serialization.ISerializable

        Private m_commandLine As String = ""
        Private m_timeStamp As DateTime = DateTime.Now

        ''' <summary>
        ''' Constructs a new instance of this class with
        ''' the specified command line and timestamp.
        ''' </summary>
        ''' <param name="commandLine">Command Line</param>
        ''' <param name="timeStamp">Timestamp</param>
        Public Sub New(ByVal commandLine As String, ByVal timeStamp As DateTime)
            m_commandLine = commandLine
            m_timeStamp = timeStamp
        End Sub

        ''' <summary>
        ''' Serialization constructor
        ''' </summary>
        ''' <param name="info">The object that holds the serialized object data.</param>
        ''' <param name="context">The contextual information about the source or destination.</param>
        Public Sub New( _
            ByVal info As System.Runtime.Serialization.SerializationInfo, _
            ByVal context As System.Runtime.Serialization.StreamingContext _
            )
            m_commandLine = info.GetString("CommandLine")
            m_timeStamp = info.GetDateTime("TimeStamp")
        End Sub

        ''' <summary>
        ''' Provides a customised <see cref="GetObjectData"/>
        ''' implementation for serializing the contents of the class.
        ''' </summary>
        ''' <param name="info">The <see cref="System.Runtime.Serialization.SerializationInfo" /> 
        ''' into which the object is serialized.</param>
        ''' <param name="context">The source and destination of the serialization.</param>
        Public Sub GetObjectData( _
            ByVal info As System.Runtime.Serialization.SerializationInfo, _
            ByVal context As System.Runtime.Serialization.StreamingContext _
            ) Implements System.Runtime.Serialization.ISerializable.GetObjectData

            info.AddValue("CommandLine", m_commandLine)
            info.AddValue("TimeStamp", m_timeStamp)
        End Sub

        ''' <summary>
        ''' Gets the <c>CommandLine</c> value stored in this class.
        ''' </summary>
        Public ReadOnly Property CommandLine() As String
            Get
                Return m_commandLine
            End Get
        End Property

        ''' <summary>
        ''' Gets the <c>Timestamp</c> value stored in this class.
        ''' </summary>
        Public ReadOnly Property TimeStamp() As DateTime
            Get
                Return m_timeStamp
            End Get
        End Property
    End Class

End Namespace
