using System;
using System.Runtime.Serialization;

namespace SimpleInterprocessCommunications
{
	/// <summary>
	/// A slightly more sophisticated DataClassExample
	/// which performs customised serialization and 
	/// deserialization of the fields.  Doing custom
	/// de/serialization gives you more control over how
	/// the data is manipulated..
	/// </summary>
	[Serializable()]
	public class DataClassExample2 : ISerializable
	{
		private string commandLine = "";
		private DateTime timeStamp = DateTime.Now;

		/// <summary>
		/// Constructs a new instance of this class with
		/// the specified command line and timestamp.
		/// </summary>
		/// <param name="commandLine">Command Line</param>
		/// <param name="timeStamp">Timestamp</param>
		public DataClassExample2(string commandLine, DateTime timeStamp)
		{
			this.commandLine = commandLine;
			this.timeStamp = timeStamp;
		}
		
		/// <summary>
		/// Seralization constructor
		/// </summary>
		/// <param name="info">The object that holds the serialized object data.</param>
		/// <param name="context">The contextual information about the source or destination.</param>
		public DataClassExample2(
			SerializationInfo info, 
			StreamingContext context
			)
		{
			commandLine = info.GetString("CommandLine");
			timeStamp = info.GetDateTime("TimeStamp");
		}
	
		/// <summary>
		/// Provides a customised <see cref="GetObjectData"/>
		/// implementation for serializing the contents of the class.
		/// </summary>
		/// <param name="info">The <see cref="System.Runtime.Serialization.SerializationInfo" /> 
		/// into which the object is serialized.</param>
		/// <param name="context">The source and destination of the serialization.</param>
		public void GetObjectData ( 
			SerializationInfo info , 
			StreamingContext context 
			)
		{
			info.AddValue("CommandLine", commandLine);
			info.AddValue("TimeStamp", timeStamp);
		}		

		/// <summary>
		/// Gets the <c>CommandLine</c> value stored in this class.
		/// </summary>
		public string CommandLine
		{
			get
			{
				return this.commandLine;
			}
		}

		/// <summary>
		/// Gets the <c>Timestamp</c> value stored in this class.
		/// </summary>
		public DateTime TimeStamp
		{
			get
			{
				return this.timeStamp;
			}
		}
	}
}
