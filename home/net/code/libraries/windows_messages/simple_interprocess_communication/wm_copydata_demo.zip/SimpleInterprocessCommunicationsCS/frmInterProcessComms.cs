using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using vbAccelerator.Components.Win32;

namespace SimpleInterprocessCommunications
{
	/// <summary>
	/// A Windows form demonstrating using the CopyData class for
	/// inter-process messaging.
	/// </summary>
	public class frmInterProcessComms : System.Windows.Forms.Form
	{
		/// <summary>
		/// The CopyData class used for message sending.
		/// </summary>
		private CopyData copyData = null;
		private System.Windows.Forms.GroupBox grpSend;
		private System.Windows.Forms.ComboBox cboChannels;
		private System.Windows.Forms.TextBox txtToSend;
		private System.Windows.Forms.Button btnSend;
		private System.Windows.Forms.GroupBox grpReceive;
		private System.Windows.Forms.ListBox lstReceived;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Label lblRecipients;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary>
		/// Constructs a new instance of this form
		/// </summary>
		public frmInterProcessComms()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmInterProcessComms));
			this.grpSend = new System.Windows.Forms.GroupBox();
			this.cboChannels = new System.Windows.Forms.ComboBox();
			this.txtToSend = new System.Windows.Forms.TextBox();
			this.btnSend = new System.Windows.Forms.Button();
			this.grpReceive = new System.Windows.Forms.GroupBox();
			this.lstReceived = new System.Windows.Forms.ListBox();
			this.btnClear = new System.Windows.Forms.Button();
			this.lblRecipients = new System.Windows.Forms.Label();
			this.grpSend.SuspendLayout();
			this.grpReceive.SuspendLayout();
			this.SuspendLayout();
			// 
			// grpSend
			// 
			this.grpSend.Controls.AddRange(new System.Windows.Forms.Control[] {
																				  this.lblRecipients,
																				  this.cboChannels,
																				  this.txtToSend,
																				  this.btnSend});
			this.grpSend.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.grpSend.Location = new System.Drawing.Point(4, 4);
			this.grpSend.Name = "grpSend";
			this.grpSend.Size = new System.Drawing.Size(292, 100);
			this.grpSend.TabIndex = 4;
			this.grpSend.TabStop = false;
			this.grpSend.Text = "Send Data";
			// 
			// cboChannels
			// 
			this.cboChannels.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cboChannels.Location = new System.Drawing.Point(8, 20);
			this.cboChannels.Name = "cboChannels";
			this.cboChannels.Size = new System.Drawing.Size(192, 21);
			this.cboChannels.TabIndex = 6;
			// 
			// txtToSend
			// 
			this.txtToSend.Location = new System.Drawing.Point(8, 44);
			this.txtToSend.Multiline = true;
			this.txtToSend.Name = "txtToSend";
			this.txtToSend.Size = new System.Drawing.Size(192, 40);
			this.txtToSend.TabIndex = 5;
			this.txtToSend.Text = "This is the data to send on the selected channel.";
			// 
			// btnSend
			// 
			this.btnSend.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnSend.Location = new System.Drawing.Point(208, 20);
			this.btnSend.Name = "btnSend";
			this.btnSend.TabIndex = 4;
			this.btnSend.Text = "&Send";
			this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
			// 
			// grpReceive
			// 
			this.grpReceive.Controls.AddRange(new System.Windows.Forms.Control[] {
																					 this.btnClear,
																					 this.lstReceived});
			this.grpReceive.Location = new System.Drawing.Point(4, 108);
			this.grpReceive.Name = "grpReceive";
			this.grpReceive.Size = new System.Drawing.Size(288, 176);
			this.grpReceive.TabIndex = 5;
			this.grpReceive.TabStop = false;
			this.grpReceive.Text = "Received Data";
			// 
			// lstReceived
			// 
			this.lstReceived.Location = new System.Drawing.Point(8, 20);
			this.lstReceived.Name = "lstReceived";
			this.lstReceived.Size = new System.Drawing.Size(192, 147);
			this.lstReceived.TabIndex = 3;
			// 
			// btnClear
			// 
			this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnClear.Location = new System.Drawing.Point(204, 20);
			this.btnClear.Name = "btnClear";
			this.btnClear.TabIndex = 5;
			this.btnClear.Text = "&Clear";
			this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
			// 
			// lblRecipients
			// 
			this.lblRecipients.Location = new System.Drawing.Point(208, 48);
			this.lblRecipients.Name = "lblRecipients";
			this.lblRecipients.Size = new System.Drawing.Size(76, 16);
			this.lblRecipients.TabIndex = 7;
			// 
			// frmInterProcessComms
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(300, 290);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.grpReceive,
																		  this.grpSend});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmInterProcessComms";
			this.Text = "Simple Interprocess Data Sender";
			this.Load += new System.EventHandler(this.frmInterProcessComms_Load);
			this.grpSend.ResumeLayout(false);
			this.grpReceive.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmInterProcessComms());
		}

		/// <summary>
		/// Performs initialization on the CopyData class once the form
		/// has loaded and its handle has been assigned.
		/// </summary>
		/// <param name="sender">The form instance.</param>
		/// <param name="e">Not used.</param>
		private void frmInterProcessComms_Load(object sender, System.EventArgs e)
		{
			// Create a new instance of the class:
			copyData = new CopyData();
			
			// Assign the handle:
			copyData.AssignHandle(this.Handle);

			// Create the named channels to send and receive on.  The name
			// is arbitary; it can be anything you want.
			copyData.Channels.Add("DataClass1");
			copyData.Channels.Add("DataClass2");			

			// Display the channels in the combo box and pick
			// the first:
			foreach (CopyDataChannel channel in copyData.Channels)
			{
				cboChannels.Items.Add(channel.ChannelName);
			}
			cboChannels.SelectedIndex = 0;

			// Hook up event notifications whenever a message is received:
			copyData.DataReceived += new DataReceivedEventHandler(
				copyData_DataReceived);
		}

		/// <summary>
		/// Fired whenever message is received from another instance
		/// </summary>
		/// <param name="sender">The CopyData class which receieved the data.</param>
		/// <param name="e">Data that was receieved.</param>
		private void copyData_DataReceived(object sender, DataReceivedEventArgs e)
		{			
			// Display the data in the logging list box:
			if (e.ChannelName.Equals("DataClass1"))
			{
				DataClassExample1 data = (DataClassExample1)e.Data;
				lstReceived.Items.Add(
					String.Format("{0} : {1}", e.ChannelName,data.CommandLine));
			}
			else
			{
				DataClassExample2 data = (DataClassExample2)e.Data;
				lstReceived.Items.Add(
					String.Format("{0} : {1}", e.ChannelName,data.CommandLine));
			}
			lstReceived.SelectedIndex = lstReceived.Items.Count - 1;
		}

		/// <summary>
		/// Sends data in response to the send button being clicked.
		/// </summary>
		/// <param name="sender">The button that was clicked.</param>
		/// <param name="e">Not used.</param>
		private void btnSend_Click(object sender, System.EventArgs e)
		{
			// Pick the channel name to send on:
			string channelName = (string)cboChannels.Items[cboChannels.SelectedIndex];
			int recipients = 0;
			// Create some demonstration data and send it on the named
			// channel:
			if (channelName.Equals("DataClass1"))
			{
				DataClassExample1 data = new DataClassExample1(txtToSend.Text, DateTime.Now);
				recipients = copyData.Channels[channelName].Send(data);
			}
			else
			{
				DataClassExample2 data = new DataClassExample2(txtToSend.Text, DateTime.Now);
				recipients = copyData.Channels[channelName].Send(data);
			}
			// Display how many other instances receieved the message:
			lblRecipients.Text = String.Format("{0} recipients", recipients);
		}

		/// <summary>
		/// Clears the log in response to the clear button being clicked.
		/// </summary>
		/// <param name="sender">The button that was clicked.</param>
		/// <param name="e">Not used.</param>
		private void btnClear_Click(object sender, System.EventArgs e)
		{
			lstReceived.Items.Clear();
		}


	}
}
