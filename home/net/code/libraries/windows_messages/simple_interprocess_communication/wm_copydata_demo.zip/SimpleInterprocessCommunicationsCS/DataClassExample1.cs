using System;

namespace SimpleInterprocessCommunications
{
	/// <summary>
	/// A simple data object to be passed between instances
	/// using the <see cref="CopyData"/> class.  This object
	/// uses the default serialization implementation added by 
	/// the Framework when the <see cref="Serializable"/>
	/// attribute is used.
	/// </summary>
	[Serializable()]
	public class DataClassExample1
	{
		/// <summary>
		/// The CommandLine.
		/// </summary>
		public string CommandLine ="";
		/// <summary>
		/// Timestamp associated with the CommandLine
		/// </summary>
		public DateTime TimeStamp = DateTime.Now;


		/// <summary>
		/// Constructs a new instance of this class with the
		/// specified CommandLine and Timestamp.
		/// </summary>
		/// <param name="commandLine">CommandLine</param>
		/// <param name="timeStamp">Timestamp</param>
		public DataClassExample1(string commandLine, DateTime timeStamp)
		{
			this.CommandLine = commandLine;
			this.TimeStamp = timeStamp;
		}
	}
}
