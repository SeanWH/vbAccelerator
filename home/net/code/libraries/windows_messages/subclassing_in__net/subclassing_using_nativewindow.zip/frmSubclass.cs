using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using vbAccelerator.Components.SubClassExamples;

namespace SubClassTest
{
	/// <summary>
	/// Form for testing subclass techniques
	/// </summary>
	public class frmSubclass : 
		System.Windows.Forms.Form,
		IActivateChangeNotify,
		ISizingMovingNotify
	{
		#region Member Variables
		/// <summary>
		/// Size Move subclasser
		/// </summary>
		private SizingMovingSubclass sizeMove = null;
		/// <summary>
		/// Activate Change subclasser
		/// </summary>
		private ActivateChangeSubclass activateChange = null;
		private System.Windows.Forms.Panel pnlOptions;
		private System.Windows.Forms.CheckBox chkSizeMove;
		private System.Windows.Forms.CheckBox chkActivate;
		private System.Windows.Forms.ListBox lstLog;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		#endregion

		#region Constructor, Dispose
		public frmSubclass()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// Hook up events
			this.chkSizeMove.CheckedChanged += new System.EventHandler(this.chkSizeMove_CheckedChanged);
			this.chkActivate.CheckedChanged += new System.EventHandler(this.chkActivate_CheckedChanged);

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}
		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSubclass));
			this.pnlOptions = new System.Windows.Forms.Panel();
			this.chkSizeMove = new System.Windows.Forms.CheckBox();
			this.chkActivate = new System.Windows.Forms.CheckBox();
			this.lstLog = new System.Windows.Forms.ListBox();
			this.pnlOptions.SuspendLayout();
			this.SuspendLayout();
			// 
			// pnlOptions
			// 
			this.pnlOptions.Controls.AddRange(new System.Windows.Forms.Control[] {
																					 this.chkSizeMove,
																					 this.chkActivate});
			this.pnlOptions.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnlOptions.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.pnlOptions.Name = "pnlOptions";
			this.pnlOptions.Size = new System.Drawing.Size(292, 80);
			this.pnlOptions.TabIndex = 3;
			this.pnlOptions.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlOptions_Paint);
			// 
			// chkSizeMove
			// 
			this.chkSizeMove.Checked = true;
			this.chkSizeMove.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkSizeMove.Location = new System.Drawing.Point(12, 48);
			this.chkSizeMove.Name = "chkSizeMove";
			this.chkSizeMove.Size = new System.Drawing.Size(272, 24);
			this.chkSizeMove.TabIndex = 3;
			this.chkSizeMove.Text = "&Sizing/Moving Subclass";
			// 
			// chkActivate
			// 
			this.chkActivate.Checked = true;
			this.chkActivate.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkActivate.Location = new System.Drawing.Point(12, 8);
			this.chkActivate.Name = "chkActivate";
			this.chkActivate.Size = new System.Drawing.Size(272, 24);
			this.chkActivate.TabIndex = 2;
			this.chkActivate.Text = "&Activate Change Subclass";
			// 
			// lstLog
			// 
			this.lstLog.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lstLog.Location = new System.Drawing.Point(0, 80);
			this.lstLog.Name = "lstLog";
			this.lstLog.Size = new System.Drawing.Size(292, 186);
			this.lstLog.TabIndex = 4;
			// 
			// frmSubclass
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lstLog,
																		  this.pnlOptions});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmSubclass";
			this.Text = "Subclass Example";
			this.Load += new System.EventHandler(this.frmSubclass_Load);
			this.pnlOptions.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmSubclass());
		}

		public void ActivateChanged(ActivationStateChangeType changeType)
		{
			logEvent(String.Format(
				"Activate Changed: {0}", 
				Enum.GetName(typeof(ActivationStateChangeType), changeType)));
		}
		
		public void Sizing(ref System.Drawing.Rectangle rectangle, 
			SizingLocationTypes sizingLocation)
		{
			// set minimum size to 256/256:
			rectangle.Width = (rectangle.Width < 256 ? 256 : rectangle.Width);
			rectangle.Height = (rectangle.Height < 256 ? 256 : rectangle.Height);

			logEvent(String.Format(
				"Sizing to: {0}, From: {1}", 
				rectangle.ToString(), 
				Enum.GetName(typeof(SizingLocationTypes), sizingLocation)
				));
		}
		public void Moving(ref System.Drawing.Rectangle rectangle)
		{
			logEvent(String.Format(
				"Moving {0}", rectangle.ToString()));
		}
		public void Moved(System.Drawing.Rectangle rectangle)
		{
			logEvent(String.Format(
				"Moved {0}", rectangle.ToString()));
		}
		public void Sized(System.Drawing.Rectangle rectangle, SizedReasonTypes reason)
		{
			logEvent(String.Format(
				"Sized to {0}, Reason: {1}", 
				rectangle.ToString(),
				Enum.GetName(typeof(SizedReasonTypes), reason)
				));
		}

		private void logEvent(string msg)
		{
			lstLog.Items.Add(msg);
			lstLog.SelectedIndex = lstLog.Items.Count - 1;
		}

		private void frmSubclass_Load(object sender, System.EventArgs e)
		{
			sizeMove = new SizingMovingSubclass(
				this.Handle,
				null,
				this);
			activateChange = new ActivateChangeSubclass(
				this.Handle,
				null,
				this);
		}

		private void chkActivate_CheckedChanged(object sender, System.EventArgs e)
		{
			if (chkActivate.Checked)
			{
				activateChange.AssignHandle(this.Handle);
			}
			else
			{
				activateChange.ReleaseHandle();
			}
		}

		private void chkSizeMove_CheckedChanged(object sender, System.EventArgs e)
		{
			if (chkSizeMove.Checked)
			{
				sizeMove.AssignHandle(this.Handle);
			}
			else
			{
				sizeMove.ReleaseHandle();
			}
		}

		private void pnlOptions_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
		
		}

	}
}