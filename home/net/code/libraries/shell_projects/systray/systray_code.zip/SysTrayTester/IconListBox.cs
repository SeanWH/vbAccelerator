using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace vbAccelerator.Controls.ListBox
{
	/// <summary>
	/// Summary description for IconListBox.
	/// </summary>
	public class IconListBox : System.Windows.Forms.ListBox
	{

		private System.Windows.Forms.ImageList ilsIcons = null;

		public System.Windows.Forms.ImageList ImageList
		{
			get
			{
				return this.ilsIcons;
			}
			set
			{
				this.ilsIcons = value;
				this.ItemHeight = ilsIcons.ImageSize.Height + 4;
				this.ColumnWidth = ilsIcons.ImageSize.Width + 4;
			}
		}

		private void drawItem(System.Windows.Forms.DrawItemEventArgs e)
		{
			if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
			{
				e.Graphics.FillRectangle(SystemBrushes.Highlight, e.Bounds);
				if (this.Focused)
				{
					e.DrawFocusRectangle();
				}
			}
			else
			{
				e.Graphics.FillRectangle(SystemBrushes.Window, e.Bounds);
			}
			if (ilsIcons != null)
			{
				ilsIcons.Draw(e.Graphics, 
					e.Bounds.Left + 2, 
					e.Bounds.Top + 2, 
					ilsIcons.ImageSize.Width, 
					ilsIcons.ImageSize.Height, 
					(int)this.Items[e.Index]);
			}
		}

		protected override void OnDrawItem ( System.Windows.Forms.DrawItemEventArgs e )
		{
			if (base.DesignMode)
			{
				base.OnDrawItem(e);
			}
			else
			{
				if (e.Index>-1)
				{
					drawItem(e);
				}
				else
				{
					base.OnDrawItem(e);
				}
			}
		}

		public IconListBox() : base()
		{
			this.DrawMode = DrawMode.OwnerDrawFixed;
			this.MultiColumn = true;
			this.HorizontalScrollbar = true;
		}
	}
}
