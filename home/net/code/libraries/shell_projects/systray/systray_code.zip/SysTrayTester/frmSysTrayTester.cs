using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using vbAccelerator.Components.Shell;
using vbAccelerator.Controls.ListBox;
using vbAccelerator.Components.Menu;

namespace SysTrayTester
{
	/// <summary>
	/// A form which demonstrates the vbAccelerator SysTray 
	/// component.
	/// </summary>
	public class frmSysTrayTester : System.Windows.Forms.Form
	{

		private SysTray sysTray;

		private System.Windows.Forms.ImageList ilsIcons;
		private System.Windows.Forms.Button btnShowBalloon;
		private System.Windows.Forms.ListBox lstEvents;
		private IconListBox lstIcons;
		private System.Windows.Forms.Label lblIcons;
		private System.Windows.Forms.Label lblToolTipText;
		private System.Windows.Forms.TextBox txtToolTip;
		private System.Windows.Forms.Button btnSet;
		private System.Windows.Forms.CheckBox chkHide;
		private vbAccelerator.Components.Menu.IconContextMenu mnuContext;
		private vbAccelerator.Components.Menu.IconMenuItem mnuRestore;
		private vbAccelerator.Components.Menu.IconMenuItem mnuContextSep1;
		private vbAccelerator.Components.Menu.IconMenuItem mnuAbout;
		private vbAccelerator.Components.Menu.IconMenuItem mnuContextSep2;
		private vbAccelerator.Components.Menu.IconMenuItem mnuExit;
		private System.Windows.Forms.CheckBox chkShowInTaskBar;
		private System.ComponentModel.IContainer components;

		/// <summary>
		/// Creates a new instance of this tester form.
		/// </summary>
		public frmSysTrayTester()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSysTrayTester));
			this.ilsIcons = new System.Windows.Forms.ImageList(this.components);
			this.btnShowBalloon = new System.Windows.Forms.Button();
			this.lstEvents = new System.Windows.Forms.ListBox();
			this.lstIcons = new vbAccelerator.Controls.ListBox.IconListBox();
			this.lblIcons = new System.Windows.Forms.Label();
			this.lblToolTipText = new System.Windows.Forms.Label();
			this.txtToolTip = new System.Windows.Forms.TextBox();
			this.btnSet = new System.Windows.Forms.Button();
			this.chkHide = new System.Windows.Forms.CheckBox();
			this.mnuContext = new vbAccelerator.Components.Menu.IconContextMenu();
			this.mnuRestore = new vbAccelerator.Components.Menu.IconMenuItem();
			this.mnuContextSep1 = new vbAccelerator.Components.Menu.IconMenuItem();
			this.mnuAbout = new vbAccelerator.Components.Menu.IconMenuItem();
			this.mnuContextSep2 = new vbAccelerator.Components.Menu.IconMenuItem();
			this.mnuExit = new vbAccelerator.Components.Menu.IconMenuItem();
			this.chkShowInTaskBar = new System.Windows.Forms.CheckBox();
			this.SuspendLayout();
			// 
			// ilsIcons
			// 
			this.ilsIcons.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.ilsIcons.ImageSize = new System.Drawing.Size(16, 16);
			this.ilsIcons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ilsIcons.ImageStream")));
			this.ilsIcons.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// btnShowBalloon
			// 
			this.btnShowBalloon.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnShowBalloon.Location = new System.Drawing.Point(80, 92);
			this.btnShowBalloon.Name = "btnShowBalloon";
			this.btnShowBalloon.Size = new System.Drawing.Size(92, 28);
			this.btnShowBalloon.TabIndex = 0;
			this.btnShowBalloon.Text = "Show &Balloon";
			this.btnShowBalloon.Click += new System.EventHandler(this.btnShowBalloon_Click);
			// 
			// lstEvents
			// 
			this.lstEvents.Location = new System.Drawing.Point(8, 180);
			this.lstEvents.Name = "lstEvents";
			this.lstEvents.Size = new System.Drawing.Size(276, 95);
			this.lstEvents.TabIndex = 1;
			// 
			// lstIcons
			// 
			this.lstIcons.ColumnWidth = 20;
			this.lstIcons.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
			this.lstIcons.HorizontalScrollbar = true;
			this.lstIcons.ImageList = this.ilsIcons;
			this.lstIcons.ItemHeight = 20;
			this.lstIcons.Location = new System.Drawing.Point(80, 4);
			this.lstIcons.MultiColumn = true;
			this.lstIcons.Name = "lstIcons";
			this.lstIcons.Size = new System.Drawing.Size(204, 24);
			this.lstIcons.TabIndex = 2;
			// 
			// lblIcons
			// 
			this.lblIcons.Location = new System.Drawing.Point(8, 8);
			this.lblIcons.Name = "lblIcons";
			this.lblIcons.Size = new System.Drawing.Size(68, 16);
			this.lblIcons.TabIndex = 3;
			this.lblIcons.Text = "Icon:";
			// 
			// lblToolTipText
			// 
			this.lblToolTipText.Location = new System.Drawing.Point(8, 32);
			this.lblToolTipText.Name = "lblToolTipText";
			this.lblToolTipText.Size = new System.Drawing.Size(72, 23);
			this.lblToolTipText.TabIndex = 4;
			this.lblToolTipText.Text = "Tooltip Text:";
			// 
			// txtToolTip
			// 
			this.txtToolTip.Location = new System.Drawing.Point(80, 32);
			this.txtToolTip.Name = "txtToolTip";
			this.txtToolTip.Size = new System.Drawing.Size(204, 21);
			this.txtToolTip.TabIndex = 5;
			this.txtToolTip.Text = "Sample SysTray Application";
			// 
			// btnSet
			// 
			this.btnSet.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnSet.Location = new System.Drawing.Point(80, 60);
			this.btnSet.Name = "btnSet";
			this.btnSet.Size = new System.Drawing.Size(92, 28);
			this.btnSet.TabIndex = 6;
			this.btnSet.Text = "&Set";
			this.btnSet.Click += new System.EventHandler(this.btnSet_Click);
			// 
			// chkHide
			// 
			this.chkHide.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.chkHide.Location = new System.Drawing.Point(84, 132);
			this.chkHide.Name = "chkHide";
			this.chkHide.Size = new System.Drawing.Size(148, 16);
			this.chkHide.TabIndex = 7;
			this.chkHide.Text = "&Hide Me";
			this.chkHide.CheckedChanged += new System.EventHandler(this.chkHide_CheckedChanged);
			// 
			// mnuContext
			// 
			this.mnuContext.IconImageList = null;
			this.mnuContext.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.mnuRestore,
																					   this.mnuContextSep1,
																					   this.mnuAbout,
																					   this.mnuContextSep2,
																					   this.mnuExit});
			// 
			// mnuRestore
			// 
			this.mnuRestore.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
			this.mnuRestore.IconIndex = -1;
			this.mnuRestore.Index = 0;
			this.mnuRestore.OwnerDraw = true;
			this.mnuRestore.Tag = "";
			this.mnuRestore.Text = "&Restore";
			// 
			// mnuContextSep1
			// 
			this.mnuContextSep1.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
			this.mnuContextSep1.IconIndex = -1;
			this.mnuContextSep1.Index = 1;
			this.mnuContextSep1.OwnerDraw = true;
			this.mnuContextSep1.Tag = "";
			this.mnuContextSep1.Text = "-";
			// 
			// mnuAbout
			// 
			this.mnuAbout.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
			this.mnuAbout.IconIndex = -1;
			this.mnuAbout.Index = 2;
			this.mnuAbout.OwnerDraw = true;
			this.mnuAbout.Tag = "";
			this.mnuAbout.Text = "&About...";
			// 
			// mnuContextSep2
			// 
			this.mnuContextSep2.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
			this.mnuContextSep2.IconIndex = -1;
			this.mnuContextSep2.Index = 3;
			this.mnuContextSep2.OwnerDraw = true;
			this.mnuContextSep2.Tag = "";
			this.mnuContextSep2.Text = "-";
			// 
			// mnuExit
			// 
			this.mnuExit.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
			this.mnuExit.IconIndex = -1;
			this.mnuExit.Index = 4;
			this.mnuExit.OwnerDraw = true;
			this.mnuExit.Tag = "";
			this.mnuExit.Text = "E&xit";
			// 
			// chkShowInTaskBar
			// 
			this.chkShowInTaskBar.Checked = true;
			this.chkShowInTaskBar.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkShowInTaskBar.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.chkShowInTaskBar.Location = new System.Drawing.Point(84, 152);
			this.chkShowInTaskBar.Name = "chkShowInTaskBar";
			this.chkShowInTaskBar.Size = new System.Drawing.Size(148, 20);
			this.chkShowInTaskBar.TabIndex = 8;
			this.chkShowInTaskBar.Text = "Show in Task&bar";
			this.chkShowInTaskBar.CheckedChanged += new System.EventHandler(this.chkShowInTaskBar_CheckedChanged);
			// 
			// frmSysTrayTester
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(292, 282);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.chkShowInTaskBar,
																		  this.chkHide,
																		  this.btnSet,
																		  this.txtToolTip,
																		  this.lblToolTipText,
																		  this.lblIcons,
																		  this.lstIcons,
																		  this.lstEvents,
																		  this.btnShowBalloon});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "frmSysTrayTester";
			this.Text = "SysTray Tester";
			this.Load += new System.EventHandler(this.frmSysTrayTester_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmSysTrayTester());
		}

		/// <summary>
		/// Enables the SysTray notification icon to be replaced
		/// if the form is recreated.  Recreation occurs in response
		/// to changing a handful of the form's properties, for example
		/// <see cref="System.Windows.Forms.ShowInTaskBar"/>.  In
		/// a real application you would look for an alternative way
		/// to achieve the same effect, since recreating a form 
		/// is slow and looks unprofessional.
		/// </summary>
		/// <param name="e">Not used.</param>
		protected override void OnHandleCreated(EventArgs e)
		{
			if (null != sysTray)
			{
				sysTray.AssignHandle(this.Handle);	
				sysTray.ShowInSysTray = true;
			}
			base.OnHandleCreated(e);
		}

		/// <summary>
		/// Configure the form's content and the SysTray object.
		/// </summary>
		/// <param name="sender">The form that has been loaded.</param>
		/// <param name="e">Not used.</param>
		private void frmSysTrayTester_Load(object sender, System.EventArgs e)
		{
			// Add the icons to the icon picker:
			for (int i = 0; i < ilsIcons.Images.Count; i++)
			{
				lstIcons.Items.Add(i);
			}
			lstIcons.SelectedIndex = 0;

			// Start responding to menu events:
			mnuRestore.Click += new EventHandler(mnu_Click);
			mnuAbout.Click += new EventHandler(mnu_Click);
			mnuExit.Click += new EventHandler(mnu_Click);

			// Assign the SysTray object to this form
			sysTray = new SysTray(this);
			// Set the Icon:
			sysTray.IconImageList = ilsIcons;
			sysTray.IconIndex = 0;
			// Set the default context menu:
			sysTray.Menu = mnuContext;
			// Set the tooltip text:
			sysTray.ToolTipText = txtToolTip.Text;
			
			// events:
			sysTray.MouseDown += new MouseEventHandler(sysTray_MouseDown);
			sysTray.MouseUp += new MouseEventHandler(sysTray_MouseUp);
			sysTray.MouseMove += new MouseEventHandler(sysTray_MouseMove);
			sysTray.Click += new EventHandler(sysTray_Click);
			sysTray.DoubleClick += new EventHandler(sysTray_DoubleClick);
			sysTray.KeySelect += new EventHandler(sysTray_KeySelect);
			sysTray.EnterSelect += new EventHandler(sysTray_EnterSelect);
			sysTray.BalloonClicked += new EventHandler(sysTray_BalloonClicked);
			sysTray.BalloonHide += new EventHandler(sysTray_BalloonHide);
			sysTray.BalloonShow += new EventHandler(sysTray_BalloonShow);
			sysTray.BalloonTimeOut += new EventHandler(sysTray_BalloonTimeOut);

			// Show:
			sysTray.ShowInSysTray = true;

		
		}

		/// <summary>
		/// Show a balloon tip with an INFO icon, a title and some text.
		/// </summary>
		/// <param name="sender">Button which was clicked.</param>
		/// <param name="e">Not used.</param>
		private void btnShowBalloon_Click(object sender, System.EventArgs e)
		{
			sysTray.ShowBalloonTip("Welcome from vbAccelerator.com", 
				NotifyIconBalloonIconFlags.NIIF_INFO,
				"vbAccelerator.com SysTray Sample");
		}

		private void sysTray_Click(object sender, EventArgs e)
		{
			logEvent("Click");
		}
		private void sysTray_DoubleClick(object sender, EventArgs e)
		{
			logEvent("DoubleClick");
			RestoreMe();
		}
		private void sysTray_KeySelect(object sender, EventArgs e)
		{
			logEvent("KeySelect");
		}
		private void sysTray_EnterSelect(object sender, EventArgs e)
		{
			logEvent("EnterSelect");
		}
		private void sysTray_MouseDown(object sender, MouseEventArgs e)
		{
			logEvent(String.Format("MouseDown, {0}", e.ToString()));
		}
		private void sysTray_MouseMove(object sender, MouseEventArgs e)
		{
			logEvent(String.Format("MouseMove, {0}", e.ToString()));
		}
		private void sysTray_MouseUp(object sender, MouseEventArgs e)
		{
			logEvent(String.Format("MouseUp, {0}", e.ToString()));
		}
		private void sysTray_BalloonClicked(object sender, EventArgs e)
		{
			logEvent("Balloon Clicked");
		}
		private void sysTray_BalloonShow(object sender, EventArgs e)
		{
			logEvent("Balloon Show");
		}
		private void sysTray_BalloonHide(object sender, EventArgs e)
		{
			logEvent("Balloon Hide");
		}
		private void sysTray_BalloonTimeOut(object sender, EventArgs e)
		{
			logEvent("Balloon TimeOut");
		}

		private void logEvent(string msg)
		{
			lstEvents.Items.Add(msg);
			lstEvents.SelectedIndex = lstEvents.Items.Count - 1;
		}

		private void btnSet_Click(object sender, System.EventArgs e)
		{
			sysTray.IconIndex = lstIcons.SelectedIndex;
			sysTray.ToolTipText = txtToolTip.Text;
		}

		/// <summary>
		/// Respond to all menu click events.
		/// </summary>
		/// <param name="sender">The menu object that was clicking.</param>
		/// <param name="e">Not used.</param>
		private void mnu_Click(object sender, System.EventArgs e)
		{
			if (sender == mnuAbout)
			{
				frmAbout fA = new frmAbout();
				fA.ShowDialog(this);
			}
			else if (sender == mnuExit)
			{
				sysTray.SetFocus();
				this.Close();
			}
			else if (sender == mnuRestore)
			{
				RestoreMe();
			}
		}

		/// <summary>
		/// Performs the following steps as necessary:
		/// unhides, unmiminizes, brings to foreground and
		/// sets as active application.
		/// </summary>
		private void RestoreMe()
		{
			if (!this.Visible)
			{
				this.Visible = true;
			}
			if (this.WindowState == FormWindowState.Minimized)
			{
				this.WindowState = FormWindowState.Normal;
			}
			this.BringToFront();
			chkHide.Checked = false;
		}

		/// <summary>
		/// Respond to the Hide check box being clicked.
		/// </summary>
		/// <param name="sender">Check box which was clicked.</param>
		/// <param name="e">Not used.</param>
		private void chkHide_CheckedChanged(object sender, System.EventArgs e)
		{
			if (chkHide.Checked)
			{
				this.Visible = false;
			}
		}

		/// <summary>
		/// Respond to the Show in Task Bar check box being clicked.
		/// </summary>
		/// <param name="sender">Check box which was clicked.</param>
		/// <param name="e">Not used.</param>
		private void chkShowInTaskBar_CheckedChanged(object sender, System.EventArgs e)
		{
			// changing this will cause the Window to be recreated.
			// see OnHandleCreated
			this.ShowInTaskbar = (chkShowInTaskBar.Checked);			
		}
				
	}
}
