using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

using vbAccelerator.Components.ImageList;

namespace UsingSysImageList
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmUsingSysImageList : System.Windows.Forms.Form
	{
		#region Member Variables
		private SysImageList sysilsExtraLarge = null;
		private SysImageList sysilsLarge = null;
		private SysImageList sysilsSmall = null;

		private System.Windows.Forms.ListView listView1;
		private System.Windows.Forms.TreeView treeView1;
		private System.Windows.Forms.ListBox listBox1;
		#endregion
		private System.Windows.Forms.ComboBox comboBox1;

		private System.ComponentModel.IContainer components;

		/// <summary>
		/// A form to demonstrate using the Image List in 
		/// various controls.
		/// </summary>
		public frmUsingSysImageList()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// Add a paint handler for drawing directly onto the form:
			this.Paint += new PaintEventHandler(Form_Paint);
			// Add DrawItem handlers for the custom ListBox and ComboBox:
			this.listBox1.DrawItem += new DrawItemEventHandler(Item_DrawItem);
			this.comboBox1.DrawItem += new DrawItemEventHandler(Item_DrawItem);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.listView1 = new System.Windows.Forms.ListView();
			this.treeView1 = new System.Windows.Forms.TreeView();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.SuspendLayout();
			// 
			// listView1
			// 
			this.listView1.Location = new System.Drawing.Point(164, 8);
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(260, 176);
			this.listView1.TabIndex = 0;
			// 
			// treeView1
			// 
			this.treeView1.ImageIndex = -1;
			this.treeView1.Location = new System.Drawing.Point(4, 8);
			this.treeView1.Name = "treeView1";
			this.treeView1.SelectedImageIndex = -1;
			this.treeView1.Size = new System.Drawing.Size(156, 176);
			this.treeView1.TabIndex = 1;
			// 
			// listBox1
			// 
			this.listBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
			this.listBox1.Location = new System.Drawing.Point(164, 188);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(260, 134);
			this.listBox1.TabIndex = 2;
			// 
			// comboBox1
			// 
			this.comboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
			this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox1.Location = new System.Drawing.Point(4, 188);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(156, 22);
			this.comboBox1.TabIndex = 3;
			// 
			// frmUsingSysImageList
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(432, 350);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.comboBox1,
																		  this.listBox1,
																		  this.treeView1,
																		  this.listView1});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "frmUsingSysImageList";
			this.Text = "Using System Image List";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmUsingSysImageList());
		}

		private void Form_Paint(object sender, PaintEventArgs p)
		{
			int xOrigin = this.comboBox1.Left;
			int x = xOrigin;
			int y = this.comboBox1.Top + this.comboBox1.Height + 16;
			int index = sysilsExtraLarge.IconIndex(
					Environment.GetFolderPath(
						System.Environment.SpecialFolder.Personal),
					true);

			IntPtr hdc = p.Graphics.GetHdc();

			sysilsExtraLarge.DrawImage(hdc, 
				index,
				x, y);
			x += sysilsExtraLarge.Size.Width + 4;
			sysilsExtraLarge.DrawImage(hdc, 
				index,
				x, y,
				ImageListDrawItemConstants.ILD_TRANSPARENT,
				0, 0,
				Color.Black,
				ImageListDrawStateConstants.ILS_SATURATE,
				Color.Black,
				Color.Black
				);
			
			x = xOrigin;
			y += sysilsExtraLarge.Size.Width + 4;
			sysilsExtraLarge.DrawImage(hdc, 
				index,
				x, y,
				ImageListDrawItemConstants.ILD_SELECTED | ImageListDrawItemConstants.ILD_TRANSPARENT
				);

			x += sysilsExtraLarge.Size.Width + 4;
			/*sysilsExtraLarge.DrawImage(hdc, 
				index,
				x, y,
				ImageListDrawItemConstants.ILD | ImageListDrawItemConstants.ILD_TRANSPARENT);
			*/
			Console.WriteLine("{0}", Color.FromKnownColor(KnownColor.Highlight).ToArgb());

			p.Graphics.ReleaseHdc(hdc);
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			// set up the ImageLists:
			sysilsSmall = new SysImageList(SysImageListSize.smallIcons);
			sysilsLarge = new SysImageList(SysImageListSize.largeIcons);
			sysilsExtraLarge = new SysImageList(SysImageListSize.extraLargeIcons);			
			
			// Get some data:
			string[] files = Directory.GetFiles("C:\\");
			string[] directories = Directory.GetDirectories("C:\\");

			// Add some test items to the TreeView:
			SysImageListHelper.SetTreeViewImageList(
				treeView1,
				sysilsSmall,
				false);
			foreach (string directory in directories)
			{
				TreeNode[] fakeChild = new TreeNode[1]
					{ new TreeNode("!TO DO!") };
				TreeNode node = new TreeNode(
					directory,
					sysilsSmall.IconIndex(directory, true),
					sysilsSmall.IconIndex(directory, true, ShellIconStateConstants.ShellIconStateOpen),
					fakeChild);
				treeView1.Nodes.Add(node);
			}


			// Add some test items to the ListView:
			SysImageListHelper.SetListViewImageList(
				listView1,
				sysilsExtraLarge,
				false);
			foreach (string directory in directories)
			{
				ListViewItem item = new ListViewItem(
					directory, 
					sysilsExtraLarge.IconIndex(directory, true));
				listView1.Items.Add(item);
			}
			foreach (string file in files)
			{
				ListViewItem item = new ListViewItem(
					file, 
					sysilsExtraLarge.IconIndex(file));
				listView1.Items.Add(item);
			}


			// Add some test items to the combo and list box:
			this.comboBox1.ItemHeight = sysilsSmall.Size.Height + 2;
			this.listBox1.ItemHeight = sysilsSmall.Size.Height + 2;
			foreach (string directory in directories)
			{
				this.comboBox1.Items.Add(directory);				
			}
			foreach (string file in files)
			{
				this.listBox1.Items.Add(file);
			}

		}

		private void Item_DrawItem(object sender, DrawItemEventArgs e)
		{
			if (e.Index > -1)
			{
				string item = "";
				int iconIndex = 0;
				Font font = null;
				if (sender.GetType().Equals(this.listBox1.GetType()))
				{
					item = (string)((ListBox)sender).Items[e.Index];
					font = ((ListBox)sender).Font;
					iconIndex = sysilsSmall.IconIndex(item, true);
				}
				else
				{
					item = (string)((ComboBox)sender).Items[e.Index];
					font = ((ComboBox)sender).Font;
					iconIndex = sysilsSmall.IconIndex(item, true);
				}
				Brush br = null;
				if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
				{
					e.Graphics.FillRectangle(
						SystemBrushes.Highlight, e.Bounds);
					br = SystemBrushes.HighlightText;
				}
				else
				{
					e.Graphics.FillRectangle(
						SystemBrushes.Window, e.Bounds);
					br = SystemBrushes.WindowText;
				}

				IntPtr hdc = e.Graphics.GetHdc();
				sysilsSmall.DrawImage(					
					hdc, 
					iconIndex,
					e.Bounds.X + 1, 
					e.Bounds.Y + 1);
				e.Graphics.ReleaseHdc(hdc);
				e.Graphics.DrawString(
					item, 
					font,
					br,
					(float)e.Bounds.X + sysilsSmall.Size.Width + 2,
					(float)e.Bounds.Y + 1);
			}
		}

		private class UnManagedMethods
		{


		}
	}
}
