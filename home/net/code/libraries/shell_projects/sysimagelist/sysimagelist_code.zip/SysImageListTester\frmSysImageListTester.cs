using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using vbAccelerator.Components.ImageList;
using vbAccelerator.Controls.TextBox;
using vbAccelerator.Components.Shell;

namespace SysImageListTester
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmSysImageListTester : System.Windows.Forms.Form
	{
		private SysImageList sysImageListSmall;
		private SysImageList sysImageListLarge;
		private SysImageList sysImageListExtraLarge;
		private string fileName = "";
		private System.Windows.Forms.Label lblFileName;
		private AutoCompleteTextBox txtFileName;
		private System.Windows.Forms.Button btnPick;
		private System.Windows.Forms.Label lblIcons;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmSysImageListTester()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// Create the SysImageLists:
			sysImageListExtraLarge = new SysImageList(SysImageListSize.extraLargeIcons);							
			sysImageListLarge = new SysImageList(SysImageListSize.largeIcons);
			sysImageListSmall = new SysImageList(SysImageListSize.smallIcons);

			// Set up txtFile for AutoComplete:
			txtFileName.AutoCompleteFlags = SHAutoCompleteFlags.SHACF_FILESYS_ONLY;
			txtFileName.KeyDown += new KeyEventHandler(txtFileName_KeyDown);

			this.Paint += new PaintEventHandler(frmSysImageListTester_Paint);			
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSysImageListTester));
			this.lblFileName = new System.Windows.Forms.Label();
			this.txtFileName = new vbAccelerator.Controls.TextBox.AutoCompleteTextBox();
			this.btnPick = new System.Windows.Forms.Button();
			this.lblIcons = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// lblFileName
			// 
			this.lblFileName.Location = new System.Drawing.Point(8, 8);
			this.lblFileName.Name = "lblFileName";
			this.lblFileName.Size = new System.Drawing.Size(36, 23);
			this.lblFileName.TabIndex = 1;
			this.lblFileName.Text = "File:";
			// 
			// txtFileName
			// 
			this.txtFileName.AutoCompleteFlags = vbAccelerator.Controls.TextBox.SHAutoCompleteFlags.SHACF_FILESYS_ONLY;
			this.txtFileName.Location = new System.Drawing.Point(44, 8);
			this.txtFileName.Name = "txtFileName";
			this.txtFileName.Size = new System.Drawing.Size(432, 21);
			this.txtFileName.TabIndex = 5;
			this.txtFileName.Text = "";
			// 
			// btnPick
			// 
			this.btnPick.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnPick.Location = new System.Drawing.Point(480, 4);
			this.btnPick.Name = "btnPick";
			this.btnPick.Size = new System.Drawing.Size(24, 23);
			this.btnPick.TabIndex = 4;
			this.btnPick.Text = "...";
			this.btnPick.Click += new System.EventHandler(this.btnPick_Click);
			// 
			// lblIcons
			// 
			this.lblIcons.Location = new System.Drawing.Point(8, 80);
			this.lblIcons.Name = "lblIcons";
			this.lblIcons.Size = new System.Drawing.Size(36, 23);
			this.lblIcons.TabIndex = 6;
			this.lblIcons.Text = "Icons:";
			// 
			// frmSysImageListTester
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(512, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lblIcons,
																		  this.txtFileName,
																		  this.btnPick,
																		  this.lblFileName});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmSysImageListTester";
			this.Text = "System Image List Tester";
			this.Load += new System.EventHandler(this.frmSysImageListTester_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmSysImageListTester());
		}

		private void frmSysImageListTester_Paint(object sender, PaintEventArgs e)
		{
			e.Graphics.FillRectangle(
				SystemBrushes.Control,
				e.ClipRectangle);
			
			if (fileName.Length > 0)
			{
				int x = lblIcons.Left + lblIcons.Width + 16;
				int y = lblIcons.Top;

				IntPtr hdc = e.Graphics.GetHdc();

				sysImageListExtraLarge.DrawImage(
					hdc, 
					sysImageListExtraLarge.IconIndex(fileName, true),
					x, y);
				
				sysImageListLarge.DrawImage(
					hdc, 
					sysImageListLarge.IconIndex(fileName, true),
					x + 64, y);
				
				sysImageListSmall.DrawImage(
					hdc, 
					sysImageListSmall.IconIndex(fileName, true),
					x + 128, y);

				e.Graphics.ReleaseHdc(hdc);
			}
		}

		private void frmSysImageListTester_Load(object sender, System.EventArgs e)
		{
		
		}

		private void btnPick_Click(object sender, System.EventArgs e)
		{			
			using (FolderBrowser f = new FolderBrowser())
			{
				f.Title = "Select a folder or file to thumbnail.";
				f.FileSystemAncestorsOnly = true;
				f.NewDialogStyle = true;
				f.NoNewFolderButton = true;
				f.ShowEditBox = true;
				f.ValidateEditBox = true;
				f.IncludeFiles = true;
				f.InitialPath = System.Environment.GetFolderPath(
					System.Environment.SpecialFolder.Personal);

				ValidationFailedEventHandler valFailed = new ValidationFailedEventHandler(
					folderBrowser_ValidationFailed);
				f.ValidationFailed += valFailed;

				if (f.ShowDialog(this) == DialogResult.OK)
				{
					fileName = f.SelectedPath;
					txtFileName.Text = fileName;
					this.Invalidate();
				}		
				f.ValidationFailed -= valFailed;
			}
		}

		private void folderBrowser_ValidationFailed(object sender, ValidationFailedEventArgs e)
		{
			if (MessageBox.Show(
				this,
				String.Format("The folder or file '{0}' could not be found.  Choose Retry to pick another folder or Cancel to cancel.", e.Message), 
				this.Text, 
				MessageBoxButtons.RetryCancel,
				MessageBoxIcon.Warning) == DialogResult.Cancel)
			{
				e.Cancel = true;
			}
			else
			{
				e.Cancel = false;
			}
		}

		private void txtFileName_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Return)
			{
				fileName = txtFileName.Text;
				this.Invalidate();
			}
		}


	}
}
