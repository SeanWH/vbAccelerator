using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using vbAccelerator.Controls.TextBox;
using vbAccelerator.Controls.ComboBox;

namespace ShAutoComplete
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmAutoComplete : System.Windows.Forms.Form
	{
		private AutoCompleteTextBox txtAutoComplete;
		private AutoCompleteComboBox cboAutoComplete;
		private System.Windows.Forms.Label lblTextBox;
		private System.Windows.Forms.Label lblCombo;
		private System.Windows.Forms.CheckedListBox lstFlags;
		private System.Windows.Forms.Label lblFlags;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmAutoComplete()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmAutoComplete));
			this.txtAutoComplete = new vbAccelerator.Controls.TextBox.AutoCompleteTextBox();
			this.cboAutoComplete = new vbAccelerator.Controls.ComboBox.AutoCompleteComboBox();
			this.lblTextBox = new System.Windows.Forms.Label();
			this.lblCombo = new System.Windows.Forms.Label();
			this.lstFlags = new System.Windows.Forms.CheckedListBox();
			this.lblFlags = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// txtAutoComplete
			// 
			this.txtAutoComplete.AutoCompleteFlags = vbAccelerator.Controls.TextBox.AutoCompleteTextBox.SHAutoCompleteFlags.SHACF_FILESYS_ONLY;
			this.txtAutoComplete.Location = new System.Drawing.Point(76, 8);
			this.txtAutoComplete.Name = "txtAutoComplete";
			this.txtAutoComplete.Size = new System.Drawing.Size(324, 20);
			this.txtAutoComplete.TabIndex = 0;
			this.txtAutoComplete.Text = "";
			// 
			// cboAutoComplete
			// 
			this.cboAutoComplete.AutoCompleteFlags = vbAccelerator.Controls.ComboBox.AutoCompleteComboBox.SHAutoCompleteFlags.SHACF_FILESYS_ONLY;
			this.cboAutoComplete.Location = new System.Drawing.Point(76, 36);
			this.cboAutoComplete.Name = "cboAutoComplete";
			this.cboAutoComplete.Size = new System.Drawing.Size(324, 21);
			this.cboAutoComplete.TabIndex = 1;
			// 
			// lblTextBox
			// 
			this.lblTextBox.Location = new System.Drawing.Point(4, 12);
			this.lblTextBox.Name = "lblTextBox";
			this.lblTextBox.Size = new System.Drawing.Size(68, 16);
			this.lblTextBox.TabIndex = 2;
			this.lblTextBox.Text = "Text Box:";
			// 
			// lblCombo
			// 
			this.lblCombo.Location = new System.Drawing.Point(4, 36);
			this.lblCombo.Name = "lblCombo";
			this.lblCombo.Size = new System.Drawing.Size(72, 20);
			this.lblCombo.TabIndex = 3;
			this.lblCombo.Text = "Combo Box:";
			// 
			// lstFlags
			// 
			this.lstFlags.Location = new System.Drawing.Point(76, 88);
			this.lstFlags.Name = "lstFlags";
			this.lstFlags.Size = new System.Drawing.Size(324, 244);
			this.lstFlags.TabIndex = 4;
			this.lstFlags.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.lstFlags_ItemCheck);
			// 
			// lblFlags
			// 
			this.lblFlags.Location = new System.Drawing.Point(76, 68);
			this.lblFlags.Name = "lblFlags";
			this.lblFlags.Size = new System.Drawing.Size(320, 16);
			this.lblFlags.TabIndex = 5;
			this.lblFlags.Text = "Auto-Complete Flags";
			// 
			// frmAutoComplete
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(408, 342);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lblFlags,
																		  this.lstFlags,
																		  this.lblCombo,
																		  this.lblTextBox,
																		  this.cboAutoComplete,
																		  this.txtAutoComplete});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmAutoComplete";
			this.Text = "Shell Auto-Completion Tester";
			this.Load += new System.EventHandler(this.frmAutoComplete_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmAutoComplete());
		}

		private void frmAutoComplete_Load(object sender, System.EventArgs e)
		{
			// set up 
			txtAutoComplete.AutoCompleteFlags = 
				AutoCompleteTextBox.SHAutoCompleteFlags.SHACF_FILESYS_ONLY;
			cboAutoComplete.AutoCompleteFlags = 
				AutoCompleteComboBox.SHAutoCompleteFlags.SHACF_FILESYS_ONLY;

			// show the flags:
			string[] flags = Enum.GetNames(
				typeof(AutoCompleteTextBox.SHAutoCompleteFlags));
			foreach (string flag in flags)
			{
				AutoCompleteTextBox.SHAutoCompleteFlags flagValue = 
					(AutoCompleteTextBox.SHAutoCompleteFlags)Enum.Parse(
						typeof(AutoCompleteTextBox.SHAutoCompleteFlags),
						flag, true);
				if ((flagValue & AutoCompleteTextBox.SHAutoCompleteFlags.SHACF_FILESYS_ONLY) ==
					AutoCompleteTextBox.SHAutoCompleteFlags.SHACF_FILESYS_ONLY)
				{
					lstFlags.Items.Add(flag, true);
				}
				else
				{
					lstFlags.Items.Add(flag, false);
				}
			}
		}

		private void lstFlags_ItemCheck(object sender, ItemCheckEventArgs e)
		{

			AutoCompleteTextBox.SHAutoCompleteFlags flagValue = 
				(AutoCompleteTextBox.SHAutoCompleteFlags)Enum.Parse(
					typeof(AutoCompleteTextBox.SHAutoCompleteFlags),
					(string)lstFlags.Items[e.Index], true);
	
			if (e.NewValue == CheckState.Checked)
			{
				// add this flag
				txtAutoComplete.AutoCompleteFlags |= flagValue;
				cboAutoComplete.AutoCompleteFlags |= (AutoCompleteComboBox.SHAutoCompleteFlags)flagValue;
			}
			else
			{
				// remove this flag
				txtAutoComplete.AutoCompleteFlags &= ~flagValue;
				cboAutoComplete.AutoCompleteFlags &= ~(AutoCompleteComboBox.SHAutoCompleteFlags)flagValue;
			}
		}
	}
}
