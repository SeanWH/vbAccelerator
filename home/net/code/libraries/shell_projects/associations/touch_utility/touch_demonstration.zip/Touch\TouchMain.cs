using System;
using System.IO;
using vbAccelerator.Components.Shell;

namespace vbAccelerator.Utilites
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Touch
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{			

			// Create association between touch and all files:
			string cmd = "";
			ClassAssociations cas = new ClassAssociations(PredefinedClassKey.AllFiles);
			cmd = cas.GetType().Assembly.Location + " \"%1\"";
			int index = cas.IndexOf("Touch");
			ClassAssociation ca = new ClassAssociation(
					"Touch", "", cmd);
			if (index == -1)
			{
				cas.Add(ca);
			}
			else
			{
				cas[index] = ca;
			}
			cas.Save();


			// Touch the specified file
			string msg = "";

			if (args.Length == 0)
			{
				msg = "No filename supplied.";
			}
			else
			{
				try
				{
					if (File.Exists(args[0]))
					{
						File.SetLastWriteTime(args[0], DateTime.Now);
					}
					else
					{
						msg = string.Format("The file {0} was not found", args[0]);
					}
				}
				catch (Exception ex)
				{
					msg = string.Format("Failed to touch file {0}: {1}", args[0], ex.Message);
				}
			}
			if (msg.Length > 0)
			{
				System.Windows.Forms.MessageBox.Show(null, msg,"Touch", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
			}
		}
	}
}
