using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using vbAccelerator.Controls.TextBox;
using vbAccelerator.Components.Shell;

namespace FileIconTester
{
	/// <summary>
	/// Simple test form for the vbAccelerator FileIcon and
	/// AutoCompleteTextBox classes.
	/// </summary>
	public class frmTestFileIcon : System.Windows.Forms.Form
	{
		private System.Windows.Forms.OpenFileDialog cdlOpen;
		private Icon testIcon = null;
		private vbAccelerator.Controls.TextBox.AutoCompleteTextBox txtFileName;
		private System.Windows.Forms.Label lblFile;
		private System.Windows.Forms.Button btnPick;
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Label lblSmallIcon;
		private System.Windows.Forms.Label lblFileType;
		private System.Windows.Forms.Label lblDisplayName;
		private System.Windows.Forms.TextBox txtFileType;
		private System.Windows.Forms.TextBox txtDisplayName;
		private System.Windows.Forms.ImageList ilsLargeIcons;
		private System.Windows.Forms.ImageList ilsSmallIcons;
		private System.Windows.Forms.Label lblLargeIcon;
		private System.Windows.Forms.Button btnGetDetails;

		/// <summary>
		/// A simple form to demonstrate usage of the FileIcon class
		/// </summary>
		public frmTestFileIcon()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			try
			{
				this.txtFileName.AutoCompleteFlags = AutoCompleteTextBox.SHAutoCompleteFlags.SHACF_FILESYS_ONLY;
			}
			catch
			{
				// call would fail on NT4 if it did not have IE5 installed;
				// not important since it is only a UI helper.
			}
			this.Paint += new PaintEventHandler(frmTestFileIcon_Paint);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTestFileIcon));
			this.cdlOpen = new System.Windows.Forms.OpenFileDialog();
			this.txtFileName = new vbAccelerator.Controls.TextBox.AutoCompleteTextBox();
			this.lblFile = new System.Windows.Forms.Label();
			this.btnPick = new System.Windows.Forms.Button();
			this.btnGetDetails = new System.Windows.Forms.Button();
			this.lblLargeIcon = new System.Windows.Forms.Label();
			this.lblSmallIcon = new System.Windows.Forms.Label();
			this.lblFileType = new System.Windows.Forms.Label();
			this.lblDisplayName = new System.Windows.Forms.Label();
			this.txtFileType = new System.Windows.Forms.TextBox();
			this.txtDisplayName = new System.Windows.Forms.TextBox();
			this.ilsLargeIcons = new System.Windows.Forms.ImageList(this.components);
			this.ilsSmallIcons = new System.Windows.Forms.ImageList(this.components);
			this.SuspendLayout();
			// 
			// txtFileName
			// 
			this.txtFileName.AutoCompleteFlags = vbAccelerator.Controls.TextBox.AutoCompleteTextBox.SHAutoCompleteFlags.SHACF_FILESYS_ONLY;
			this.txtFileName.Location = new System.Drawing.Point(72, 8);
			this.txtFileName.Name = "txtFileName";
			this.txtFileName.Size = new System.Drawing.Size(304, 21);
			this.txtFileName.TabIndex = 0;
			this.txtFileName.Text = "";
			// 
			// lblFile
			// 
			this.lblFile.Location = new System.Drawing.Point(8, 8);
			this.lblFile.Name = "lblFile";
			this.lblFile.Size = new System.Drawing.Size(60, 16);
			this.lblFile.TabIndex = 1;
			this.lblFile.Text = "File:";
			// 
			// btnPick
			// 
			this.btnPick.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnPick.Location = new System.Drawing.Point(380, 8);
			this.btnPick.Name = "btnPick";
			this.btnPick.Size = new System.Drawing.Size(24, 20);
			this.btnPick.TabIndex = 2;
			this.btnPick.Text = "...";
			this.btnPick.Click += new System.EventHandler(this.btnPick_Click);
			// 
			// btnGetDetails
			// 
			this.btnGetDetails.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnGetDetails.Location = new System.Drawing.Point(76, 36);
			this.btnGetDetails.Name = "btnGetDetails";
			this.btnGetDetails.Size = new System.Drawing.Size(116, 32);
			this.btnGetDetails.TabIndex = 4;
			this.btnGetDetails.Text = "Get Details";
			this.btnGetDetails.Click += new System.EventHandler(this.btnGetDetails_Click);
			// 
			// lblLargeIcon
			// 
			this.lblLargeIcon.Location = new System.Drawing.Point(76, 76);
			this.lblLargeIcon.Name = "lblLargeIcon";
			this.lblLargeIcon.Size = new System.Drawing.Size(84, 16);
			this.lblLargeIcon.TabIndex = 7;
			this.lblLargeIcon.Text = "Large Icon";
			// 
			// lblSmallIcon
			// 
			this.lblSmallIcon.Location = new System.Drawing.Point(168, 76);
			this.lblSmallIcon.Name = "lblSmallIcon";
			this.lblSmallIcon.Size = new System.Drawing.Size(84, 16);
			this.lblSmallIcon.TabIndex = 9;
			this.lblSmallIcon.Text = "Small Icon";
			// 
			// lblFileType
			// 
			this.lblFileType.Location = new System.Drawing.Point(76, 188);
			this.lblFileType.Name = "lblFileType";
			this.lblFileType.Size = new System.Drawing.Size(84, 16);
			this.lblFileType.TabIndex = 10;
			this.lblFileType.Text = "File Type:";
			// 
			// lblDisplayName
			// 
			this.lblDisplayName.Location = new System.Drawing.Point(76, 208);
			this.lblDisplayName.Name = "lblDisplayName";
			this.lblDisplayName.Size = new System.Drawing.Size(84, 16);
			this.lblDisplayName.TabIndex = 11;
			this.lblDisplayName.Text = "Display Name:";
			// 
			// txtFileType
			// 
			this.txtFileType.BackColor = System.Drawing.SystemColors.Control;
			this.txtFileType.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtFileType.Location = new System.Drawing.Point(168, 188);
			this.txtFileType.Name = "txtFileType";
			this.txtFileType.ReadOnly = true;
			this.txtFileType.Size = new System.Drawing.Size(180, 14);
			this.txtFileType.TabIndex = 12;
			this.txtFileType.Text = "";
			// 
			// txtDisplayName
			// 
			this.txtDisplayName.BackColor = System.Drawing.SystemColors.Control;
			this.txtDisplayName.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtDisplayName.Location = new System.Drawing.Point(168, 208);
			this.txtDisplayName.Name = "txtDisplayName";
			this.txtDisplayName.ReadOnly = true;
			this.txtDisplayName.Size = new System.Drawing.Size(180, 14);
			this.txtDisplayName.TabIndex = 13;
			this.txtDisplayName.Text = "";
			// 
			// ilsLargeIcons
			// 
			this.ilsLargeIcons.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.ilsLargeIcons.ImageSize = new System.Drawing.Size(32, 32);
			this.ilsLargeIcons.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// ilsSmallIcons
			// 
			this.ilsSmallIcons.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.ilsSmallIcons.ImageSize = new System.Drawing.Size(16, 16);
			this.ilsSmallIcons.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// frmTestFileIcon
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(408, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.txtDisplayName,
																		  this.txtFileType,
																		  this.lblDisplayName,
																		  this.lblFileType,
																		  this.lblSmallIcon,
																		  this.lblLargeIcon,
																		  this.btnGetDetails,
																		  this.btnPick,
																		  this.lblFile,
																		  this.txtFileName});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmTestFileIcon";
			this.Text = "FileIcon Class Tester";
			this.Load += new System.EventHandler(this.frmTestFileIcon_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Main Entry point - start the File Icon Tester form.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmTestFileIcon());
		}

		private void frmTestFileIcon_Load(object sender, System.EventArgs e)
		{
			// want to respond to return keys in the filename box:
			this.txtFileName.KeyDown += new KeyEventHandler(this.txtFileName_KeyDown);
		}

		private void frmTestFileIcon_Paint(object sender, PaintEventArgs e)
		{
			// clear area behind icons:
			Rectangle rc = new Rectangle(
				lblLargeIcon.Left,
				lblLargeIcon.Top + lblLargeIcon.Height + 2,
				96, 
				lblFileType.Top - (lblLargeIcon.Top + lblLargeIcon.Height + 2));
			e.Graphics.FillRectangle(SystemBrushes.Control, rc);

			// draw icons (if any):
			if (ilsLargeIcons.Images.Count > 0)
			{
				ilsLargeIcons.Draw(e.Graphics, 
					rc.Left,
					rc.Top, 
					0);
				e.Graphics.DrawIcon(testIcon, rc.Left + 32, rc.Top);
			}
			if (ilsSmallIcons.Images.Count > 0)
			{
				ilsSmallIcons.Draw(e.Graphics, 
					lblSmallIcon.Left,
					rc.Top, 
					0);
			}
		}

		private void btnGetDetails_Click(object sender, System.EventArgs e)
		{
			// show the selected icons:
			getDetails();
		}

		private void btnPick_Click(object sender, System.EventArgs e)
		{
			// show a common dialog to pick a file.  Note you could
			// use a FolderBrowser in file mode here if you wanted
			// to allow folders to picked as well.
			this.cdlOpen.Filter = "All Files (*.*)|*.*";
			if (this.cdlOpen.ShowDialog(this) == DialogResult.OK)
			{
				// file selected, show the details:
				txtFileName.Text = cdlOpen.FileName;
				getDetails();
			}
		}

		private void getDetails()
		{
			ilsSmallIcons.Images.Clear();
			ilsLargeIcons.Images.Clear();

			// by default the FileIcon will return DisplayName
			// and file type with a large icon:
			string fileName = txtFileName.Text;
			FileIcon fileIcon = 
				new FileIcon(fileName);
			ilsLargeIcons.Images.Add(fileIcon.ShellIcon);
			txtFileType.Text = fileIcon.TypeName;
			txtDisplayName.Text = fileIcon.DisplayName;
			testIcon = fileIcon.ShellIcon;

			// Only request the small icon:
			fileIcon.Flags = fileIcon.Flags 
				| FileIcon.SHGetFileInfoConstants.SHGFI_SMALLICON & 
				~(FileIcon.SHGetFileInfoConstants.SHGFI_DISPLAYNAME | FileIcon.SHGetFileInfoConstants.SHGFI_TYPENAME |
				FileIcon.SHGetFileInfoConstants.SHGFI_ATTRIBUTES | FileIcon.SHGetFileInfoConstants.SHGFI_EXETYPE );
			fileIcon.GetInfo();
			ilsSmallIcons.Images.Add(fileIcon.ShellIcon);
			this.Invalidate();
		}

		private void txtFileName_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Return)
			{
				getDetails();
			}
		}
	}
}
