using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using vbAccelerator.Components.Shell;

namespace FolderBrowserTest
{
	/// <summary>
	/// Provides a Form for testing the Folder Browser class.
	/// </summary>
	public class frmFolderBrowserTest : System.Windows.Forms.Form
	{
		#region Member Variables
		private System.Windows.Forms.ListBox lstEvents;
		private System.Windows.Forms.Button btnShowDialog;
		private System.Windows.Forms.GroupBox grpFileProperties;
		private System.Windows.Forms.TextBox txtRootPath;
		private System.Windows.Forms.Label lblRootPath;
		private System.Windows.Forms.TextBox txtInitialPath;
		private System.Windows.Forms.Label lblInitialPath;
		private System.Windows.Forms.GroupBox grpDisplayProperties;
		private System.Windows.Forms.CheckBox chkNewDialog;
		private System.Windows.Forms.CheckBox chkEditBox;
		private System.Windows.Forms.CheckBox chkValidateEditBox;
		private System.Windows.Forms.CheckBox chkNoNewFolder;
		private System.Windows.Forms.CheckBox chkIncludeFiles;
		private System.Windows.Forms.CheckBox chkFilter;
		private System.Windows.Forms.TextBox txtStatusText;
		private System.Windows.Forms.Label lblStatusText;
		private System.Windows.Forms.TextBox txtTitle;
		private System.Windows.Forms.Label lblTitle;
		private System.Windows.Forms.TextBox txtSelection;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		#endregion

		#region Constructor and Dispose
		/// <summary>
		/// Constructs a new Folder Browser Test form
		/// </summary>
		public frmFolderBrowserTest()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.txtInitialPath.Text = 
				System.IO.Path.GetDirectoryName(Application.ExecutablePath);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}
		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFolderBrowserTest));
			this.btnShowDialog = new System.Windows.Forms.Button();
			this.lstEvents = new System.Windows.Forms.ListBox();
			this.grpFileProperties = new System.Windows.Forms.GroupBox();
			this.txtRootPath = new System.Windows.Forms.TextBox();
			this.lblRootPath = new System.Windows.Forms.Label();
			this.txtInitialPath = new System.Windows.Forms.TextBox();
			this.lblInitialPath = new System.Windows.Forms.Label();
			this.grpDisplayProperties = new System.Windows.Forms.GroupBox();
			this.chkNewDialog = new System.Windows.Forms.CheckBox();
			this.chkEditBox = new System.Windows.Forms.CheckBox();
			this.chkValidateEditBox = new System.Windows.Forms.CheckBox();
			this.chkNoNewFolder = new System.Windows.Forms.CheckBox();
			this.chkIncludeFiles = new System.Windows.Forms.CheckBox();
			this.chkFilter = new System.Windows.Forms.CheckBox();
			this.txtStatusText = new System.Windows.Forms.TextBox();
			this.lblStatusText = new System.Windows.Forms.Label();
			this.txtTitle = new System.Windows.Forms.TextBox();
			this.lblTitle = new System.Windows.Forms.Label();
			this.txtSelection = new System.Windows.Forms.TextBox();
			this.grpFileProperties.SuspendLayout();
			this.grpDisplayProperties.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnShowDialog
			// 
			this.btnShowDialog.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnShowDialog.Location = new System.Drawing.Point(12, 328);
			this.btnShowDialog.Name = "btnShowDialog";
			this.btnShowDialog.Size = new System.Drawing.Size(88, 23);
			this.btnShowDialog.TabIndex = 0;
			this.btnShowDialog.Text = "Show Dialog";
			this.btnShowDialog.Click += new System.EventHandler(this.btnShowDialog_Click);
			// 
			// lstEvents
			// 
			this.lstEvents.Location = new System.Drawing.Point(12, 364);
			this.lstEvents.Name = "lstEvents";
			this.lstEvents.Size = new System.Drawing.Size(404, 95);
			this.lstEvents.TabIndex = 1;
			// 
			// grpFileProperties
			// 
			this.grpFileProperties.Controls.AddRange(new System.Windows.Forms.Control[] {
																							this.txtRootPath,
																							this.lblRootPath,
																							this.txtInitialPath,
																							this.lblInitialPath});
			this.grpFileProperties.Location = new System.Drawing.Point(8, 8);
			this.grpFileProperties.Name = "grpFileProperties";
			this.grpFileProperties.Size = new System.Drawing.Size(408, 92);
			this.grpFileProperties.TabIndex = 8;
			this.grpFileProperties.TabStop = false;
			this.grpFileProperties.Text = "File Properties";
			// 
			// txtRootPath
			// 
			this.txtRootPath.Location = new System.Drawing.Point(80, 44);
			this.txtRootPath.Name = "txtRootPath";
			this.txtRootPath.Size = new System.Drawing.Size(316, 21);
			this.txtRootPath.TabIndex = 10;
			this.txtRootPath.Text = "";
			// 
			// lblRootPath
			// 
			this.lblRootPath.Location = new System.Drawing.Point(8, 48);
			this.lblRootPath.Name = "lblRootPath";
			this.lblRootPath.Size = new System.Drawing.Size(72, 16);
			this.lblRootPath.TabIndex = 9;
			this.lblRootPath.Text = "&Root Path:";
			// 
			// txtInitialPath
			// 
			this.txtInitialPath.Location = new System.Drawing.Point(80, 20);
			this.txtInitialPath.Name = "txtInitialPath";
			this.txtInitialPath.Size = new System.Drawing.Size(316, 21);
			this.txtInitialPath.TabIndex = 8;
			this.txtInitialPath.Text = "";
			// 
			// lblInitialPath
			// 
			this.lblInitialPath.Location = new System.Drawing.Point(8, 24);
			this.lblInitialPath.Name = "lblInitialPath";
			this.lblInitialPath.Size = new System.Drawing.Size(72, 16);
			this.lblInitialPath.TabIndex = 7;
			this.lblInitialPath.Text = "&Initial Path:";
			// 
			// grpDisplayProperties
			// 
			this.grpDisplayProperties.Controls.AddRange(new System.Windows.Forms.Control[] {
																							   this.txtStatusText,
																							   this.lblStatusText,
																							   this.txtTitle,
																							   this.lblTitle,
																							   this.chkFilter,
																							   this.chkIncludeFiles,
																							   this.chkNoNewFolder,
																							   this.chkValidateEditBox,
																							   this.chkEditBox,
																							   this.chkNewDialog});
			this.grpDisplayProperties.Location = new System.Drawing.Point(8, 104);
			this.grpDisplayProperties.Name = "grpDisplayProperties";
			this.grpDisplayProperties.Size = new System.Drawing.Size(408, 216);
			this.grpDisplayProperties.TabIndex = 9;
			this.grpDisplayProperties.TabStop = false;
			this.grpDisplayProperties.Text = "Display Properties";
			// 
			// chkNewDialog
			// 
			this.chkNewDialog.Checked = true;
			this.chkNewDialog.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkNewDialog.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.chkNewDialog.Location = new System.Drawing.Point(12, 24);
			this.chkNewDialog.Name = "chkNewDialog";
			this.chkNewDialog.Size = new System.Drawing.Size(380, 20);
			this.chkNewDialog.TabIndex = 8;
			this.chkNewDialog.Text = "&New Dialog Style";
			// 
			// chkEditBox
			// 
			this.chkEditBox.Checked = true;
			this.chkEditBox.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkEditBox.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.chkEditBox.Location = new System.Drawing.Point(28, 44);
			this.chkEditBox.Name = "chkEditBox";
			this.chkEditBox.Size = new System.Drawing.Size(356, 20);
			this.chkEditBox.TabIndex = 9;
			this.chkEditBox.Text = "&Edit Box";
			// 
			// chkValidateEditBox
			// 
			this.chkValidateEditBox.Checked = true;
			this.chkValidateEditBox.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkValidateEditBox.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.chkValidateEditBox.Location = new System.Drawing.Point(28, 64);
			this.chkValidateEditBox.Name = "chkValidateEditBox";
			this.chkValidateEditBox.Size = new System.Drawing.Size(356, 20);
			this.chkValidateEditBox.TabIndex = 10;
			this.chkValidateEditBox.Text = "&Validate Edit Box";
			// 
			// chkNoNewFolder
			// 
			this.chkNoNewFolder.Checked = true;
			this.chkNoNewFolder.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkNoNewFolder.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.chkNoNewFolder.Location = new System.Drawing.Point(28, 84);
			this.chkNoNewFolder.Name = "chkNoNewFolder";
			this.chkNoNewFolder.Size = new System.Drawing.Size(356, 20);
			this.chkNoNewFolder.TabIndex = 11;
			this.chkNoNewFolder.Text = "No &New Folder Button";
			// 
			// chkIncludeFiles
			// 
			this.chkIncludeFiles.Checked = true;
			this.chkIncludeFiles.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkIncludeFiles.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.chkIncludeFiles.Location = new System.Drawing.Point(28, 104);
			this.chkIncludeFiles.Name = "chkIncludeFiles";
			this.chkIncludeFiles.Size = new System.Drawing.Size(356, 20);
			this.chkIncludeFiles.TabIndex = 12;
			this.chkIncludeFiles.Text = "&Show Files";
			// 
			// chkFilter
			// 
			this.chkFilter.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.chkFilter.Checked = true;
			this.chkFilter.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkFilter.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.chkFilter.Location = new System.Drawing.Point(44, 124);
			this.chkFilter.Name = "chkFilter";
			this.chkFilter.Size = new System.Drawing.Size(340, 20);
			this.chkFilter.TabIndex = 13;
			this.chkFilter.Text = "&Filter Files (.jpg Files Only)";
			// 
			// txtStatusText
			// 
			this.txtStatusText.Location = new System.Drawing.Point(80, 172);
			this.txtStatusText.Name = "txtStatusText";
			this.txtStatusText.Size = new System.Drawing.Size(316, 21);
			this.txtStatusText.TabIndex = 17;
			this.txtStatusText.Text = "";
			// 
			// lblStatusText
			// 
			this.lblStatusText.Location = new System.Drawing.Point(8, 176);
			this.lblStatusText.Name = "lblStatusText";
			this.lblStatusText.Size = new System.Drawing.Size(72, 16);
			this.lblStatusText.TabIndex = 16;
			this.lblStatusText.Text = "&Status Text:";
			// 
			// txtTitle
			// 
			this.txtTitle.Location = new System.Drawing.Point(79, 148);
			this.txtTitle.Name = "txtTitle";
			this.txtTitle.Size = new System.Drawing.Size(316, 21);
			this.txtTitle.TabIndex = 15;
			this.txtTitle.Text = "Select file or folder to process.";
			// 
			// lblTitle
			// 
			this.lblTitle.Location = new System.Drawing.Point(8, 152);
			this.lblTitle.Name = "lblTitle";
			this.lblTitle.Size = new System.Drawing.Size(72, 16);
			this.lblTitle.TabIndex = 14;
			this.lblTitle.Text = "&Title:";
			// 
			// txtSelection
			// 
			this.txtSelection.BackColor = System.Drawing.SystemColors.Control;
			this.txtSelection.Location = new System.Drawing.Point(104, 328);
			this.txtSelection.Name = "txtSelection";
			this.txtSelection.ReadOnly = true;
			this.txtSelection.Size = new System.Drawing.Size(312, 21);
			this.txtSelection.TabIndex = 10;
			this.txtSelection.Text = "";
			// 
			// frmFolderBrowserTest
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(428, 466);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.txtSelection,
																		  this.grpDisplayProperties,
																		  this.grpFileProperties,
																		  this.lstEvents,
																		  this.btnShowDialog});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmFolderBrowserTest";
			this.Text = "FolderBrowser Tester";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.grpFileProperties.ResumeLayout(false);
			this.grpDisplayProperties.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region EntryPoint
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmFolderBrowserTest());
		}
		#endregion

		private void showDialog()
		{
			using (FolderBrowser f = new FolderBrowser())
			{			
				// Add events:
				EventHandler initEventHandler = new EventHandler(
					folderBrowser_Initialised);
				f.Initialized += initEventHandler;
				SelectionChangedEventHandler selChangeEventHandler = 
					new SelectionChangedEventHandler(
					folderBrowser_SelectionChanged);
				f.SelectionChanged += selChangeEventHandler;
				ValidationFailedEventHandler validationFailedEventHandler = 
					new ValidationFailedEventHandler(
					folderBrowser_ValidationFailed);
				f.ValidationFailed += validationFailedEventHandler;

				// Set main properties:
				f.Title = this.txtTitle.Text;
				f.StatusText = this.txtStatusText.Text;
				f.NewDialogStyle = (this.chkNewDialog.Checked);
				f.ShowEditBox = (this.chkEditBox.Checked);
				f.ValidateEditBox = (this.chkValidateEditBox.Checked);
				f.NoNewFolderButton = (this.chkNoNewFolder.Checked);
				f.IncludeFiles = (this.chkIncludeFiles.Checked);
				f.InitialPath = this.txtInitialPath.Text;
				f.RootPath = this.txtRootPath.Text;

				// Add a filter:
				f.Filter.ApplyFilter = (this.chkFilter.Checked);
				if (f.Filter.ApplyFilter)
				{
					f.Filter.Items.Add(
						new FileFilterSpecification(".jpg", true, false));
				}

				if (DialogResult.OK == f.ShowDialog(this))
				{
					txtSelection.Text = f.SelectedPath;
				}
				else
				{
					txtSelection.Text = "Dialog Cancelled";
				}

				// Remove events
				f.Initialized -= initEventHandler;
				f.SelectionChanged -= selChangeEventHandler;
				f.ValidationFailed -= validationFailedEventHandler;
			} // Dispose f
		}

		#region Event Response
		private void btnShowDialog_Click(object sender, System.EventArgs e)
		{
			showDialog();
		}

		private void folderBrowser_ValidationFailed(object sender, ValidationFailedEventArgs e)
		{
			lstEvents.Items.Add(
				String.Format("ValidationFailed: Message {0}", e.Message));
			lstEvents.SelectedIndex = lstEvents.Items.Count - 1;

			if (MessageBox.Show(this, 
				String.Format(
					"The path '{0}' could not be found.  Click Retry to correct or Cancel to exit.", 
					e.Message), 
				this.Text,
				MessageBoxButtons.RetryCancel,
				MessageBoxIcon.Warning) == DialogResult.Retry)
			{
				e.Cancel = false;
			}

		}

		private void folderBrowser_Initialised(object sender, System.EventArgs e)
		{
			lstEvents.Items.Add(
				String.Format("Initialised: hWnd={0}", ((FolderBrowser)sender).Handle));
			lstEvents.SelectedIndex = lstEvents.Items.Count - 1;

			// centre the dialog to this window:
			FolderBrowser f = (FolderBrowser)sender;
			Console.WriteLine("{0} {1}", this.Size.ToString(), f.Size.ToString());
			Size sz = f.Size;
			Point pt = new Point(
				Math.Max(0, this.Left + (this.Width - sz.Width)/2),
				Math.Max(0, this.Top + (this.Height - sz.Height)/2)
				);
			f.Position = pt;
		}

		private void folderBrowser_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			lstEvents.Items.Add(
				String.Format("Selection Changed: {0} {1}", e.Pidl, e.Path));
			lstEvents.SelectedIndex = lstEvents.Items.Count - 1;
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
		
		}
		#endregion

	}
}
