using System;
using System.Collections;
using System.IO;
using System.Runtime.InteropServices;

namespace vbAccelerator.Components.Shell
{
	#region RecentDocuments
	/// <summary>
	/// Provides methods to access the collection of Recent Documents
	/// </summary>
	public class RecentDocuments
	{

		private RecentDocumentCollection recentDocuments;

		/// <summary>
		/// Gets the recent documents path
		/// </summary>
		public string Path
		{
			get
			{
				return System.Environment.GetFolderPath(System.Environment.SpecialFolder.Recent);
			}
		}

		/// <summary>
		/// Gets the collection of recent documents on the system
		/// </summary>
		public RecentDocumentCollection Items
		{
			get
			{
				return recentDocuments;
			}
		}

		public RecentDocuments()
		{
			recentDocuments = new RecentDocumentCollection();
		}
	}
	#endregion

	#region RecentDocumentCollection
	public class RecentDocumentCollection : ReadOnlyCollectionBase
	{
		#region UnManagedCode
		private class UnManagedCode
		{
			internal enum SHARD_OPTIONS : int
			{
				SHARD_PIDL = 0x1,
				SHARD_PATHA = 0x2,
				SHARD_PATHW = 0x3
			}
			[DllImport("shell32", CharSet = CharSet.Auto, EntryPoint="SHAddToRecentDocs",  SetLastError=true)]	
			internal static extern void SHAddToRecentDocs(
				int uFlags, 
				[MarshalAs(UnmanagedType.LPTStr)]string pv 
				);
			[DllImport("shell32", CharSet = CharSet.Auto, EntryPoint="SHAddToRecentDocs",  SetLastError=true)]	
			internal static extern void SHClearRecentDocs(
				int uFlags, 
				IntPtr pv 
				);

		}
		#endregion

		/// <summary>
		/// Clears the current user's recent document list
		/// </summary>
		public void Clear()
		{
			int flag = (int)UnManagedCode.SHARD_OPTIONS.SHARD_PATHW;
			if (System.Environment.OSVersion.Platform != PlatformID.Win32NT)
			{
				flag = (int)UnManagedCode.SHARD_OPTIONS.SHARD_PATHA;
			}
			UnManagedCode.SHClearRecentDocs(flag, IntPtr.Zero);
		}

		/// <summary>
		/// Adds a file to the recent documents list
		/// </summary>
		/// <param name="file">The name of the file to add</param>
		public void Add(
			string file
			)
		{
			int flag = (int)UnManagedCode.SHARD_OPTIONS.SHARD_PATHW;
			if (System.Environment.OSVersion.Platform != PlatformID.Win32NT)
			{
				flag = (int)UnManagedCode.SHARD_OPTIONS.SHARD_PATHA;
			}
			UnManagedCode.SHAddToRecentDocs(flag, file);
			Refresh();
		}

		/// <summary>
		/// Refreshes the list of recent documents
		/// </summary>
		public void Refresh()
		{
			this.InnerList.Clear();

			string[] files = Directory.GetFiles(
				System.Environment.GetFolderPath(System.Environment.SpecialFolder.Recent));
			RecentDocument doc = null;
			foreach (string file in files)
			{
				if (System.IO.Path.GetExtension(file).ToUpper().Equals(".LNK"))
				{
					ShellLink link = new ShellLink(file);
					doc = new RecentDocument(file, link);
					this.InnerList.Add(doc);
				}
			}
		}

		/// <summary>
		/// Gets the recent document at the specified array index
		/// </summary>
		public RecentDocument this[int index]
		{
			get
			{
				return (RecentDocument)this.InnerList[index];
			}
		}

		internal RecentDocumentCollection() : base()
		{
			Refresh();
		}
	}
	#endregion

	#region RecentDocument
	public class RecentDocument
	{
		private string linkFile;
		private ShellLink shellLink;

		/// <summary>
		/// Gets the file name of the recent document shortcut
		/// </summary>
		public string LinkFile
		{
			get
			{
				return this.linkFile;
			}
		}

		/// <summary>
		/// Gets a ShellLink object containing the details of the
		/// recent document
		/// </summary>
		public ShellLink Link
		{
			get
			{
				return this.shellLink;
			}
		}

		/// <summary>
		/// Gets the creation time of the recent document item
		/// </summary>
		public DateTime CreationTime
		{
			get
			{
				return File.GetCreationTime(linkFile);
			}
		}

		/// <summary>
		/// Gets the last access time of the recent document item
		/// </summary>
		public DateTime LastAccessTime
		{
			get
			{
				return File.GetLastAccessTime(linkFile);
			}
		}

		/// <summary>
		/// Gets the last write time of the recent document item
		/// </summary>
		public DateTime LastWriteTime
		{
			get
			{
				return File.GetLastWriteTime(linkFile);
			}
		}
	

		internal RecentDocument(
			string linkFile,
			ShellLink shellLink
			)
		{
			this.linkFile = linkFile;
			this.shellLink = shellLink;
		}
	}
	#endregion
}
