using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

using vbAccelerator.Components.Shell;
using vbAccelerator.Controls.TextBox;

namespace vbAccelerator.Components.Shell.RecentDocumentsTester
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmRecentDocuments : System.Windows.Forms.Form
	{
		private RecentDocuments recentDocuments;

		private System.Windows.Forms.Label lblFile;
		private System.Windows.Forms.Label lblRecent;
		private System.Windows.Forms.Button btnPick;
		private System.Windows.Forms.Button btnAdd;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Button btnList;
		private AutoCompleteTextBox txtFile;
		private System.Windows.Forms.TextBox txtPath;
		private System.Windows.Forms.ListBox lstDocuments;
		private System.Windows.Forms.Label lblIcon;
		private System.Windows.Forms.TextBox txtArguments;
		private System.Windows.Forms.Label lblArguments;
		private vbAccelerator.Controls.TextBox.AutoCompleteTextBox txtTarget;
		private System.Windows.Forms.Label lblPath;
		private System.Windows.Forms.Label label1;
		private vbAccelerator.Controls.TextBox.AutoCompleteTextBox txtShortcut;
		private System.Windows.Forms.ImageList ilsLargeIcons;
		private System.Windows.Forms.ImageList ilsSmallIcons;
		private System.ComponentModel.IContainer components;

		public frmRecentDocuments()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Set up the form:
			//
			this.Paint += new PaintEventHandler(frmRecentDocuments_Paint);
			txtFile.AutoCompleteFlags = AutoCompleteTextBox.SHAutoCompleteFlags.SHACF_FILESYS_ONLY;
			recentDocuments = new RecentDocuments();
			txtPath.Text = recentDocuments.Path;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmRecentDocuments));
			this.lblFile = new System.Windows.Forms.Label();
			this.txtFile = new vbAccelerator.Controls.TextBox.AutoCompleteTextBox();
			this.txtPath = new System.Windows.Forms.TextBox();
			this.lblRecent = new System.Windows.Forms.Label();
			this.lstDocuments = new System.Windows.Forms.ListBox();
			this.btnPick = new System.Windows.Forms.Button();
			this.btnAdd = new System.Windows.Forms.Button();
			this.btnClear = new System.Windows.Forms.Button();
			this.btnList = new System.Windows.Forms.Button();
			this.lblIcon = new System.Windows.Forms.Label();
			this.txtArguments = new System.Windows.Forms.TextBox();
			this.lblArguments = new System.Windows.Forms.Label();
			this.txtTarget = new vbAccelerator.Controls.TextBox.AutoCompleteTextBox();
			this.lblPath = new System.Windows.Forms.Label();
			this.txtShortcut = new vbAccelerator.Controls.TextBox.AutoCompleteTextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.ilsLargeIcons = new System.Windows.Forms.ImageList(this.components);
			this.ilsSmallIcons = new System.Windows.Forms.ImageList(this.components);
			this.SuspendLayout();
			// 
			// lblFile
			// 
			this.lblFile.Location = new System.Drawing.Point(4, 4);
			this.lblFile.Name = "lblFile";
			this.lblFile.TabIndex = 0;
			this.lblFile.Text = "File to Add:";
			// 
			// txtFile
			// 
			this.txtFile.AutoCompleteFlags = vbAccelerator.Controls.TextBox.AutoCompleteTextBox.SHAutoCompleteFlags.SHACF_FILESYS_ONLY;
			this.txtFile.Location = new System.Drawing.Point(112, 4);
			this.txtFile.Name = "txtFile";
			this.txtFile.Size = new System.Drawing.Size(356, 21);
			this.txtFile.TabIndex = 1;
			this.txtFile.Text = "";
			// 
			// txtPath
			// 
			this.txtPath.BackColor = System.Drawing.SystemColors.Control;
			this.txtPath.Location = new System.Drawing.Point(112, 100);
			this.txtPath.Name = "txtPath";
			this.txtPath.ReadOnly = true;
			this.txtPath.Size = new System.Drawing.Size(384, 21);
			this.txtPath.TabIndex = 2;
			this.txtPath.Text = "";
			// 
			// lblRecent
			// 
			this.lblRecent.Location = new System.Drawing.Point(4, 100);
			this.lblRecent.Name = "lblRecent";
			this.lblRecent.Size = new System.Drawing.Size(100, 32);
			this.lblRecent.TabIndex = 3;
			this.lblRecent.Text = "Recent Documents:";
			// 
			// lstDocuments
			// 
			this.lstDocuments.Location = new System.Drawing.Point(112, 184);
			this.lstDocuments.Name = "lstDocuments";
			this.lstDocuments.Size = new System.Drawing.Size(384, 173);
			this.lstDocuments.TabIndex = 4;
			this.lstDocuments.SelectedIndexChanged += new System.EventHandler(this.lstDocuments_SelectedIndexChanged);
			// 
			// btnPick
			// 
			this.btnPick.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnPick.Location = new System.Drawing.Point(472, 4);
			this.btnPick.Name = "btnPick";
			this.btnPick.Size = new System.Drawing.Size(24, 23);
			this.btnPick.TabIndex = 5;
			this.btnPick.Text = "...";
			this.btnPick.Click += new System.EventHandler(this.btnPick_Click);
			// 
			// btnAdd
			// 
			this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnAdd.Location = new System.Drawing.Point(112, 32);
			this.btnAdd.Name = "btnAdd";
			this.btnAdd.Size = new System.Drawing.Size(100, 44);
			this.btnAdd.TabIndex = 6;
			this.btnAdd.Text = "&Add To Recent Documents";
			this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
			// 
			// btnClear
			// 
			this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnClear.Location = new System.Drawing.Point(220, 128);
			this.btnClear.Name = "btnClear";
			this.btnClear.Size = new System.Drawing.Size(100, 44);
			this.btnClear.TabIndex = 7;
			this.btnClear.Text = "&Clear Recent Documents";
			this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
			// 
			// btnList
			// 
			this.btnList.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnList.Location = new System.Drawing.Point(112, 128);
			this.btnList.Name = "btnList";
			this.btnList.Size = new System.Drawing.Size(100, 44);
			this.btnList.TabIndex = 8;
			this.btnList.Text = "&List Recent Documents";
			this.btnList.Click += new System.EventHandler(this.btnList_Click);
			// 
			// lblIcon
			// 
			this.lblIcon.Location = new System.Drawing.Point(32, 440);
			this.lblIcon.Name = "lblIcon";
			this.lblIcon.Size = new System.Drawing.Size(72, 16);
			this.lblIcon.TabIndex = 20;
			this.lblIcon.Text = "Icons:";
			// 
			// txtArguments
			// 
			this.txtArguments.BackColor = System.Drawing.SystemColors.Control;
			this.txtArguments.Location = new System.Drawing.Point(112, 412);
			this.txtArguments.Name = "txtArguments";
			this.txtArguments.ReadOnly = true;
			this.txtArguments.Size = new System.Drawing.Size(384, 21);
			this.txtArguments.TabIndex = 19;
			this.txtArguments.Text = "";
			// 
			// lblArguments
			// 
			this.lblArguments.Location = new System.Drawing.Point(32, 416);
			this.lblArguments.Name = "lblArguments";
			this.lblArguments.Size = new System.Drawing.Size(76, 16);
			this.lblArguments.TabIndex = 18;
			this.lblArguments.Text = "Arguments:";
			// 
			// txtTarget
			// 
			this.txtTarget.AutoCompleteFlags = vbAccelerator.Controls.TextBox.AutoCompleteTextBox.SHAutoCompleteFlags.SHACF_FILESYS_ONLY;
			this.txtTarget.BackColor = System.Drawing.SystemColors.Control;
			this.txtTarget.Location = new System.Drawing.Point(112, 388);
			this.txtTarget.Name = "txtTarget";
			this.txtTarget.ReadOnly = true;
			this.txtTarget.Size = new System.Drawing.Size(384, 21);
			this.txtTarget.TabIndex = 17;
			this.txtTarget.Text = "";
			// 
			// lblPath
			// 
			this.lblPath.Location = new System.Drawing.Point(32, 392);
			this.lblPath.Name = "lblPath";
			this.lblPath.Size = new System.Drawing.Size(76, 16);
			this.lblPath.TabIndex = 16;
			this.lblPath.Text = "Target:";
			// 
			// txtShortcut
			// 
			this.txtShortcut.AutoCompleteFlags = vbAccelerator.Controls.TextBox.AutoCompleteTextBox.SHAutoCompleteFlags.SHACF_FILESYS_ONLY;
			this.txtShortcut.BackColor = System.Drawing.SystemColors.Control;
			this.txtShortcut.Location = new System.Drawing.Point(112, 364);
			this.txtShortcut.Name = "txtShortcut";
			this.txtShortcut.ReadOnly = true;
			this.txtShortcut.Size = new System.Drawing.Size(384, 21);
			this.txtShortcut.TabIndex = 15;
			this.txtShortcut.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(32, 368);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(76, 16);
			this.label1.TabIndex = 14;
			this.label1.Text = "Shortcut:";
			// 
			// ilsLargeIcons
			// 
			this.ilsLargeIcons.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.ilsLargeIcons.ImageSize = new System.Drawing.Size(32, 32);
			this.ilsLargeIcons.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// ilsSmallIcons
			// 
			this.ilsSmallIcons.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.ilsSmallIcons.ImageSize = new System.Drawing.Size(16, 16);
			this.ilsSmallIcons.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// frmRecentDocuments
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(504, 506);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lblIcon,
																		  this.txtArguments,
																		  this.lblArguments,
																		  this.txtTarget,
																		  this.lblPath,
																		  this.txtShortcut,
																		  this.label1,
																		  this.btnList,
																		  this.btnClear,
																		  this.btnAdd,
																		  this.btnPick,
																		  this.lstDocuments,
																		  this.lblRecent,
																		  this.txtPath,
																		  this.txtFile,
																		  this.lblFile});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmRecentDocuments";
			this.Text = "Recent Documents Tester";
			this.Load += new System.EventHandler(this.frmRecentDocuments_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmRecentDocuments());
		}

		private void frmRecentDocuments_Load(object sender, System.EventArgs e)
		{
		
		}

		private void frmRecentDocuments_Paint(object sender, PaintEventArgs e)
		{
			// clear the icons area:
			Rectangle rc = new Rectangle(
				txtArguments.Left,
				lblIcon.Top,
				128,
				ilsLargeIcons.ImageSize.Height);
			e.Graphics.FillRectangle(SystemBrushes.Control, rc);

			// draw icons if they exist
			if (ilsLargeIcons.Images.Count > 0)
			{
				ilsLargeIcons.Draw(e.Graphics, rc.Left, rc.Top, 0);
			}
			if (ilsSmallIcons.Images.Count > 0)
			{
				ilsSmallIcons.Draw(e.Graphics, rc.Left + ilsLargeIcons.ImageSize.Width + 16, rc.Top, 0);
			}
		}

		private void btnPick_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog o = new OpenFileDialog();
			o.Filter = "All Files (*.*)|*.*";
			o.FilterIndex = 1;
			o.CheckFileExists = true;
			o.CheckPathExists = true;
			o.InitialDirectory = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
			if (o.ShowDialog(this) == DialogResult.OK)
			{
				this.txtFile.Text = o.FileName;
			}
		}

		private void btnAdd_Click(object sender, System.EventArgs e)
		{
			string file = txtFile.Text;
			if (File.Exists(file))
			{
				recentDocuments.Items.Add(file);
				displayRecentDocuments();
			}
			else
			{
				MessageBox.Show(this, 
					String.Format("The file '{0}' does not exist.", file),
					this.Text,
					MessageBoxButtons.OK,
					MessageBoxIcon.Exclamation);
			}
		}

		private void displayRecentDocuments()
		{
			lstDocuments.Items.Clear();
			ilsLargeIcons.Images.Clear();
			ilsSmallIcons.Images.Clear();
			txtShortcut.Text = "";
			txtTarget.Text = "";
			txtArguments.Text = "";
			
			recentDocuments.Items.Refresh();
			foreach (RecentDocument doc in recentDocuments.Items)
			{
				lstDocuments.Items.Add(doc.Link.Target);
			}

			if (lstDocuments.Items.Count > 0)
			{
				lstDocuments.SelectedIndex = 0;
			}
			else
			{
				this.Invalidate();
			}

		}

		private void btnList_Click(object sender, System.EventArgs e)
		{
			displayRecentDocuments();
		}

		private void lstDocuments_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (lstDocuments.Items.Count > 0)
			{
				int index = lstDocuments.SelectedIndex;
				RecentDocument doc = recentDocuments.Items[index];
				txtShortcut.Text = doc.LinkFile;
				txtTarget.Text = doc.Link.Target;
				txtArguments.Text = doc.Link.Arguments;
				Icon icon = doc.Link.LargeIcon;
				if (icon != null)
				{
					ilsLargeIcons.Images.Clear();
					ilsLargeIcons.Images.Add(icon);
					icon.Dispose();
				}
				icon = doc.Link.SmallIcon;
				if (icon != null)
				{
					ilsSmallIcons.Images.Clear();
					ilsSmallIcons.Images.Add(icon);
					icon.Dispose();
				}
				this.Invalidate();
			}
		}

		private void btnClear_Click(object sender, System.EventArgs e)
		{
			if (MessageBox.Show(this,
				"Are you sure you want to clear your recent documents list?",
				this.Text, 
				MessageBoxButtons.YesNo,
				MessageBoxIcon.Question, 
				MessageBoxDefaultButton.Button2) == DialogResult.Yes)
			{
				recentDocuments.Items.Clear();
				displayRecentDocuments();
			}
		}
	}
}
