using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Vbaccelerator.Components.Drawing;

namespace Vbaccelerator.Components.Drawing.Demonstration
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private HLSRGB hlsrgb;
		private Rectangle ColorSampleRect;
		private Rectangle ColorWheelRect;

		private System.Windows.Forms.TrackBar trkHue;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TrackBar trkLuminance;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TrackBar trkSaturation;
		private System.Windows.Forms.ComboBox cboColors;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			//
			ColorSampleRect = new Rectangle(172,16,108,92);
			ColorWheelRect = new Rectangle(ColorSampleRect.X, ColorSampleRect.Y, ColorSampleRect.Width, ColorSampleRect.Height);
			ColorWheelRect.Offset(0, ColorSampleRect.Height + 16);

			hlsrgb = new HLSRGB(Color.Goldenrod);
			trkHue.Value = (int)hlsrgb.Hue;
			trkLuminance.Value = (int)(hlsrgb.Luminance * 100);
			trkSaturation.Value = (int)(hlsrgb.Saturation * 100);

			trkHue.ValueChanged += new EventHandler(trkHue_ValueChanged);
			trkSaturation.ValueChanged += new EventHandler(trkSaturation_ValueChanged);
			trkLuminance.ValueChanged += new EventHandler(trkLuminance_ValueChanged);
			
			PopulateColors();

			cboColors.DrawMode = DrawMode.OwnerDrawFixed;
			cboColors.DrawItem += new DrawItemEventHandler(cboColors_DrawItem);
			cboColors.SelectedIndexChanged += new EventHandler(cboColors_SelectedIndexChanged);

			this.SetStyle(ControlStyles.AllPaintingInWmPaint | 
				ControlStyles.ResizeRedraw |
				ControlStyles.Opaque | 
				ControlStyles.UserPaint | 
				ControlStyles.DoubleBuffer, true);
		
		}

		private void PopulateColors()
		{
			cboColors.Items.Clear();

			Array arr = Enum.GetNames(typeof(System.Drawing.KnownColor));
			cboColors.Items.AddRange((object[])arr);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.trkHue = new System.Windows.Forms.TrackBar();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.trkLuminance = new System.Windows.Forms.TrackBar();
			this.label3 = new System.Windows.Forms.Label();
			this.trkSaturation = new System.Windows.Forms.TrackBar();
			this.cboColors = new System.Windows.Forms.ComboBox();
			((System.ComponentModel.ISupportInitialize)(this.trkHue)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trkLuminance)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trkSaturation)).BeginInit();
			this.SuspendLayout();
			// 
			// trkHue
			// 
			this.trkHue.LargeChange = 30;
			this.trkHue.Location = new System.Drawing.Point(16, 12);
			this.trkHue.Maximum = 360;
			this.trkHue.Name = "trkHue";
			this.trkHue.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.trkHue.Size = new System.Drawing.Size(34, 220);
			this.trkHue.TabIndex = 0;
			this.trkHue.TickFrequency = 10;
			this.trkHue.TickStyle = System.Windows.Forms.TickStyle.Both;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 236);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(56, 16);
			this.label1.TabIndex = 1;
			this.label1.Text = "Hue";
			this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(60, 236);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(56, 16);
			this.label2.TabIndex = 3;
			this.label2.Text = "Luminance";
			this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// trkLuminance
			// 
			this.trkLuminance.LargeChange = 10;
			this.trkLuminance.Location = new System.Drawing.Point(68, 12);
			this.trkLuminance.Maximum = 100;
			this.trkLuminance.Name = "trkLuminance";
			this.trkLuminance.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.trkLuminance.Size = new System.Drawing.Size(34, 220);
			this.trkLuminance.TabIndex = 2;
			this.trkLuminance.TickFrequency = 10;
			this.trkLuminance.TickStyle = System.Windows.Forms.TickStyle.Both;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(112, 236);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(56, 16);
			this.label3.TabIndex = 5;
			this.label3.Text = "Saturation";
			this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// trkSaturation
			// 
			this.trkSaturation.LargeChange = 10;
			this.trkSaturation.Location = new System.Drawing.Point(120, 12);
			this.trkSaturation.Maximum = 100;
			this.trkSaturation.Name = "trkSaturation";
			this.trkSaturation.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.trkSaturation.Size = new System.Drawing.Size(34, 220);
			this.trkSaturation.TabIndex = 4;
			this.trkSaturation.TickFrequency = 10;
			this.trkSaturation.TickStyle = System.Windows.Forms.TickStyle.Both;
			// 
			// cboColors
			// 
			this.cboColors.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cboColors.Location = new System.Drawing.Point(16, 264);
			this.cboColors.Name = "cboColors";
			this.cboColors.Size = new System.Drawing.Size(144, 21);
			this.cboColors.TabIndex = 7;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 305);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.cboColors,
																		  this.label3,
																		  this.trkSaturation,
																		  this.label2,
																		  this.trkLuminance,
																		  this.label1,
																		  this.trkHue});
			this.Name = "Form1";
			this.Text = "HLS - RGB Class Demonstration";
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.trkHue)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trkLuminance)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trkSaturation)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void cboColors_SelectedIndexChanged(object sender, EventArgs e)
		{
			int itemIndex = cboColors.SelectedIndex;
			if (itemIndex > -1)
			{
				string knownColorName = cboColors.Items[itemIndex].ToString();
				KnownColor k = (KnownColor)Enum.Parse(typeof(System.Drawing.KnownColor), knownColorName);
				Color color = Color.FromKnownColor(k);
				hlsrgb.Color = color;
				trkHue.Value = (int)hlsrgb.Hue;
				trkLuminance.Value = (int)(hlsrgb.Luminance * 100);
				trkSaturation.Value = (int)(hlsrgb.Saturation * 100);
			}
		}

		private void cboColors_DrawItem(object sender, DrawItemEventArgs d)
		{
			int itemIndex = d.Index;

			d.DrawBackground();

			if (itemIndex > -1)
			{
				string knownColorName = cboColors.Items[itemIndex].ToString();

				Rectangle textRectangle = d.Bounds;
				Rectangle colorRectangle = d.Bounds;			
				colorRectangle.X += 2;
				colorRectangle.Y += 2;
				colorRectangle.Width = 16;
				colorRectangle.Height -= 4;

				KnownColor k = (KnownColor)Enum.Parse(typeof(System.Drawing.KnownColor), knownColorName);
				Color color = Color.FromKnownColor(k);
				SolidBrush colorBrush = new SolidBrush(color);
				d.Graphics.FillRectangle(colorBrush, colorRectangle);
				colorBrush.Dispose();
				d.Graphics.DrawRectangle(SystemPens.ControlDarkDark, colorRectangle);

				textRectangle.X += 20;
				textRectangle.Width -= 20;

				Brush textBrush;
				if ((d.State & DrawItemState.Selected) == DrawItemState.Selected)
				{
					textBrush = SystemBrushes.HighlightText;
				}
				else
				{
					textBrush = SystemBrushes.ControlText;
				}
				d.Graphics.DrawString(knownColorName, d.Font, textBrush, textRectangle);
			}

			if ((d.State & DrawItemState.Focus) == DrawItemState.Focus)
			{
				d.DrawFocusRectangle();
			}

		}

		protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
		{
			base.OnPaint(e);
			e.Graphics.FillRectangle(SystemBrushes.Control, e.ClipRectangle);
			if (e.ClipRectangle.IntersectsWith(ColorSampleRect))
			{
				DrawColorSample(ColorSampleRect, e.Graphics);
			}
			if (e.ClipRectangle.IntersectsWith(ColorWheelRect))
			{
				DrawColorWheel(ColorWheelRect, e.Graphics);
			}
			e.Graphics.Flush();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
		
		}

		private void trkHue_ValueChanged(object sender, EventArgs e)
		{
			hlsrgb.Hue = trkHue.Value;
			ShowColor();
		}

		private void trkSaturation_ValueChanged(object sender, EventArgs e)
		{
			hlsrgb.Saturation = trkSaturation.Value/100f;
			ShowColor();
		}

		private void trkLuminance_ValueChanged(object sender, EventArgs e)
		{
			hlsrgb.Luminance = trkLuminance.Value/100f;
			ShowColor();
		}

		private void ShowColor()
		{
			this.Invalidate(ColorSampleRect);
			this.Invalidate(ColorWheelRect);
		}

		private void DrawColorSample(Rectangle rect, Graphics gfx)
		{
			// Fill background
			gfx.FillRectangle(SystemBrushes.Control, rect);

			// draw border
			gfx.DrawLine(SystemPens.ControlDark, rect.X, rect.Y + rect.Height, rect.X, rect.Y);
			gfx.DrawLine(SystemPens.ControlDark, rect.X, rect.Y, rect.X + rect.Width, rect.Y);
			gfx.DrawLine(SystemPens.ControlLightLight, rect.X + rect.Width, rect.Y + 1, rect.X + rect.Width, rect.Y + rect.Height);
			gfx.DrawLine(SystemPens.ControlLightLight, rect.X + rect.Width, rect.Y + rect.Height, rect.X + 1, rect.Y + rect.Height);

			// draw color sample:
			SolidBrush colorBrush = new SolidBrush(hlsrgb.Color);
			gfx.FillRectangle(colorBrush, rect.X + 1, rect.Y + 1, rect.Width - 2, rect.Height - 2);
			colorBrush.Dispose();
			
		}

		private void DrawColorWheel(Rectangle rect, Graphics gfx)
		{

			// Fill background:
			Brush backBrush = SystemBrushes.Control;
			gfx.FillRectangle(backBrush, rect);
			
			// Determine range and centre of the circle:
			int  border  = Math.Min(rect.Width, rect.Height);
			double border2 = border / 2;
			Point ptCentre = new Point();
			ptCentre.X = (int)(border / 2 + 1); // Middle point
			ptCentre.Y = ptCentre.X;

			// Define start color:
			HLSRGB color = new HLSRGB((float)trkHue.Value, (float)trkLuminance.Value/100, (float)trkSaturation.Value/100);

			// Determine circle edge points and colors:
			Point[] pt = new Point[360];
			HLSRGB[] colors = new HLSRGB[360];
			float hue = color.Hue;
			for (int i = 359; i >= 0; i--)
			{
				// Determine color:
				hue += 1.0f;
				if (hue > 360.0f) 
				{
					hue -= 360.0f;
				}
				colors[i] = new HLSRGB(hue, color.Luminance, color.Saturation);

				// Determine new point on circle:
				pt[i].X = rect.X + (int)(ptCentre.X - Math.Cos(Math.PI * i / 180.0) * border2);
				pt[i].Y = rect.Y + (int)(ptCentre.Y - Math.Sin(Math.PI * i / 180.0) * border2);
			}

			ptCentre.Offset(rect.X, rect.Y);

			// Draw the circle using thick lines:
			for (int i = 359; i >= 0; i--)
			{
				Pen colorPen = new Pen(colors[i].Color, 2f);
				gfx.DrawLine(colorPen, pt[i], ptCentre);
				colorPen.Dispose();
			}

			// Draw using thin lines;
			for (int i = 359; i >= 0; i--)
			{
				Pen colorPen = new Pen(colors[i].Color, 1);
				gfx.DrawLine(colorPen, pt[i], ptCentre);
				colorPen.Dispose();
			}

		}


	}
}
