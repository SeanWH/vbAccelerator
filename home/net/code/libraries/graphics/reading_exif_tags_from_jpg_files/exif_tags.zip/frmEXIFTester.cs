using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using vbAccelerator.Components.ListBox;
using vbAccelerator.Components.Shell;

namespace EXIFTags
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmEXIFTester : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Panel pnlTools;
		private System.Windows.Forms.Label lblFolder;
		private System.Windows.Forms.TextBox txtFolder;
		private System.Windows.Forms.Button btnPick;
		private System.Windows.Forms.StatusBar sbrMain;
		private vbAccelerator.Components.ListBox.EXIFListBox listBox1;
		private System.Windows.Forms.StatusBarPanel spnlProgress;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmEXIFTester()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.listBox1.Progress += new ProgressEventHandler(lstEXIF_Progress);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmEXIFTester));
			this.pnlTools = new System.Windows.Forms.Panel();
			this.btnPick = new System.Windows.Forms.Button();
			this.txtFolder = new System.Windows.Forms.TextBox();
			this.lblFolder = new System.Windows.Forms.Label();
			this.sbrMain = new System.Windows.Forms.StatusBar();
			this.spnlProgress = new System.Windows.Forms.StatusBarPanel();
			this.listBox1 = new vbAccelerator.Components.ListBox.EXIFListBox();
			this.pnlTools.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.spnlProgress)).BeginInit();
			this.SuspendLayout();
			// 
			// pnlTools
			// 
			this.pnlTools.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.btnPick,
																				   this.txtFolder,
																				   this.lblFolder});
			this.pnlTools.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnlTools.Name = "pnlTools";
			this.pnlTools.Size = new System.Drawing.Size(480, 40);
			this.pnlTools.TabIndex = 1;
			this.pnlTools.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlTools_Paint);
			// 
			// btnPick
			// 
			this.btnPick.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnPick.Location = new System.Drawing.Point(424, 8);
			this.btnPick.Name = "btnPick";
			this.btnPick.Size = new System.Drawing.Size(52, 24);
			this.btnPick.TabIndex = 2;
			this.btnPick.Text = "&Pick...";
			this.btnPick.Click += new System.EventHandler(this.btnPick_Click);
			// 
			// txtFolder
			// 
			this.txtFolder.Location = new System.Drawing.Point(64, 8);
			this.txtFolder.Name = "txtFolder";
			this.txtFolder.Size = new System.Drawing.Size(356, 21);
			this.txtFolder.TabIndex = 1;
			this.txtFolder.Text = "";
			// 
			// lblFolder
			// 
			this.lblFolder.Location = new System.Drawing.Point(8, 12);
			this.lblFolder.Name = "lblFolder";
			this.lblFolder.Size = new System.Drawing.Size(52, 16);
			this.lblFolder.TabIndex = 0;
			this.lblFolder.Text = "&Folder:";
			// 
			// sbrMain
			// 
			this.sbrMain.Location = new System.Drawing.Point(0, 500);
			this.sbrMain.Name = "sbrMain";
			this.sbrMain.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																					   this.spnlProgress});
			this.sbrMain.ShowPanels = true;
			this.sbrMain.Size = new System.Drawing.Size(480, 22);
			this.sbrMain.TabIndex = 4;
			// 
			// spnlProgress
			// 
			this.spnlProgress.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.spnlProgress.Text = "Ready.";
			this.spnlProgress.Width = 464;
			// 
			// listBox1
			// 
			this.listBox1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.listBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
			this.listBox1.ItemHeight = 149;
			this.listBox1.Location = new System.Drawing.Point(0, 40);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(480, 460);
			this.listBox1.TabIndex = 5;
			this.listBox1.ThumbNailSize = new System.Drawing.Size(100, 100);
			// 
			// frmEXIFTester
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(480, 522);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.listBox1,
																		  this.sbrMain,
																		  this.pnlTools});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmEXIFTester";
			this.Text = "Asynchronous EXIF File Tag Demonstration";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.pnlTools.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.spnlProgress)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmEXIFTester());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			//this.listBox1.AddFolder(txtFolder.Text);
		}

		private void pnlTools_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
		
		}

		private void btnPick_Click(object sender, System.EventArgs e)
		{
			using (FolderBrowser f = new FolderBrowser())
			{
				f.NewDialogStyle = true;
				f.ValidateEditBox = true;
				f.InitialPath = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
				f.FileSystemDirectoriesOnly = true;
				if (DialogResult.OK == f.ShowDialog(this))
				{
					txtFolder.Text = f.SelectedPath;
					this.listBox1.AddFolder(txtFolder.Text);
				}
			}

		}

		private void lstEXIF_Progress(object sender, ProgressEventArgs p)
		{
			if (p.Complete)
			{
				spnlProgress.Text = "Ready";
			}
			else
			{
				spnlProgress.Text = 
					String.Format("Processing {0} of {1}, {2}",
					p.Item,p.Count, p.File);
			}
		}
	}
}
