using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using vbAccelerator.Components.Win32;

namespace EnumWindowsTester
{
	/// <summary>
	/// Summary description for frmWindowDetail.
	/// </summary>
	public class frmWindowDetail : System.Windows.Forms.Form
	{
		private EnumWindowsItem window = null;

		private System.Windows.Forms.Label lblCaption;
		private System.Windows.Forms.TextBox txtCaption;
		private System.Windows.Forms.TextBox txtClassName;
		private System.Windows.Forms.Label lblClassName;
		private System.Windows.Forms.TextBox txtPosition;
		private System.Windows.Forms.Label lblRectangle;
		private System.Windows.Forms.CheckBox chkVisible;
		private System.Windows.Forms.CheckBox chkIconic;
		private System.Windows.Forms.CheckBox chkMaximised;
		private System.Windows.Forms.TextBox txtStyles;
		private System.Windows.Forms.Label lblStyles;
		private System.Windows.Forms.ListBox lstStyles;
		private System.Windows.Forms.ListBox lstExtendedStyles;
		private System.Windows.Forms.TextBox txtExtendedStyles;
		private System.Windows.Forms.Label lblExtendedStyles;
		private System.Windows.Forms.Button btnOK;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmWindowDetail(EnumWindowsItem item)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.window = item;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmWindowDetail));
			this.lblCaption = new System.Windows.Forms.Label();
			this.txtCaption = new System.Windows.Forms.TextBox();
			this.txtClassName = new System.Windows.Forms.TextBox();
			this.lblClassName = new System.Windows.Forms.Label();
			this.txtPosition = new System.Windows.Forms.TextBox();
			this.lblRectangle = new System.Windows.Forms.Label();
			this.chkVisible = new System.Windows.Forms.CheckBox();
			this.chkIconic = new System.Windows.Forms.CheckBox();
			this.chkMaximised = new System.Windows.Forms.CheckBox();
			this.txtStyles = new System.Windows.Forms.TextBox();
			this.lblStyles = new System.Windows.Forms.Label();
			this.lstStyles = new System.Windows.Forms.ListBox();
			this.lstExtendedStyles = new System.Windows.Forms.ListBox();
			this.txtExtendedStyles = new System.Windows.Forms.TextBox();
			this.lblExtendedStyles = new System.Windows.Forms.Label();
			this.btnOK = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblCaption
			// 
			this.lblCaption.Location = new System.Drawing.Point(4, 12);
			this.lblCaption.Name = "lblCaption";
			this.lblCaption.Size = new System.Drawing.Size(72, 16);
			this.lblCaption.TabIndex = 0;
			this.lblCaption.Text = "&Caption:";
			// 
			// txtCaption
			// 
			this.txtCaption.Location = new System.Drawing.Point(80, 8);
			this.txtCaption.Name = "txtCaption";
			this.txtCaption.Size = new System.Drawing.Size(288, 21);
			this.txtCaption.TabIndex = 1;
			this.txtCaption.Text = "";
			// 
			// txtClassName
			// 
			this.txtClassName.Location = new System.Drawing.Point(80, 32);
			this.txtClassName.Name = "txtClassName";
			this.txtClassName.Size = new System.Drawing.Size(288, 21);
			this.txtClassName.TabIndex = 3;
			this.txtClassName.Text = "";
			// 
			// lblClassName
			// 
			this.lblClassName.Location = new System.Drawing.Point(4, 36);
			this.lblClassName.Name = "lblClassName";
			this.lblClassName.Size = new System.Drawing.Size(72, 16);
			this.lblClassName.TabIndex = 2;
			this.lblClassName.Text = "&Class:";
			// 
			// txtPosition
			// 
			this.txtPosition.Location = new System.Drawing.Point(80, 56);
			this.txtPosition.Name = "txtPosition";
			this.txtPosition.Size = new System.Drawing.Size(288, 21);
			this.txtPosition.TabIndex = 5;
			this.txtPosition.Text = "";
			// 
			// lblRectangle
			// 
			this.lblRectangle.Location = new System.Drawing.Point(4, 60);
			this.lblRectangle.Name = "lblRectangle";
			this.lblRectangle.Size = new System.Drawing.Size(72, 16);
			this.lblRectangle.TabIndex = 4;
			this.lblRectangle.Text = "&Position";
			// 
			// chkVisible
			// 
			this.chkVisible.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.chkVisible.Location = new System.Drawing.Point(80, 84);
			this.chkVisible.Name = "chkVisible";
			this.chkVisible.Size = new System.Drawing.Size(288, 16);
			this.chkVisible.TabIndex = 6;
			this.chkVisible.Text = "Visible";
			// 
			// chkIconic
			// 
			this.chkIconic.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.chkIconic.Location = new System.Drawing.Point(80, 104);
			this.chkIconic.Name = "chkIconic";
			this.chkIconic.Size = new System.Drawing.Size(288, 16);
			this.chkIconic.TabIndex = 7;
			this.chkIconic.Text = "Iconic";
			// 
			// chkMaximised
			// 
			this.chkMaximised.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.chkMaximised.Location = new System.Drawing.Point(80, 124);
			this.chkMaximised.Name = "chkMaximised";
			this.chkMaximised.Size = new System.Drawing.Size(288, 16);
			this.chkMaximised.TabIndex = 8;
			this.chkMaximised.Text = "Maximised";
			// 
			// txtStyles
			// 
			this.txtStyles.Location = new System.Drawing.Point(80, 152);
			this.txtStyles.Name = "txtStyles";
			this.txtStyles.Size = new System.Drawing.Size(288, 21);
			this.txtStyles.TabIndex = 10;
			this.txtStyles.Text = "";
			// 
			// lblStyles
			// 
			this.lblStyles.Location = new System.Drawing.Point(4, 156);
			this.lblStyles.Name = "lblStyles";
			this.lblStyles.Size = new System.Drawing.Size(72, 16);
			this.lblStyles.TabIndex = 9;
			this.lblStyles.Text = "&Styles:";
			// 
			// lstStyles
			// 
			this.lstStyles.Location = new System.Drawing.Point(80, 180);
			this.lstStyles.Name = "lstStyles";
			this.lstStyles.Size = new System.Drawing.Size(288, 95);
			this.lstStyles.TabIndex = 11;
			// 
			// lstExtendedStyles
			// 
			this.lstExtendedStyles.Location = new System.Drawing.Point(82, 308);
			this.lstExtendedStyles.Name = "lstExtendedStyles";
			this.lstExtendedStyles.Size = new System.Drawing.Size(288, 95);
			this.lstExtendedStyles.TabIndex = 14;
			// 
			// txtExtendedStyles
			// 
			this.txtExtendedStyles.Location = new System.Drawing.Point(82, 280);
			this.txtExtendedStyles.Name = "txtExtendedStyles";
			this.txtExtendedStyles.Size = new System.Drawing.Size(288, 21);
			this.txtExtendedStyles.TabIndex = 13;
			this.txtExtendedStyles.Text = "";
			// 
			// lblExtendedStyles
			// 
			this.lblExtendedStyles.Location = new System.Drawing.Point(6, 284);
			this.lblExtendedStyles.Name = "lblExtendedStyles";
			this.lblExtendedStyles.Size = new System.Drawing.Size(72, 32);
			this.lblExtendedStyles.TabIndex = 12;
			this.lblExtendedStyles.Text = "&Extended Styles:";
			// 
			// btnOK
			// 
			this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnOK.Location = new System.Drawing.Point(280, 412);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(88, 28);
			this.btnOK.TabIndex = 16;
			this.btnOK.Text = "OK";
			// 
			// frmWindowDetail
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(376, 448);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnOK,
																		  this.lstExtendedStyles,
																		  this.txtExtendedStyles,
																		  this.lblExtendedStyles,
																		  this.lstStyles,
																		  this.txtStyles,
																		  this.lblStyles,
																		  this.chkMaximised,
																		  this.chkIconic,
																		  this.chkVisible,
																		  this.txtPosition,
																		  this.lblRectangle,
																		  this.txtClassName,
																		  this.lblClassName,
																		  this.txtCaption,
																		  this.lblCaption});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmWindowDetail";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "frmWindowDetail";
			this.Load += new System.EventHandler(this.frmWindowDetail_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void frmWindowDetail_Load(object sender, System.EventArgs e)
		{
			if (window != null)
			{
				this.txtCaption.Text = window.Text;
				this.txtClassName.Text = window.ClassName;
				this.txtPosition.Text = String.Format(
					"({0},{1})-({2},{3})",
					window.Rect.Left, window.Rect.Top,
					window.Rect.Width - window.Rect.Left, 
					window.Rect.Height - window.Rect.Top);
				this.chkIconic.Checked = window.Iconic;
				this.chkVisible.Checked = window.Visible;
				this.chkMaximised.Checked = window.Maximised;
				this.txtStyles.Text = String.Format(
					"{0:x8}", (uint)window.WindowStyle);
				string[] styles = Enum.GetNames(typeof(WindowStyleFlags));
				foreach (string style in styles)
				{
					WindowStyleFlags flag = (WindowStyleFlags)Enum.Parse(
						typeof(WindowStyleFlags),
						style, true);
					if ((flag & window.WindowStyle) == flag)
					{
						lstStyles.Items.Add(style);
					}
				}
				this.txtExtendedStyles.Text = String.Format(
					"{0:x8}", (uint)window.ExtendedWindowStyle);
				styles = Enum.GetNames(typeof(ExtendedWindowStyleFlags));
				foreach (string style in styles)
				{
					ExtendedWindowStyleFlags flag = (ExtendedWindowStyleFlags)Enum.Parse(
						typeof(ExtendedWindowStyleFlags),
						style, true);
					if ((flag & window.ExtendedWindowStyle) == flag)
					{
						lstExtendedStyles.Items.Add(style);
					}
				}
			}
		}
	}
}
