using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text.RegularExpressions;

using vbAccelerator.Components.Win32;

namespace EnumWindowsTester
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmEnumWindows : System.Windows.Forms.Form
	{
		private bool visibleOnly = false;
		private System.Windows.Forms.ToolBar tbrMain;
		private System.Windows.Forms.StatusBar sbrMain;
		private System.Windows.Forms.ToolBarButton tbbRefresh;
		private System.Windows.Forms.ToolBarButton tbbFind;
		private System.Windows.Forms.ToolBarButton tbbVisible;
		private System.Windows.Forms.TreeView tvwWindows;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmEnumWindows()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// Add TreeView events:
			tvwWindows.BeforeExpand += new TreeViewCancelEventHandler(tvwWindows_BeforeExpand);
			tvwWindows.DoubleClick += new EventHandler(tvwWindows_DoubleClick);
		}
 
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmEnumWindows));
			this.tbrMain = new System.Windows.Forms.ToolBar();
			this.tbbRefresh = new System.Windows.Forms.ToolBarButton();
			this.tbbFind = new System.Windows.Forms.ToolBarButton();
			this.sbrMain = new System.Windows.Forms.StatusBar();
			this.tbbVisible = new System.Windows.Forms.ToolBarButton();
			this.tvwWindows = new System.Windows.Forms.TreeView();
			this.SuspendLayout();
			// 
			// tbrMain
			// 
			this.tbrMain.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																					   this.tbbRefresh,
																					   this.tbbFind,
																					   this.tbbVisible});
			this.tbrMain.ButtonSize = new System.Drawing.Size(128, 22);
			this.tbrMain.DropDownArrows = true;
			this.tbrMain.Name = "tbrMain";
			this.tbrMain.ShowToolTips = true;
			this.tbrMain.Size = new System.Drawing.Size(704, 25);
			this.tbrMain.TabIndex = 1;
			this.tbrMain.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right;
			this.tbrMain.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.tbrMain_ButtonClick);
			// 
			// tbbRefresh
			// 
			this.tbbRefresh.Tag = "REFRESH";
			this.tbbRefresh.Text = "Refresh";
			// 
			// tbbFind
			// 
			this.tbbFind.Tag = "FIND";
			this.tbbFind.Text = "Find Window";
			// 
			// sbrMain
			// 
			this.sbrMain.Location = new System.Drawing.Point(0, 444);
			this.sbrMain.Name = "sbrMain";
			this.sbrMain.Size = new System.Drawing.Size(704, 22);
			this.sbrMain.TabIndex = 2;
			this.sbrMain.Text = " Window Enumeration Demonstration";
			// 
			// tbbVisible
			// 
			this.tbbVisible.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.tbbVisible.Tag = "VISIBLE";
			this.tbbVisible.Text = "Visible Only";
			// 
			// tvwWindows
			// 
			this.tvwWindows.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tvwWindows.ImageIndex = -1;
			this.tvwWindows.Location = new System.Drawing.Point(0, 25);
			this.tvwWindows.Name = "tvwWindows";
			this.tvwWindows.SelectedImageIndex = -1;
			this.tvwWindows.Size = new System.Drawing.Size(704, 419);
			this.tvwWindows.TabIndex = 3;
			// 
			// frmEnumWindows
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(704, 466);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.tvwWindows,
																		  this.sbrMain,
																		  this.tbrMain});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmEnumWindows";
			this.Text = "Window Enumeration Demonstration";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmEnumWindows());
		}

		private void tbrMain_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
			string tag = (string)e.Button.Tag;
			visibleOnly = tbrMain.Buttons[2].Pushed;
			if (tag.Equals("REFRESH"))
			{				
				enumWindows();
			}
			else if (tag.Equals("FIND"))
			{
				findWindow();
			}
			else if (tag.Equals("VISIBLE"))
			{
				enumWindows();
			}
		}

		private void tvwWindows_DoubleClick(object sender, EventArgs e)
		{
			if (tvwWindows.SelectedNode != null)
			{
				EnumWindowsItem item = 
					(EnumWindowsItem)tvwWindows.SelectedNode.Tag;
				frmWindowDetail fwd = new frmWindowDetail(item);
				fwd.ShowDialog(this);
			}
		}

		private void tvwWindows_BeforeExpand(object sender, TreeViewCancelEventArgs e)
		{
			if (e.Node.FirstNode.Text.Equals("EXPAND ME"))
			{
				EnumWindowsItem item = 
					(EnumWindowsItem)e.Node.Tag;
				EnumWindows eW = new EnumWindows();
				// note that this isn't perfect since
				// EnumChildWindows also returns all children owned
				// by the child windows that get enumerated. Hence
				// the same child can appear at more than one
				// level in the branch.  Good for finding items
				// though.
				eW.GetWindows(item.Handle);
				foreach (EnumWindowsItem subWin in eW.Items)
				{
					bool add = true;
					if (visibleOnly)
					{
						add = (subWin.Visible);
					}
					if (add)
					{						
						TreeNode[] fakeChild = new TreeNode[1] {new TreeNode("EXPAND ME")};
						TreeNode nod = new TreeNode(
							String.Format("{0:x8} '{1}' {2}", 
							(int)subWin.Handle, 
							subWin.Text, 
							subWin.ClassName),
							fakeChild);
						nod.Tag = subWin;					
						e.Node.Nodes.Add(nod);
					}
				}
				e.Node.Nodes.Remove(e.Node.FirstNode);
			}
		}

		private void findWindow()
		{
			frmFindWindow fw = new frmFindWindow();
			fw.ShowDialog(this);

		}

		private void enumWindows()
		{
			tvwWindows.Nodes.Clear();

			EnumWindows eW = new EnumWindows();
			eW.GetWindows();
			foreach (EnumWindowsItem item in eW.Items)
			{
				bool add = true;
				if (visibleOnly)
				{
					add = (item.Visible);
				}
				if (add)
				{
					TreeNode[] fakeChild = new TreeNode[1] {new TreeNode("EXPAND ME")};
					TreeNode nod = new TreeNode(
						String.Format("{0:x8} '{1}' {2}", 
						(int)item.Handle, 
						item.Text, 
						item.ClassName),
						fakeChild);
					nod.Tag = item;
					tvwWindows.Nodes.Add(nod);	
				}
			}
		}


	}
}
