using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using vbAccelerator.Components.Win32;

namespace EnumWindowsTester
{
	/// <summary>
	/// Summary description for frmFindWindow.
	/// </summary>
	public class frmFindWindow : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label lblOr;
		private System.Windows.Forms.ListBox lstResults;
		private System.Windows.Forms.Button btnFind;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.GroupBox grpExpression;
		private System.Windows.Forms.TextBox txtClassName;
		private System.Windows.Forms.Label lblClassName;
		private System.Windows.Forms.TextBox txtCaption;
		private System.Windows.Forms.Label lblCaption;
		private System.Windows.Forms.GroupBox grpHandle;
		private System.Windows.Forms.TextBox txtHandle;
		private System.Windows.Forms.Label lblHandle;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmFindWindow()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblOr = new System.Windows.Forms.Label();
			this.lstResults = new System.Windows.Forms.ListBox();
			this.btnFind = new System.Windows.Forms.Button();
			this.btnOK = new System.Windows.Forms.Button();
			this.grpExpression = new System.Windows.Forms.GroupBox();
			this.txtClassName = new System.Windows.Forms.TextBox();
			this.lblClassName = new System.Windows.Forms.Label();
			this.txtCaption = new System.Windows.Forms.TextBox();
			this.lblCaption = new System.Windows.Forms.Label();
			this.grpHandle = new System.Windows.Forms.GroupBox();
			this.txtHandle = new System.Windows.Forms.TextBox();
			this.lblHandle = new System.Windows.Forms.Label();
			this.grpExpression.SuspendLayout();
			this.grpHandle.SuspendLayout();
			this.SuspendLayout();
			// 
			// lblOr
			// 
			this.lblOr.Location = new System.Drawing.Point(12, 88);
			this.lblOr.Name = "lblOr";
			this.lblOr.Size = new System.Drawing.Size(100, 16);
			this.lblOr.TabIndex = 10;
			this.lblOr.Text = "Or:";
			// 
			// lstResults
			// 
			this.lstResults.Location = new System.Drawing.Point(8, 220);
			this.lstResults.Name = "lstResults";
			this.lstResults.Size = new System.Drawing.Size(364, 199);
			this.lstResults.TabIndex = 11;
			// 
			// btnFind
			// 
			this.btnFind.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnFind.Location = new System.Drawing.Point(92, 176);
			this.btnFind.Name = "btnFind";
			this.btnFind.Size = new System.Drawing.Size(88, 28);
			this.btnFind.TabIndex = 12;
			this.btnFind.Text = "&Find Now";
			this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
			// 
			// btnOK
			// 
			this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnOK.Location = new System.Drawing.Point(280, 428);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(92, 28);
			this.btnOK.TabIndex = 13;
			this.btnOK.Text = "OK";
			// 
			// grpExpression
			// 
			this.grpExpression.Controls.AddRange(new System.Windows.Forms.Control[] {
																						this.txtClassName,
																						this.lblClassName,
																						this.txtCaption,
																						this.lblCaption});
			this.grpExpression.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.grpExpression.Location = new System.Drawing.Point(8, 8);
			this.grpExpression.Name = "grpExpression";
			this.grpExpression.Size = new System.Drawing.Size(364, 76);
			this.grpExpression.TabIndex = 14;
			this.grpExpression.TabStop = false;
			this.grpExpression.Text = "Search By &Regular Expression";
			// 
			// txtClassName
			// 
			this.txtClassName.Location = new System.Drawing.Point(84, 44);
			this.txtClassName.Name = "txtClassName";
			this.txtClassName.Size = new System.Drawing.Size(272, 21);
			this.txtClassName.TabIndex = 11;
			this.txtClassName.Text = "";
			// 
			// lblClassName
			// 
			this.lblClassName.Location = new System.Drawing.Point(8, 48);
			this.lblClassName.Name = "lblClassName";
			this.lblClassName.Size = new System.Drawing.Size(72, 16);
			this.lblClassName.TabIndex = 10;
			this.lblClassName.Text = "&Class:";
			// 
			// txtCaption
			// 
			this.txtCaption.Location = new System.Drawing.Point(84, 20);
			this.txtCaption.Name = "txtCaption";
			this.txtCaption.Size = new System.Drawing.Size(272, 21);
			this.txtCaption.TabIndex = 9;
			this.txtCaption.Text = "";
			// 
			// lblCaption
			// 
			this.lblCaption.Location = new System.Drawing.Point(8, 24);
			this.lblCaption.Name = "lblCaption";
			this.lblCaption.Size = new System.Drawing.Size(72, 16);
			this.lblCaption.TabIndex = 8;
			this.lblCaption.Text = "&Caption:";
			// 
			// grpHandle
			// 
			this.grpHandle.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.txtHandle,
																					this.lblHandle});
			this.grpHandle.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.grpHandle.Location = new System.Drawing.Point(8, 108);
			this.grpHandle.Name = "grpHandle";
			this.grpHandle.Size = new System.Drawing.Size(364, 56);
			this.grpHandle.TabIndex = 15;
			this.grpHandle.TabStop = false;
			this.grpHandle.Text = "Search By &Handle";
			// 
			// txtHandle
			// 
			this.txtHandle.Location = new System.Drawing.Point(84, 28);
			this.txtHandle.Name = "txtHandle";
			this.txtHandle.Size = new System.Drawing.Size(272, 21);
			this.txtHandle.TabIndex = 11;
			this.txtHandle.Text = "";
			// 
			// lblHandle
			// 
			this.lblHandle.Location = new System.Drawing.Point(8, 32);
			this.lblHandle.Name = "lblHandle";
			this.lblHandle.Size = new System.Drawing.Size(72, 16);
			this.lblHandle.TabIndex = 10;
			this.lblHandle.Text = "&Handle:";
			// 
			// frmFindWindow
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(380, 460);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.grpHandle,
																		  this.grpExpression,
																		  this.btnOK,
																		  this.btnFind,
																		  this.lstResults,
																		  this.lblOr});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmFindWindow";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Find Window";
			this.Load += new System.EventHandler(this.frmFindWindow_Load);
			this.grpExpression.ResumeLayout(false);
			this.grpHandle.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void frmFindWindow_Load(object sender, System.EventArgs e)
		{
		
		}

		private void txtHandle_TextChanged(object sender, System.EventArgs e)
		{
		}

		private void btnFind_Click(object sender, System.EventArgs e)
		{
			Regex findTitle = null;
			Regex findClassName = null;
			int findHandle = 0;			
			
			try
			{
				if (txtHandle.Text.Trim().Length > 0)
				{
					findHandle = int.Parse(txtHandle.Text.Trim());
				}
				else
				{
					if (txtCaption.Text.Trim().Length > 0)
					{
						findTitle = new Regex(txtCaption.Text.Trim());
						Console.WriteLine("Test {0}",
							findTitle.IsMatch("Paint Shop Pro - enumeration.png"));
					}
					if (txtClassName.Text.Trim().Length > 0)
					{
						findClassName = new Regex(txtClassName.Text.Trim());
						Console.WriteLine("Test {0}",
							findTitle.IsMatch("#32767"));
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(this,
					String.Format("Invalid data entered: {0}", ex.Message),
					this.Text,
					MessageBoxButtons.OK,
					MessageBoxIcon.Exclamation);
			}


			lstResults.Items.Clear();
			FindWindow fw = new FindWindow(
				IntPtr.Zero,
				findHandle,
				findClassName,
				findTitle
				);

			foreach (IntPtr handle in fw.Handles)
			{
				EnumWindowsItem ew = new EnumWindowsItem(handle);
				lstResults.Items.Add(
					String.Format("{0:x8} '{1}' ({2})",
						(int)ew.Handle,
						ew.Text,
						ew.ClassName));
			}
		}

		#region Customised EnumWindows for find purposes
		// Customised EnumWindows for find purposes:
		public class FindWindow : EnumWindows
		{
			private Regex findClassName = null;
			private Regex findTitle = null;
			private IntPtr findHandle = IntPtr.Zero;
			private IntPtr startHandle = IntPtr.Zero;
			private ArrayList handles = null;

			public ArrayList Handles
			{
				get
				{
					return handles;
				}
			}

			private void find()
			{
				this.handles = new ArrayList();
				if (startHandle == IntPtr.Zero)
				{
					this.GetWindows();
				}
				else
				{
					this.GetWindows(startHandle);
				}
			}

			protected override bool OnWindowEnum(
				IntPtr hWnd)
			{
				bool ret = true;
				if (hWnd == findHandle)
				{
					handles.Add(hWnd);
					ret = false;
				}
				else
				{
					EnumWindowsItem ew = new EnumWindowsItem(hWnd);
					if (findClassName != null)
					{
						if (findClassName.IsMatch(ew.ClassName))
						{
							handles.Add(hWnd);							
						}
					}
					if (findTitle != null)
					{
						if (findTitle.IsMatch(ew.Text))
						{
							handles.Add(hWnd);							
						}
					}
				}
				if (ret)
				{
					// check all the children:
					if (this.startHandle == IntPtr.Zero)
					{
						FindWindow fw = new FindWindow(hWnd, (int)findHandle, findClassName, findTitle);
						foreach (IntPtr handle in fw.Handles)
						{
							this.handles.Add(handle);
							if (findHandle != IntPtr.Zero)
							{
								ret = false;
							}
						}
					}
				}
				//Console.WriteLine("{0} {1}", hWnd, ret);
				return ret;
			}

			public FindWindow(
				IntPtr startHandle,
				int findHandle,
				Regex findClassName,
				Regex findTitle
				) : base()
			{
				//Console.WriteLine("FindWindow: {0}", startHandle, findHandle);
				this.findHandle = (IntPtr)findHandle;
				this.findClassName = findClassName;
				this.findTitle = findTitle;
				this.startHandle = startHandle;
				find();
			}
		}
		#endregion
	}
}
