***NOTES FOR DIjpg.dll***

I've taken the code from: www.hypermart.net/dilib and modified it. It's much more better
then the Intel library.


-Notes for C++
Most of the code is from the IJG , except DIwrjpeg.c and DIcommon.h .
Code was compiled using MSVC++ 5.0 .

The function's signature is :

long DIAPI DIWriteJpg ( char* DestPath    ,
                        char* SrcPath     ,
			long  quality     ,
			long  progressive )

See possible return values in "DIcommon.h"
