using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using vbAccelerator.Components.TextFilter;
using vbAccelerator.Components.Shell;

namespace IFilter
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.ListBox lstFilters;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.TreeView tvwFileClass;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			this.tvwFileClass.BeforeExpand += new TreeViewCancelEventHandler(tvwFileClass_BeforeExpand);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.lstFilters = new System.Windows.Forms.ListBox();
			this.button3 = new System.Windows.Forms.Button();
			this.tvwFileClass = new System.Windows.Forms.TreeView();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(196, 44);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(68, 40);
			this.button1.TabIndex = 0;
			this.button1.Text = "button1";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(212, 140);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(72, 36);
			this.button2.TabIndex = 1;
			this.button2.Text = "button2";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// lstFilters
			// 
			this.lstFilters.Location = new System.Drawing.Point(12, 140);
			this.lstFilters.Name = "lstFilters";
			this.lstFilters.Size = new System.Drawing.Size(196, 108);
			this.lstFilters.TabIndex = 2;
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(208, 268);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(72, 36);
			this.button3.TabIndex = 3;
			this.button3.Text = "button3";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// tvwFileClass
			// 
			this.tvwFileClass.ImageIndex = -1;
			this.tvwFileClass.Location = new System.Drawing.Point(12, 260);
			this.tvwFileClass.Name = "tvwFileClass";
			this.tvwFileClass.SelectedImageIndex = -1;
			this.tvwFileClass.Size = new System.Drawing.Size(188, 156);
			this.tvwFileClass.TabIndex = 4;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 430);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.tvwFileClass,
																		  this.button3,
																		  this.lstFilters,
																		  this.button2,
																		  this.button1});
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());			
		}

		private void tvwFileClass_BeforeExpand(object sender, TreeViewCancelEventArgs e)
		{
			if (e.Node.Nodes[0] != null)
			{
				if (e.Node.Nodes[0].Text.Equals("EXPANDME"))
				{
					e.Node.Nodes[0].Remove();
					FileClass fc = new FileClass(FileClassKeyHive.LocalMachine, e.Node.Text);
					foreach (FileExtension ext in fc.Extensions)
					{
						e.Node.Nodes.Add(
							new TreeNode(
								String.Format("{0} - {1}", ext.Extension, ext.DisplayName)));
					}
				}
			}
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			TextFilter i = new TextFilter(@"C:\SteveMac\Html\SSite\codelib\article\circ2.htm");
			//IFilterLib i = new IFilterLib(@"C:\SteveMac\Word\CV\2003\CV - 2002.doc");
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			lstFilters.Items.Clear();
			TextFilterImplementations impls = new TextFilterImplementations();
			foreach (TextFilterImplementation impl in impls)
			{
				lstFilters.Items.Add(impl.Description + "  " + impl.DllFileName);
			}
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			FileClass f = new FileClass(FileClassKeyHive.LocalMachine, "txtfile");
			Console.WriteLine("{0} {1} {2} {3}", f.ClassName, f.Associations.Count, f.Extensions.Count, f.DefaultIcon);

			FileClasseNames fc = new FileClasseNames(FileClassKeyHive.LocalMachine);

			foreach (string className in fc)
			{
				TreeNode classNode = new TreeNode(
										className);
				classNode.Nodes.Add(new TreeNode("EXPANDME"));
				tvwFileClass.Nodes.Add(classNode);
			}
		}
	}
}
