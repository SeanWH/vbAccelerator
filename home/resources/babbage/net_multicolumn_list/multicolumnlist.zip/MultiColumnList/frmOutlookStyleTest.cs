using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Xml;

using vbAccelerator.Components.ListBox;

namespace MultiColumnList
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmOutlookStyleTest : System.Windows.Forms.Form
	{
		private string genericPageUrl;

		private System.Windows.Forms.ImageList ilsIcons;
		private System.Windows.Forms.CheckBox chkShowMessagePreview;
		private System.Windows.Forms.Panel pnlProps;
		private System.Windows.Forms.Label lblColumn;
		private System.Windows.Forms.ComboBox cboColumns;
		private System.Windows.Forms.PropertyGrid pgrdColumn;
		private vbAccelerator.Components.ListBox.SListBox lstOutlookStyleTest;
		private System.Windows.Forms.Panel pnlTools;
		private System.Windows.Forms.Splitter spltColumnProps;
		private System.Windows.Forms.Panel pnlIE;
		private AxSHDocVw.AxWebBrowser webMessage;
		private System.Windows.Forms.Splitter splitter1;
		private System.Windows.Forms.CheckBox chkPreviewPane;
		private System.Windows.Forms.CheckBox chkGroupingRows;
		private System.ComponentModel.IContainer components;

		public frmOutlookStyleTest()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.genericPageUrl = Path.Combine(
				System.Environment.CurrentDirectory,
				"genericPage.html");
			this.lstOutlookStyleTest.DoubleClick += new EventHandler(lstOutlookStyleTest_DoubleClick);
			this.lstOutlookStyleTest.SelectedIndexChanged += new EventHandler(lstOutlookStyleTest_SelectedIndexChanged);
			this.cboColumns.SelectedIndexChanged += new EventHandler(cboColumns_SelectedIndexChanged);
			this.pnlProps.SizeChanged += new EventHandler(pnlProps_SizeChanged);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmOutlookStyleTest));
			this.ilsIcons = new System.Windows.Forms.ImageList(this.components);
			this.pnlTools = new System.Windows.Forms.Panel();
			this.chkShowMessagePreview = new System.Windows.Forms.CheckBox();
			this.pnlProps = new System.Windows.Forms.Panel();
			this.lblColumn = new System.Windows.Forms.Label();
			this.cboColumns = new System.Windows.Forms.ComboBox();
			this.pgrdColumn = new System.Windows.Forms.PropertyGrid();
			this.spltColumnProps = new System.Windows.Forms.Splitter();
			this.lstOutlookStyleTest = new vbAccelerator.Components.ListBox.SListBox();
			this.pnlIE = new System.Windows.Forms.Panel();
			this.webMessage = new AxSHDocVw.AxWebBrowser();
			this.splitter1 = new System.Windows.Forms.Splitter();
			this.chkPreviewPane = new System.Windows.Forms.CheckBox();
			this.chkGroupingRows = new System.Windows.Forms.CheckBox();
			this.pnlTools.SuspendLayout();
			this.pnlProps.SuspendLayout();
			this.pnlIE.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.webMessage)).BeginInit();
			this.SuspendLayout();
			// 
			// ilsIcons
			// 
			this.ilsIcons.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.ilsIcons.ImageSize = new System.Drawing.Size(16, 16);
			this.ilsIcons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ilsIcons.ImageStream")));
			this.ilsIcons.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// pnlTools
			// 
			this.pnlTools.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.chkGroupingRows,
																				   this.chkPreviewPane,
																				   this.chkShowMessagePreview});
			this.pnlTools.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnlTools.Name = "pnlTools";
			this.pnlTools.Size = new System.Drawing.Size(412, 32);
			this.pnlTools.TabIndex = 7;
			this.pnlTools.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlTools_Paint);
			// 
			// chkShowMessagePreview
			// 
			this.chkShowMessagePreview.Checked = true;
			this.chkShowMessagePreview.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkShowMessagePreview.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.chkShowMessagePreview.Location = new System.Drawing.Point(4, 4);
			this.chkShowMessagePreview.Name = "chkShowMessagePreview";
			this.chkShowMessagePreview.Size = new System.Drawing.Size(92, 24);
			this.chkShowMessagePreview.TabIndex = 0;
			this.chkShowMessagePreview.Text = "&Auto Preview";
			this.chkShowMessagePreview.CheckedChanged += new System.EventHandler(this.chkShowMessagePreview_CheckedChanged);
			// 
			// pnlProps
			// 
			this.pnlProps.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.lblColumn,
																				   this.cboColumns,
																				   this.pgrdColumn});
			this.pnlProps.Dock = System.Windows.Forms.DockStyle.Right;
			this.pnlProps.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.pnlProps.Location = new System.Drawing.Point(268, 32);
			this.pnlProps.Name = "pnlProps";
			this.pnlProps.Size = new System.Drawing.Size(144, 290);
			this.pnlProps.TabIndex = 11;
			// 
			// lblColumn
			// 
			this.lblColumn.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.lblColumn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblColumn.Location = new System.Drawing.Point(2, 0);
			this.lblColumn.Name = "lblColumn";
			this.lblColumn.Size = new System.Drawing.Size(140, 16);
			this.lblColumn.TabIndex = 2;
			this.lblColumn.Text = "Column:";
			// 
			// cboColumns
			// 
			this.cboColumns.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cboColumns.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.cboColumns.Location = new System.Drawing.Point(2, 20);
			this.cboColumns.Name = "cboColumns";
			this.cboColumns.Size = new System.Drawing.Size(144, 21);
			this.cboColumns.TabIndex = 1;
			// 
			// pgrdColumn
			// 
			this.pgrdColumn.CommandsVisibleIfAvailable = true;
			this.pgrdColumn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.pgrdColumn.LargeButtons = false;
			this.pgrdColumn.LineColor = System.Drawing.SystemColors.ScrollBar;
			this.pgrdColumn.Location = new System.Drawing.Point(2, 50);
			this.pgrdColumn.Name = "pgrdColumn";
			this.pgrdColumn.Size = new System.Drawing.Size(144, 268);
			this.pgrdColumn.TabIndex = 0;
			this.pgrdColumn.Text = "PropertyGrid";
			this.pgrdColumn.ViewBackColor = System.Drawing.SystemColors.Window;
			this.pgrdColumn.ViewForeColor = System.Drawing.SystemColors.WindowText;
			// 
			// spltColumnProps
			// 
			this.spltColumnProps.Dock = System.Windows.Forms.DockStyle.Right;
			this.spltColumnProps.Location = new System.Drawing.Point(264, 32);
			this.spltColumnProps.Name = "spltColumnProps";
			this.spltColumnProps.Size = new System.Drawing.Size(4, 290);
			this.spltColumnProps.TabIndex = 13;
			this.spltColumnProps.TabStop = false;
			// 
			// lstOutlookStyleTest
			// 
			this.lstOutlookStyleTest.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lstOutlookStyleTest.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
			this.lstOutlookStyleTest.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lstOutlookStyleTest.ImageList = null;
			this.lstOutlookStyleTest.Location = new System.Drawing.Point(0, 32);
			this.lstOutlookStyleTest.Name = "lstOutlookStyleTest";
			this.lstOutlookStyleTest.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.lstOutlookStyleTest.ShowGroupingRows = false;
			this.lstOutlookStyleTest.Size = new System.Drawing.Size(264, 290);
			this.lstOutlookStyleTest.TabIndex = 14;
			// 
			// pnlIE
			// 
			this.pnlIE.Controls.AddRange(new System.Windows.Forms.Control[] {
																				this.webMessage,
																				this.splitter1});
			this.pnlIE.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.pnlIE.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.pnlIE.Location = new System.Drawing.Point(0, 322);
			this.pnlIE.Name = "pnlIE";
			this.pnlIE.Size = new System.Drawing.Size(412, 132);
			this.pnlIE.TabIndex = 4;
			// 
			// webMessage
			// 
			this.webMessage.ContainingControl = this;
			this.webMessage.Dock = System.Windows.Forms.DockStyle.Fill;
			this.webMessage.Enabled = true;
			this.webMessage.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.webMessage.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("webMessage.OcxState")));
			this.webMessage.Size = new System.Drawing.Size(412, 128);
			this.webMessage.TabIndex = 4;
			// 
			// splitter1
			// 
			this.splitter1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.splitter1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.splitter1.Location = new System.Drawing.Point(0, 128);
			this.splitter1.Name = "splitter1";
			this.splitter1.Size = new System.Drawing.Size(412, 4);
			this.splitter1.TabIndex = 3;
			this.splitter1.TabStop = false;
			// 
			// chkPreviewPane
			// 
			this.chkPreviewPane.Checked = true;
			this.chkPreviewPane.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkPreviewPane.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.chkPreviewPane.Location = new System.Drawing.Point(100, 4);
			this.chkPreviewPane.Name = "chkPreviewPane";
			this.chkPreviewPane.Size = new System.Drawing.Size(92, 24);
			this.chkPreviewPane.TabIndex = 1;
			this.chkPreviewPane.Text = "&Preview Pane";
			this.chkPreviewPane.CheckedChanged += new System.EventHandler(this.chkPreviewPane_CheckedChanged);
			// 
			// chkGroupingRows
			// 
			this.chkGroupingRows.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.chkGroupingRows.Location = new System.Drawing.Point(200, 4);
			this.chkGroupingRows.Name = "chkGroupingRows";
			this.chkGroupingRows.Size = new System.Drawing.Size(144, 24);
			this.chkGroupingRows.TabIndex = 2;
			this.chkGroupingRows.Text = "Show &Grouping Rows";
			this.chkGroupingRows.CheckedChanged += new System.EventHandler(this.chkGroupingRows_CheckedChanged);
			// 
			// frmOutlookStyleTest
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(412, 454);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lstOutlookStyleTest,
																		  this.spltColumnProps,
																		  this.pnlProps,
																		  this.pnlTools,
																		  this.pnlIE});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "frmOutlookStyleTest";
			this.Text = "Outlook Style Demo";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.pnlTools.ResumeLayout(false);
			this.pnlProps.ResumeLayout(false);
			this.pnlIE.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.webMessage)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmOutlookStyleTest());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{	
			// load generic page that we can insert our HTML into:
			object o = null;
			webMessage.Navigate(genericPageUrl, ref o, ref o, ref o, ref o);

			// Set up the Listbox
			lstOutlookStyleTest.ImageList = ilsIcons;

			// Add the columns:
			SListColumn col = new SListColumn();			
			col.Width = 20;
			lstOutlookStyleTest.Columns.Add(col);

			col = new SListColumn();
			col.Text = "From";
			col.Width = 160;
			lstOutlookStyleTest.Columns.Add(col);

			col = new SListColumn();
			col.Text = "Subject";
			col.Width = 300;
			lstOutlookStyleTest.Columns.Add(col);

			col = new SListColumn();
			col.Text = "Date Received";
			col.Width = 72;
			lstOutlookStyleTest.Columns.Add(col);

			// Set up property list editing of column information:
			foreach (SListColumn colItem in lstOutlookStyleTest.Columns)
			{
				cboColumns.Items.Add(colItem);
			}
			cboColumns.SelectedIndex = 0;

			// Add some data:
			populateListBox();

		}

		private void populateListBox()
		{

			// Set up a custom format for the preview text of a cell:
			StringFormat previewFormat = new StringFormat();
			previewFormat.Alignment = StringAlignment.Near;
			previewFormat.LineAlignment = StringAlignment.Near;
			previewFormat.FormatFlags = StringFormatFlags.LineLimit;
			previewFormat.Trimming = StringTrimming.EllipsisCharacter;

			// Load the xml data containing the messages:
			string file = Path.Combine(System.Environment.CurrentDirectory, "messages.xml");
			XmlDocument doc = new XmlDocument();
			doc.Load(file);

			foreach (XmlNode node in doc.SelectNodes("messages/message"))
			{
				string from = node.SelectSingleNode("from").FirstChild.Value;
				string dateReceivedStr = node.SelectSingleNode("dateReceived").FirstChild.Value;
				DateTime dateReceived = DateTime.Parse(dateReceivedStr);
				string subject = node.SelectSingleNode("subject").InnerText;
				XmlNode content = node.SelectSingleNode("content");
				string contentText = content.InnerText;
				/*
				if (contentText.Length > 255)
				{
					contentText = contentText.Substring(0, 255);
				}
				*/
				string contentHtml = content.InnerXml;

				SListColumnItem dateColumn = new SListColumnItem(dateReceived);
				dateColumn.TextFormat = "{0:d}";
				SListColumnItem[] sCols = new SListColumnItem[4]
					{
						new SListColumnItem("",0),
						new SListColumnItem(from),
						new SListColumnItem(subject),
						dateColumn
					};
				SListItem item = new SListItem(
					sCols,
					contentText);
				item.ForeColor = Color.DarkBlue;
				item.StringFormat = previewFormat;
				item.Height = 34;
				item.Tag = contentHtml;
				item.Indentation = 32;

				this.lstOutlookStyleTest.Items.Add(item);
			}

		}

		private void lstOutlookStyleTest_DoubleClick(object sender, System.EventArgs e)
		{
			SListItem s = lstOutlookStyleTest.Items[lstOutlookStyleTest.SelectedIndex];
			if (!s.ShowColumns)
			{
				if (s.Expanded)
				{
					s.Collapse();
				}
				else
				{
					s.Expand();
				}
			}
		}
		private void cboColumns_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			int index = cboColumns.SelectedIndex;
			if (index > -1)
			{
				pgrdColumn.SelectedObject = cboColumns.SelectedItem;
			}
		}

		private void lstOutlookStyleTest_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			int index = lstOutlookStyleTest.SelectedIndex;
			if ((index > -1) && (chkPreviewPane.Checked))
			{
				// Show the text
				string html = (string)lstOutlookStyleTest.Items[index].Tag;
				mshtml.HTMLDocument doc = (mshtml.HTMLDocument)webMessage.Document;
				doc.body.innerHTML = html;
				
			}			
		}

		private void chkShowMessagePreview_CheckedChanged(object sender, System.EventArgs e)
		{
			bool state = chkShowMessagePreview.Checked;
			// can't use a for-each enumerator when changing height
			// because items have to be removed from the Listbox
			// to change their heights...
			for (int i = 0; i < lstOutlookStyleTest.Items.Count; i++)
			{
				lstOutlookStyleTest.Items[i].ShowText = state;
			}
		}

		private void pnlProps_SizeChanged(object sender, System.EventArgs e)
		{
			int width = pnlProps.Width - lblColumn.Left * 2;
			width = Math.Max(width, 4);
			lblColumn.Width = width;
			cboColumns.Width = width;
			int height = pnlProps.Height - pgrdColumn.Top;
			height = Math.Max(height, 4);
			pgrdColumn.Width = width;
			pgrdColumn.Height = height;
		}

		private void chkPreviewPane_CheckedChanged(object sender, System.EventArgs e)
		{
			pnlIE.Visible = chkPreviewPane.Checked;
		}

		private void pnlTools_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
		
		}

		private void chkGroupingRows_CheckedChanged(object sender, System.EventArgs e)
		{
			lstOutlookStyleTest.ShowGroupingRows = (chkGroupingRows.Checked);
		}

	}
}
